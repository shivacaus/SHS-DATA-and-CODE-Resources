% Regression  ΔI & ΔR vs Weather (lag-7), 
% NOTE: Ensure that the data file
% 'Epidemic and meteorological data_Nepal.xlsx'
% is located in the same folder.
%%------------------------------------------
clear; clc; close all; rng(2025,'twister');
% --- Figure/typography defaults for EPS ---
set(groot,'defaultTextInterpreter','latex');
set(groot,'defaultAxesTickLabelInterpreter','latex');
set(groot,'defaultLegendInterpreter','latex');

FIG_W_IN = 6.9;   
FIG_H_IN = 3.6;   

%% smoothing
use_sgolay = true;   % << set false for unsmoothed primary analysis
sg_span     = 7;     % must be odd
sg_order    = 3;

time_lag = 7;        % days
half = (sg_span-1)/2;

%% Load
T = readtable('Epidemic and meteorological data_Nepal.xlsx');
I   = T.I;   R   = T.R_c;
T2M = T.T2M; RH2M = T.RH2M; WS2M = T.WS2M;
%% 
if use_sgolay
    sgTrail = @(x) [sgolayfilt(x, sg_order, sg_span); nan(0,1)]; 
    makeTrailing = @(xc) [xc(half+1:end); nan(half,1)];
    T2M = makeTrailing( sgTrail(T2M) );
    RH2M= makeTrailing( sgTrail(RH2M) );
    WS2M= makeTrailing( sgTrail(WS2M) );
    I    = makeTrailing( sgTrail(I) );
    R    = makeTrailing( sgTrail(R) );
end

%% Build lag-7 weather 
W      = [T2M RH2M WS2M];
wf_pad = [nan(time_lag,3); W(1:end-time_lag,:)];
T_lag  = wf_pad(:,1); RH_lag = wf_pad(:,2); WS_lag = wf_pad(:,3);

%% Clean alignment
keep = all(isfinite([I R T_lag RH_lag WS_lag]),2);
I = I(keep); R = R(keep);
T_lag = T_lag(keep); RH_lag = RH_lag(keep); WS_lag = WS_lag(keep);

%% Standardize predictors
[zT, muT, sT ]  = zscore(T_lag);
[zRH,muRH,sRH]  = zscore(RH_lag);
[zWS,muWS,sWS]  = zscore(WS_lag);

%% Daily changes 
dI = [NaN; diff(I)];
dR = [NaN; diff(R)];
tblD = table(dI(2:end), dR(2:end), zT(2:end), zRH(2:end), zWS(2:end), ...
    'VariableNames', {'dI','dR','zT','zRH','zWS'});

%% Robust regressions
mdl_dI = safeFitlm(tblD, 'dI ~ zT + zRH + zWS');
mdl_dR = safeFitlm(tblD, 'dR ~ zT + zRH + zWS');

%% Figure: 
nx  = 120;
xT  = linspace(min(T_lag),  max(T_lag),  nx)';   % original units
xRH = linspace(min(RH_lag), max(RH_lag), nx)';
xWS = linspace(min(WS_lag), max(WS_lag), nx)';

mkTbl = @(x,which) table( ...
    (which==1)*(x - muT)/sT  + (which~=1)*zeros(size(x)), ...
    (which==2)*(x - muRH)/sRH+ (which~=2)*zeros(size(x)), ...
    (which==3)*(x - muWS)/sWS+ (which~=3)*zeros(size(x)), ...
    'VariableNames',{'zT','zRH','zWS'});

[yDI_T,ciDI_T]   = predict(mdl_dI, mkTbl(xT,1));  [yDR_T,ciDR_T]   = predict(mdl_dR, mkTbl(xT,1));
[yDI_RH,ciDI_RH] = predict(mdl_dI, mkTbl(xRH,2)); [yDR_RH,ciDR_RH] = predict(mdl_dR, mkTbl(xRH,2));
[yDI_WS,ciDI_WS] = predict(mdl_dI, mkTbl(xWS,3)); [yDR_WS,ciDR_WS] = predict(mdl_dR, mkTbl(xWS,3));

figure('Name','ΔI and ΔR_c vs Weather (lag-7)','Color','w');
tiledlayout(2,3,'Padding','compact','TileSpacing','compact');

ttl_suffix = ternary(use_sgolay, ' (trailing SG(7,3), lag = 7)');

% -------- ΔI panels --------
nexttile;  % ΔI vs T
fill([xT; flipud(xT)], [ciDI_T(:,1); flipud(ciDI_T(:,2))], 0.9*[1 1 1], 'EdgeColor','none'); hold on
plot(xT, yDI_T, 'LineWidth', 1.8);
grid on
xlabel('Temperature ($^\circ$C)', 'Interpreter','latex','FontWeight','bold');
ylabel('$\Delta I$', 'Interpreter','latex','FontWeight','bold');
title('$\Delta I$ vs T', 'Interpreter','latex');

nexttile;  % ΔI vs RH
fill([xRH; flipud(xRH)], [ciDI_RH(:,1); flipud(ciDI_RH(:,2))], 0.9*[1 1 1], 'EdgeColor','none'); hold on
plot(xRH, yDI_RH, 'LineWidth', 1.8);
grid on
xlabel('Relative Humidity (\%)', 'Interpreter','latex','FontWeight','bold');
ylabel('$\Delta I$', 'Interpreter','latex','FontWeight','bold');
title('$\Delta I$ vs RH', 'Interpreter','latex');

nexttile;  % ΔI vs WS
fill([xWS; flipud(xWS)], [ciDI_WS(:,1); flipud(ciDI_WS(:,2))], 0.9*[1 1 1], 'EdgeColor','none'); hold on
plot(xWS, yDI_WS, 'LineWidth', 1.8);
grid on
xlabel('Wind Speed ($\mathrm{m\,s^{-1}}$)', 'Interpreter','latex','FontWeight','bold');
ylabel('$\Delta I$', 'Interpreter','latex','FontWeight','bold');
title('$\Delta I$ vs WS', 'Interpreter','latex');

% -------- ΔR panels --------
nexttile;  % ΔR vs T
fill([xT; flipud(xT)], [ciDR_T(:,1); flipud(ciDR_T(:,2))], 0.9*[1 1 1], 'EdgeColor','none'); hold on
plot(xT, yDR_T, 'LineWidth', 1.8);
grid on
xlabel('Temperature ($^\circ$C)', 'Interpreter','latex','FontWeight','bold');
ylabel('$\Delta R_c$', 'Interpreter','latex','FontWeight','bold');
title('$\Delta R_c$ vs T', 'Interpreter','latex');

nexttile;  % ΔR vs RH
fill([xRH; flipud(xRH)], [ciDR_RH(:,1); flipud(ciDR_RH(:,2))], 0.9*[1 1 1], 'EdgeColor','none'); hold on
plot(xRH, yDR_RH, 'LineWidth', 1.8);
grid on
xlabel('Relative Humidity (\%)', 'Interpreter','latex','FontWeight','bold');
ylabel('$\Delta R_c$', 'Interpreter','latex','FontWeight','bold');
title('$\Delta R_c$ vs RH', 'Interpreter','latex');

nexttile;  % ΔR vs WS
fill([xWS; flipud(xWS)], [ciDR_WS(:,1); flipud(ciDR_WS(:,2))], 0.9*[1 1 1], 'EdgeColor','none'); hold on
plot(xWS, yDR_WS, 'LineWidth', 1.8);
grid on
xlabel('Wind Speed ($\mathrm{m\,s^{-1}}$)', 'Interpreter','latex','FontWeight','bold');
ylabel('$\Delta R_c$', 'Interpreter','latex','FontWeight','bold');
title('$\Delta R_c$ vs WS', 'Interpreter','latex');

fig = gcf;                       
set(fig,'Renderer','painters');  

exportgraphics(fig,'dI_dR_weather.eps','ContentType','vector');

%%  summary
names = {'Temperature','Relative Humidity','Wind Speed'};

bI  = mdl_dI.Coefficients.Estimate(2:4);
pI  = mdl_dI.Coefficients.pValue(2:4);
ciI = coefCI(mdl_dI,0.05);  ciI = ciI(2:4,:);

bR  = mdl_dR.Coefficients.Estimate(2:4);
pR  = mdl_dR.Coefficients.pValue(2:4);
ciR = coefCI(mdl_dR,0.05);  ciR = ciR(2:4,:);

fprintf('\n=== Manuscript summary (ΔI, ΔR_c; lag-7)%s ===\n', ttl_suffix);
for j=1:3
    fprintf('ΔI: Increase in %s %s ΔI (%s; p=%g; 95%% CI [%+.1f,%+.1f]).\n', ...
        names{j}, ternary(bI(j)>0,'increases','decreases'), p2label(pI(j)), pI(j), ciI(j,1), ciI(j,2));
    fprintf('ΔR_c: Increase in %s %s ΔR_c (%s; p=%g; 95%% CI [%+.1f,%+.1f]).\n', ...
        names{j}, ternary(bR(j)>0,'increases','decreases'), p2label(pR(j)), pR(j), ciR(j,1), ciR(j,2));
end


if use_sgolay
    fprintf(['Note: exposure uses trailing SG(7,3): each daily weather value is a poly-smoothed\n' ...
             'average of the **preceding 7 days**, then shifted by lag=7.\n' ...
             'Hence effects at day t reflect weather over t-13 to t-7 days.\n']);
end

%% -------------------------- Helpers -------------------------------------
function s = p2label(p)
    if p < 1e-3
        s = "strongly significant";
    elseif p < 1e-2
        s = "moderately significant";
    elseif p < 0.05
        s = "weakly significant";
    elseif p < 0.10
        s = "suggestive (not statistically significant)";
    else
        s = "insignificant";
    end
end

function out = ternary(cond, a, b)
    if cond, out = a; else, out = b; end
end

function mdl = safeFitlm(tbl, formula)
    ws = warning('query','stats:statrobustfit:IterationLimit');
    warning('error','stats:statrobustfit:IterationLimit');
    try
        mdl = fitlm(tbl, formula, 'RobustOpts','bisquare');
    catch ME
        if strcmp(ME.identifier,'stats:statrobustfit:IterationLimit')
            try
                mdl = fitlm(tbl, formula, 'RobustOpts','huber');
            catch
                mdl = fitlm(tbl, formula, 'RobustOpts','off');
            end
        else
            rethrow(ME);
        end
    end
    warning(ws.state, ws.identifier);
end
