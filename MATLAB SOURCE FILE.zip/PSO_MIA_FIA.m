%%% PSO-MIA-FIA Model %%%
% NOTE: Ensure that the data file
% 'Epidemic and meteorological data_Nepal.xlsx'
% is located in the same folder.

%% ===================== PART A: Data Preprocessing =====================
fprintf('\n========== PART A: DATA PREPROCESSING ==========\n');

% 1) Loading Data
data  = readtable('Epidemic and meteorological data_Nepal.xlsx');
I     = data.I;                   % Active case
R     = data.R_c;                 % Recovered
DD    = data.Death_Daily;         % Daily death ( Daily DIF)
N     = data.N_Living;            % Living population
T2M   = data.T2M;                 % Temperature at 2M
RH2M  = data.RH2M;                % Relative humidity
WS2M  = data.WS2M;                % Wind speed
u_t   = data.u_t;                 % Non-pharmaceutical measures (NPM)
v_t   = data.v_t;                 % Vaccination coverage (VC)
dates = data.Date;
n_days = height(data);

% 2) Weather features
weather_features = [T2M, RH2M, WS2M];

% 3) Birth rate by year
y = year(dates);
alpha = zeros(size(dates));
alpha(y==2020) = 5.65479e-05;
alpha(y==2021) = 5.60274e-05;
alpha(y==2022) = 5.52329e-05;

% 4) Settings 
rho_0 = 1/5; % average recovery rate
epsilon_0 = 1/7; % average incubation rate
vaccine_efficacy = 0.60;% 32%--97%

r_min = 1/28; r_max = 0.6;  % minimum and maximum recovery rate
e_min = 1/21; e_max = 0.6;  % minimum and maximum incubation rate
b_min = 5e-4; b_max = 1.6;  % minimum and maximum transmission rate
d_min = 0;    d_max = 1e-3; % DIF rate
u_min = 0.05; u_max= 0.95;  % Intervention efficacy

% ##1. Bounding struct
bds = struct('b_min', b_min, 'b_max', b_max, ...
             'r_min', r_min, 'r_max', r_max, ...
             'e_min', e_min, 'e_max', e_max, ...
             'd_min', d_min, 'd_max', d_max, ...
             'u_min', u_min, 'u_max', u_max);

time_lag   = 7;
span_param = 15;
polyorder  = 3;
windowSize = 11;

% 5) Intervention with lag ( 7-day)
u_combined = 1 - (1 - u_t).*(1 - v_t.*vaccine_efficacy);
u_combined = min(max(u_combined, u_min), u_max);

u_pad = [nan(time_lag,1); u_combined(1:end-time_lag)];
u_ts  = movmean(u_pad, 14, 'omitnan','Endpoints','shrink');
u_ts  = fillmissing(u_ts,'nearest');
u_ts  = min(max(u_ts, u_min), u_max);  % u_ts=NPM+VC (Combined intervention)

% 6) Weather lag (7-day)
wf_pad = [nan(time_lag,3); weather_features(1:end-time_lag,:)];

% 7) Removing initial lag period
keep_idx = (time_lag+1):n_days;
dates = dates(keep_idx);
I     = I(keep_idx);
R     = R(keep_idx);
DD    = DD(keep_idx);
N     = N(keep_idx);
u_ts  = u_ts(keep_idx);
alpha = alpha(keep_idx);
weather_features = wf_pad(keep_idx,:);
n_days = numel(dates);

% 8) Smoothing
alpha            = max(sgolayfilt(alpha, polyorder, span_param), 0);
weather_smoothed = sgolayfilt(weather_features, polyorder, span_param);

I_s = max(sgolayfilt(I, polyorder, span_param), 0);
R_s = max(sgolayfilt(R, polyorder, span_param), 0);
D_s = max(movmean(DD, 14, 'omitnan'), 0);

% 9) DIF 
delta_t = D_s ./ max(I_s, 1);
delta_t = sgolayfilt(delta_t, polyorder, span_param);
delta_t = min(max(delta_t, d_min), d_max);

% 10) Normalization
I_sn = min(max(I_s ./ N, 0), 1);
R_sn = min(max(R_s ./ N, 0), 1);

% 11) E estimation (3-method blend)
fprintf('Estimating Exposed (E) ...\n');
delta_I = [0; diff(I_sn)];
delta_I = sgolayfilt(delta_I, polyorder, span_param);

% M1 gamma convolution
incub_shape = 5.8; incub_scale = 0.9; max_incub_days = 21;
t_incub = 0:max_incub_days;
incub_kernel = gampdf(t_incub, incub_shape, incub_scale);
incub_kernel = incub_kernel / sum(incub_kernel);
E_method1 = conv(delta_I, incub_kernel, 'same') / epsilon_0;

% M2 growth multiplier
growth_rate = delta_I ./ max(I_sn, 1e-6);
growth_rate = sgolayfilt(growth_rate, polyorder, span_param);
E_to_I_multiplier = 1.5 + (1/epsilon_0) * growth_rate;
E_to_I_multiplier = min(max(E_to_I_multiplier, 1.2), 4.0);
E_method2 = I_sn .* E_to_I_multiplier;

% M3 model-based reconstruction
numerator = delta_I + (rho_0 + delta_t + alpha).*I_sn - delta_t.*(I_sn.^2);
E_method3 = numerator ./ max(epsilon_0, 1e-8);
E_method3 = sgolayfilt(E_method3, polyorder, span_param);
E_method3 = max(E_method3, 1e-6);

E_sn = 0.1*E_method1 + 0.2*E_method2 + 0.7*E_method3;
E_sn = sgolayfilt(E_sn, polyorder, span_param);
E_sn = max(E_sn, 1e-6);

% Ensure E > I 
needs_adjustment = (E_sn ./ max(I_sn,1e-6)) < 1;
E_sn(needs_adjustment) = 1.2 * I_sn(needs_adjustment);
fprintf('Adjusted %d time points to ensure E > I\n', sum(needs_adjustment));

% 12) Reconstruction of S + renormalization
S_sn = 1 - E_sn - I_sn - R_sn;
TS   = max(S_sn + E_sn + I_sn + R_sn, 1e-6);
S_sn = S_sn./TS; E_sn = E_sn./TS; I_sn = I_sn./TS; R_sn = R_sn./TS;

% 13) Derivatives and smoothing
dS_s = sgolayfilt(gradient(S_sn), polyorder, span_param);
dE_s = sgolayfilt(gradient(E_sn), polyorder, span_param);
dI_s = sgolayfilt(gradient(I_sn), polyorder, span_param);
dR_s = sgolayfilt(gradient(R_sn), polyorder, span_param);

% 14) Parameters (rho -> epsilon -> beta)
fprintf('Estimating parameters (rho -> epsilon -> beta)...\n');

% rho from dR
rho_SEIR = (dR_s + (alpha - delta_t .* I_sn).*R_sn) ./ max(I_sn,1e-6);
rho_SEIR = real(rho_SEIR);
rho_SEIR = fillmissing(rho_SEIR,'movmedian',windowSize);
rho_SEIR = min(max(rho_SEIR, r_min), r_max);

% epsilon from dI
epsilon_SEIR = (dI_s + (rho_SEIR + delta_t + alpha).*I_sn - delta_t.*I_sn.^2) ./ max(E_sn,1e-6);
epsilon_SEIR = real(epsilon_SEIR);
epsilon_SEIR = fillmissing(epsilon_SEIR,'movmedian',windowSize);
epsilon_SEIR = min(max(epsilon_SEIR, e_min), e_max);

% beta (intrinsic) from dE 
beta_SEIR = (dE_s + (epsilon_SEIR + alpha).*E_sn - delta_t.*I_sn.*E_sn) ./ max((1-u_ts).*S_sn.*I_sn, 1e-8);
beta_SEIR = real(beta_SEIR);
beta_SEIR = fillmissing(beta_SEIR,'movmedian',windowSize);
beta_SEIR = min(max(beta_SEIR, b_min), b_max);

% 15) Smooth + outlier repair + bounds
beta_SEIR    = sgolayfilt(beta_SEIR,    polyorder, span_param);
rho_SEIR     = sgolayfilt(rho_SEIR,     polyorder, span_param);
epsilon_SEIR = sgolayfilt(epsilon_SEIR, polyorder, span_param);

[beta_SEIR, rho_SEIR, epsilon_SEIR] = replaceBadValues(windowSize, beta_SEIR, rho_SEIR, epsilon_SEIR);

beta_SEIR    = min(max(beta_SEIR,    b_min), b_max);
rho_SEIR     = min(max(rho_SEIR,     r_min), r_max);
epsilon_SEIR = min(max(epsilon_SEIR, e_min), e_max);

% Compute beta_eff for later comparison
beta_SEIR_eff = (1 - u_ts) .* beta_SEIR;

% ##2. Initial conditions
initial_window = 7;  % Average 
x0_init = [
    mean(S_sn(1:initial_window));
    mean(E_sn(1:initial_window));
    mean(I_sn(1:initial_window));
    mean(R_sn(1:initial_window))
];
% Ensure normalization
x0_init = x0_init / sum(x0_init);
fprintf('PART A COMPLETE\n\n');

%%%%%%%%%%%%%%%%%%%%%
%% PART B: PSO + Pattern Search Optimization 
%%%%%%%%%%%%%%%%%%%%
fprintf('\n=== PSO (Global+Local) Optimization ===\n');

%   Inputs
m_d = weather_smoothed;  % T2M, RH2M, WS2M (lagged+smoothed)
o_d = [S_sn, E_sn, I_sn, R_sn];
c_p = [beta_SEIR, epsilon_SEIR, rho_SEIR, u_ts, delta_t];

% Z-score normalize meteorological features
m_d = (m_d - mean(m_d,1,'omitnan')) ./ std(m_d,0,1,'omitnan');

t_sp = (1:n_days)';
n_meteo_ftr = 3; % number of meteo features

% Parameter bounds (18 total): [b0,bT,bRH,bWS, r0,rT,rRH,rWS, e0,eT,eRH,eWS, d0,dT,dRH,dWS, u_scale, ep_hold]
coef_low  = -1;  coef_high = 1 ;
dcoef_low = -1e-6;  dcoef_high = 1e-6;

lb = [b_min, coef_low*ones(1,n_meteo_ftr), r_min, coef_low*ones(1,n_meteo_ftr), ...
      e_min, coef_low*ones(1,n_meteo_ftr), d_min, dcoef_low*ones(1,n_meteo_ftr), u_min, 0];
ub = [b_max, coef_high*ones(1,n_meteo_ftr), r_max, coef_high*ones(1,n_meteo_ftr), ...
      e_max, coef_high*ones(1,n_meteo_ftr), d_max, dcoef_high*ones(1,n_meteo_ftr), u_max, 0];

% Parallel pool setup
if isempty(gcp('nocreate'))
    try parpool; catch, warning('Parallel pool unavailable; continuing serially.'); end
end
 
% Optimization options
pso_opt = optimoptions('particleswarm', 'Display','iter', 'MaxIterations', 300, ...
    'SwarmSize', 200, 'FunctionTolerance',1e-5, 'MaxStallIterations',200, ...
    'SelfAdjustmentWeight',1.45, 'SocialAdjustmentWeight',1.45, ...
    'InertiaRange',[0.2 0.9], 'MinNeighborsFraction', 0.25, ...
    'UseParallel', ~isempty(gcp('nocreate')));  

ps_options = optimoptions('patternsearch', 'Display','iter', 'MaxIterations', 10, ...
    'FunctionTolerance',1e-5, 'StepTolerance',1e-5, ...
    'UseParallel', ~isempty(gcp('nocreate')));

rng(1); tic;
obj_fun = @(x) seir_objective_function(x, m_d, o_d, alpha, t_sp, false, c_p, x0_init, bds, u_ts);

fprintf('\n--- STAGE 1: PSO GLOBAL SEARCH ---\n');
[pso_prm, pso_fval] = particleswarm(obj_fun, numel(lb), lb, ub, pso_opt);

fprintf('\n--- STAGE 2: PATTERN SEARCH REFINEMENT ---\n');
[optm_prm, fval] = patternsearch(obj_fun, pso_prm, [], [], [], [], lb, ub, [], ps_options);
optimization_time = toc;

% Results summary
fprintf('\nHYBRID OPTIMIZATION RESULTS WITH 7-DAY LAG (3 features, u_ts-aware):\n');
fprintf(' PSO Objective: %.6f\n', pso_fval);
fprintf(' Final Objective: %.6f (%.2f%%%% improvement)\n', fval, 100*(pso_fval-fval)/max(pso_fval,eps));
fprintf(' Total Optimization Time: %.2f seconds\n', optimization_time);

% Unpack for display
beta_params  = optm_prm(1: 4);
rho_params   = optm_prm(5: 8);
eps_params   = optm_prm(9:12);
delta_params = optm_prm(13:16);
u_scale      = optm_prm(17);

fprintf('\nOptimal Parameters:\n');
fprintf('Beta:    beta0=%.4f, [beta_T,beta_RH,beta_WS]=[%s]\n', beta_params(1),  num2str(beta_params(2:4), '%.4f '));
fprintf('Rho:     rho0=%.4f, [rho_T,rho_RH,rho_WS]=[%s]\n', rho_params(1),   num2str(rho_params(2:4),  '%.4f '));
fprintf('Epsilon: epsilon0=%.4f, [epsilon_T,epsilon_RH,epsilon_WS]=[%s]\n', eps_params(1),   num2str(eps_params(2:4), '%.4f '));
fprintf('Delta:   delta0=%.4f, [delta_T,delta_RH,delta_WS]=[%s]\n', delta_params(1), num2str(delta_params(2:4), '%.4f '));
fprintf('u_scale: %.4f  (u_eff = clamp(u_scale * u_ts))\n', u_scale);

%%%---PART C---%%%
%%  Post-optimization Simulation 
[S_model, E_model, I_model, R_model, u_eff] = simulate_seir_model( ...
    optm_prm, m_d, alpha, t_sp, x0_init, bds, u_ts);

modeled_data = [S_model, E_model, I_model, R_model];

% Environment-dependent parameter trajectories
beta_env  = beta_params(1)  * exp(m_d * beta_params(2:4)');
rho_env    = rho_params(1)   * exp(m_d * rho_params(2:4)');
eps_env    = eps_params(1)   * exp(m_d * eps_params(2:4)');
delta_env  = delta_params(1) * exp(m_d * delta_params(2:4)');

beta_env  = max(min(beta_env,  bds.b_max), bds.b_min);
rho_env    = max(min(rho_env,    bds.r_max), bds.r_min);
eps_env    = max(min(eps_env,    bds.e_max), bds.e_min);
delta_env  = max(min(delta_env,  bds.d_max), bds.d_min);

beta_env_eff = (1 - u_eff) .* beta_env;
%% --- Effective Reproduction Number R_t  ---
Rt_ts = (beta_env_eff.*eps_env .* S_model) ./ (max(rho_env + delta_env + alpha,1e-8).* max(eps_env + alpha, 1e-8));
Rt_ts = real(Rt_ts);
Rt_ts(~isfinite(Rt_ts)) = NaN;
%% --- Equilibrium classification & color ---
Rt_last = Rt_ts(end);

if Rt_last < 0.98
    eq_label = 'Disease-Free Equilibrium (DFE)';
    eq_color = [0.0 0.60 0.0];     % green
elseif Rt_last <= 1.02
    eq_label = 'Critical / Transitional';
    eq_color = [0.85 0.55 0.0];    % orange
else
    eq_label = 'Endemic Equilibrium (EE)';
    eq_color = [0.75 0.00 0.0];    % red
end

%%  Performance Metrics

[rmse_vals, mae_vals, r2_vals] = calculate_goodness_of_fit(o_d, modeled_data);
param_computed = [beta_SEIR, epsilon_SEIR, rho_SEIR, u_ts, delta_t];
param_modeled  = [beta_env, eps_env, rho_env, u_eff, delta_env];
[rmse_params, mae_params, r2_params] = calculate_goodness_of_fit(param_computed, param_modeled);

%%  Advanced Analyses 
fprintf('\n=== ADVANCED ANALYSES (Lag-aware) ===\n');

analyze_environmental_effects(beta_params, rho_params, eps_params, ...
    delta_params, u_scale, m_d, dates, time_lag, u_ts, bds);

k_folds = 5;
[cv_errors, cv_r2] = perform_cross_validation( ...
    weather_smoothed(:,1:3), o_d, alpha, k_folds, lb, ub, x0_init, [], bds, [], [], u_ts);

n_ensembles   = 200;
jitter_pct    = 0.10;
extend_mode   = 'trend';
forecast_days = 60;
[all_dates, median_SEIR, low_SEIR, high_SEIR, ~] = ...
    generate_forecast(optm_prm, m_d, alpha, forecast_days, x0_init, dates, bds, n_ensembles, jitter_pct, extend_mode, u_ts);

%%%---PART D (Plotting section)---%%%
%%  PLOTS 
fprintf('\n=== GENERATING PLOTS ===\n');
createFigure = @(n) figure('Units','normalized','OuterPosition',[0.05+n*0.02 0.05+n*0.02 0.85 0.75]);

outdir = 'fig';
if ~exist(outdir,'dir'), mkdir(outdir); end

%% Plot 1: Environmental effects
fprintf('Plot 1: Environmental Effects...\n');
FIG1_W = 7.0;  FIG1_H = 3.0;

env_range  = linspace(-3, 3, 200)';
param_sets = {beta_params, rho_params, eps_params};
panel_lbls = {'Transmission (beta)', 'Recovery (rho)', 'Incubation (epsilon)'};
feat_lbls  = {'T','RH','WS'};

fig1 = figure('Name','Plot1_EnvEffects','Color','w', 'Units','inches','Position',[1 1 FIG1_W FIG1_H]);
tiledlayout(fig1, 1, 3, 'Padding','compact','TileSpacing','compact');

for k = 1:3
    nexttile; hold on;
    p = param_sets{k};
    base = p(1);  cT = p(2);  cRH = p(3);  cWS = p(4);
    yT  = base * exp(env_range * cT);
    yRH = base * exp(env_range * cRH);
    yWS = base * exp(env_range * cWS);
    plot(env_range, yT,  'LineWidth', 1.8);
    plot(env_range, yRH, 'LineWidth', 1.8);
    plot(env_range, yWS, 'LineWidth', 1.8);
    grid on; box off;
    xlabel('Standardized feature value (z)', 'Interpreter','none');
    ylabel('Rate', 'Interpreter','none');
    title(panel_lbls{k}, 'Interpreter','none');
    legend(feat_lbls, 'Location','best', 'Box','off', 'Interpreter','none');
    set(gca,'FontSize',9,'LineWidth',0.8);
end
exportgraphics(fig1, fullfile(outdir,'meteo_effects.eps'), 'ContentType','vector');

%% Plot 2: Feature importance
fprintf('Plot 2: Feature Importance...\n');
FIG2_W = 6.8;  FIG2_H = 3.2;

beta_coeffs = abs(beta_params(2:4));
rho_coeffs  = abs(rho_params(2:4));
eps_coeffs  = abs(eps_params(2:4));
feature_names = {'T2M','RH2M','WS2M'};

fig2 = figure('Name','Plot2_FeatureImportance','Color','w', 'Units','inches','Position',[1 1 FIG2_W FIG2_H]);
tiledlayout(fig2, 1, 2, 'Padding','compact','TileSpacing','compact');

nexttile;
B = [beta_coeffs; rho_coeffs; eps_coeffs]';
bar(B, 'LineWidth',0.5);
set(gca,'XTickLabel',feature_names,'XTickLabelRotation',0);
ylabel('Coefficient magnitude (per z-unit)', 'Interpreter','none');
legend({'beta','rho','epsilon'}, 'Interpreter','none', 'Location','best', 'Box','off');
title('Feature Importance (Exponential Coefficients)', 'Interpreter','none');
grid on; box off; set(gca,'FontSize',9,'LineWidth',0.8);

nexttile;
overall_imp = mean(B,2);
[sorted_imp, order] = sort(overall_imp,'descend');
bar(sorted_imp, 'LineWidth',0.5);
set(gca,'XTickLabel',feature_names(order));
ylabel('Avg Coefficient magnitude (per z-unit)', 'Interpreter','none');
title('Overall Feature Importance', 'Interpreter','none');
grid on; box off; set(gca,'FontSize',9,'LineWidth',0.8);
exportgraphics(fig2, fullfile(outdir,'feature_importance.eps'), 'ContentType','vector');
  
%% ================= Plot 3: SEIR Forecast =================
fprintf('Plot 3: SEIR Forecast...\n');

createFigure(3);
x_all      = all_dates;
x_hist_end = dates(end);

% Colors
cS = [0.0000 0.4470 0.7410];
cE = [0.4940 0.1840 0.5560];
cI = [0.8500 0.3250 0.0980];
cR = [0.4660 0.6740 0.1880];
fa = 0.18;

tiledlayout(3,1,'TileSpacing','compact','Padding','compact');

%% -------- S (top) --------
ax1 = nexttile;
shaded_band_eps(ax1, x_all, ...
    low_SEIR(:,1), median_SEIR(:,1), high_SEIR(:,1), ...
    cS, 'Susceptible', 'S', fa);
xline(ax1, x_hist_end,'--','Color',[.2 .2 .2],'LineWidth',1);
ylim([0.93 0.99]);
grid on;

%% -------- E & I (middle) --------
ax2 = nexttile; hold on;

shaded_band_eps(ax2, x_all, ...
    low_SEIR(:,2), median_SEIR(:,2), high_SEIR(:,2), ...
    cE, 'Exposed', 'E', fa);

shaded_band_eps(ax2, x_all, ...
    low_SEIR(:,3), median_SEIR(:,3), high_SEIR(:,3), ...
    cI, 'Infected', 'I', fa);

xline(ax2, x_hist_end,'--','Color',[.2 .2 .2],'LineWidth',1);
ylabel('E, I');
grid on;

% --- Force stable axis ---
yEI_max = max(high_SEIR(:,3));
ylim([0 1.05*yEI_max]);

% --- Title AFTER plotting ---
title('Forecast of Exposed (E) and Infected (I)', ...
      'FontWeight','bold','FontSize',11);

%% --- R_t marker at forecast start ---
idxF = find(x_all >= x_hist_end,1);
plot(ax2, x_hist_end, median_SEIR(idxF,3), ...
    'o','MarkerFaceColor',eq_color, ...
    'MarkerEdgeColor','k','MarkerSize',6);

% --- R_t value (top-left) ---
text(ax2,0.02,0.95, ...
    sprintf('R_t = %.2f', Rt_last), ...
    'Units','normalized', ...
    'Interpreter','none', ...
    'FontSize',9, ...
    'FontWeight','bold', ...
    'VerticalAlignment','top', ...
    'Color',eq_color);

% --- Equilibrium label ---
annotation('textbox', ...
    [0.12 0.34 0.76 0.05], ...
    'String',['Equilibrium status: ', eq_label], ...
    'HorizontalAlignment','center', ...
    'FontWeight','bold', ...
    'FontSize',9, ...
    'EdgeColor','none', ...
    'Color',eq_color);

hold off;

%% -------- R_c (bottom) --------
ax3 = nexttile;
shaded_band_eps(ax3, x_all, ...
    low_SEIR(:,4), median_SEIR(:,4), high_SEIR(:,4), ...
    cR, 'Recovered', 'R_c', fa);
xline(ax3, x_hist_end,'--','Color',[.2 .2 .2],'LineWidth',1);
ylim([0 1]);
grid on;

%% -------- Global title --------
sgtitle(sprintf(['%d-Day SEIR Forecast (PSO) with 95%%%% Bands\n', ...
    '(n=%d, jitter=%.0f%%%%, %s meteo, u_ts-aware)'], ...
    forecast_days, n_ensembles, 100*jitter_pct, extend_mode), ...
    'Interpreter','none');

%%%---PART E (Summary section)---%%%
%%  Final Summary & Recommendations 
fprintf('\n=== FINAL SUMMARY & RECOMMENDATIONS (7-DAY LAG, 3 FEATURES, u_ts-aware) ===\n');

% Environmental coefficient magnitudes (exp form)
env_effects = [abs(beta_params(2:4)); abs(rho_params(2:4)); abs(eps_params(2:4)); abs(delta_params(2:4))];
[sorted_effects, sort_idx] = sort(env_effects(:), 'descend');
param_types = {'beta_T','beta_RH','beta_WS','rho_T','rho_RH','rho_WS','epsilon_T','epsilon_RH','epsilon_WS','delta_T','delta_RH','delta_WS'};

fprintf('\nTop 5 Environmental Effects (exp coefficients, 7-day lag):\n');
for i = 1:min(5,numel(sorted_effects))
    fprintf('%d. %s: %.4f\n', i, param_types{sort_idx(i)}, sorted_effects(i));
end

fprintf('\nTime Lag Applied: %d days (weather & interventions influence day t from t-%d)\n', time_lag, time_lag);
fprintf('u_scale = %.3f  -> scales empirical u_ts.\n', u_scale);

overall_rmse = mean(rmse_vals);
overall_r2   = mean(r2_vals);
fprintf('\nModel Quality: RMSE=%.4f, R^2=%.3f\n', overall_rmse, overall_r2);

env_factors = {'Temperature','Humidity','Windspeed'};
par_sets = {beta_params, rho_params, eps_params};
par_names = {'Transmission (beta)','Recovery (rho)','Incubation (epsilon)'};
for i = 1:3
    fprintf('\n%s (lagged, exp effects):\n', par_names{i});
    for j = 2:4
        c = par_sets{i}(j);
        if c > 1e-3,   fprintf('  + Higher %s increases %s\n', env_factors{j-1}, par_names{i});
        elseif c < -1e-3, fprintf('  - Higher %s reduces %s\n',  env_factors{j-1}, par_names{i});
        else,           fprintf('  ~ No clear effect of %s on %s\n', env_factors{j-1}, par_names{i});
        end
    end
end

fprintf('\nPolicy note: use u_ts (empirical) directly with a learned u_scale; this respects the measured NPI/vaccine trajectory and typically improves E & I fits and the parameter R^2.\n');
fprintf('=== ANALYSIS COMPLETE ===\n');

%%%---PART F---%%%
%%% HELPER FUNCTION 1 %%%
function analyze_environmental_effects(beta_params, rho_params, eps_params, delta_params, u_scale, meteo_data, ~, time_lag, u_ts, bds)
    fprintf('\n=== ENVIRONMENTAL EFFECTS (7-DAY LAG) ===\n');
    env_factors = meteo_data(:,1:3); % normalized, lagged
    env_names = {'Temperature (lag)','Humidity (lag)','Wind (lag)'};

    % Multiplicative env effects
    beta_env = beta_params(1) * exp(meteo_data*beta_params(2:4)');
    rho_env  =  rho_params(1)  * exp(meteo_data*rho_params(2:4)');
    eps_env  =  eps_params(1)  * exp(meteo_data*eps_params(2:4)');
    delta_env=  delta_params(1)* exp(meteo_data(:,1:3)*delta_params(2:4)');
    u_eff = min(max(u_scale .* u_ts, bds.u_min), bds.u_max);
    beta_env_eff = (1 - u_eff) .* beta_env;  
    param_env = [beta_env_eff, rho_env, eps_env, delta_env];
    param_names = {'Beta','Rho','Epsilon','Delta'};

    fprintf('\nCorrelation (env vs params):\n');
    fprintf('%-10s%14s%14s%14s\n','Param',env_names{1},env_names{2},env_names{3});
    for i = 1:4
        fprintf('%-10s', param_names{i});
        for j = 1:3
            c = corr(env_factors(:,j), param_env(:,i), 'rows','complete');
            fprintf('%14.4f', c);
        end
        fprintf('\n');
    end

    fprintf('\nPrimary |exp-coeff| with %d-day lag:\n', time_lag);
    sens = [abs(beta_params(2:4)); abs(rho_params(2:4)); abs(eps_params(2:4)); abs(delta_params(2:4))];
    fprintf('%-10s%14s%14s%14s\n','Param','Temp','Humidity','Wind');
    for i = 1:4
        fprintf('%-10s%14.4f%14.4f%14.4f\n', param_names{i}, sens(i,1), sens(i,2), sens(i,3));
    end
end

%%% HELPER FUNCTION 2 %%%
function [cv_errors, cv_r2] = perform_cross_validation( ...
        meteo_raw, observed_data, alpha, k_folds, lb, ub, ...
        initial_conditions, ~, bds, min_train, gap, u_full)

    fprintf('\n=== %d-FOLD CROSS-VALIDATION (time-blocked; train-only z-score; uses u_ts) ===\n', k_folds);

    n = size(observed_data,1);
    if nargin < 12 || isempty(u_full),    u_full = zeros(n,1); end
    if nargin < 11 || isempty(gap),       gap    = 0;          end
    if nargin < 10 || isempty(min_train), min_train = max(20, ceil(0.20*n)); end

    cv_errors = zeros(k_folds,1);
    cv_r2     = zeros(k_folds,1);

    % Define test blocks 
    if min_train >= n-5
        warning('min_train too large relative to series length; reducing.');
        min_train = max(10, floor(0.10*n));
    end
    edges = round(linspace(min_train+1, n+1, k_folds+1));

    usePar = ~isempty(gcp('nocreate'));

    for f = 1:k_folds
        test_start = edges(f);
        test_end   = edges(f+1)-1;
        test_idx   = test_start:test_end;

        % Train only on the past
        train_end  = max(test_start - 1 - gap, 1);
        train_idx  = 1:train_end;

        % Enforce minimum training history and a small test size
        if numel(train_idx) < min_train || numel(test_idx) < 5
            cv_errors(f) = inf; cv_r2(f) = -inf;
            fprintf('  Fold %d/%d... [insufficient data: train=%d, test=%d]\n', ...
                    f, k_folds, numel(train_idx), numel(test_idx));
            continue;
        end

        fprintf('  Fold %d/%d...', f, k_folds);

        % --- Fold-wise z-score from TRAIN only---
        train_raw = meteo_raw(train_idx, :);
        test_raw  = meteo_raw(test_idx,  :);

        mu  = mean(train_raw, 1, 'omitnan');
        sig = std(train_raw, 0, 1, 'omitnan');
        sig(~isfinite(sig) | sig == 0) = 1;

        train_m = (train_raw - mu) ./ sig;
        test_m  = (test_raw  - mu) ./ sig;

        % Observed normalized compartments
        train_o = observed_data(train_idx, :);
        test_o  = observed_data(test_idx,  :);

        % Time vectors 
        tr_t = (1:numel(train_idx))';
        te_t = (1:numel(test_idx))';

        % Align interventions
        train_u = u_full(train_idx);
        test_u  = u_full(test_idx);

        alpha_train = alpha(train_idx);
        alpha_test  = alpha(test_idx);

        % --- Objective WITHOUT parameter-trajectory term ---
        pso_opt = optimoptions('particleswarm', ...
            'Display','off', 'MaxIterations', 10, 'SwarmSize', 40, ...
            'UseParallel', usePar);

        cp_train = []; % no param-trajectory guidance inside CV training
        obj = @(x) seir_objective_function( ...
            x, train_m, train_o, alpha_train, tr_t, false, ...
            cp_train, initial_conditions, bds, train_u);

        try
            % Optimize on the training block
            [theta, ~] = particleswarm(obj, numel(lb), lb, ub, pso_opt);

            % Evaluate on the test block 
            [S,E,I,R] = simulate_seir_model(theta, test_m, alpha_test, te_t, ...
                                            initial_conditions, bds, test_u);
            pred = [S,E,I,R];  

            % Metrics
            cv_errors(f) = sqrt(mean((test_o(:) - pred(:)).^2));
            ss_tot = sum((test_o(:) - mean(test_o(:))).^2);
            ss_res = sum((test_o(:) - pred(:)).^2);
            cv_r2(f) = 1 - ss_res / max(ss_tot, eps);

            fprintf(' RMSE=%.4f, R^2=%.4f\n', cv_errors(f), cv_r2(f));
        catch ME
            cv_errors(f) = inf; cv_r2(f) = -inf;
            fprintf(' [failed: %s]\n', ME.message);
        end
    end
end

%%% HELPER FUNCTION 3 %%%
function [all_dates, median_SEIR, low_SEIR, high_SEIR, sim_SEIR_all] = generate_forecast(optimal_params, meteo_data, alpha, forecast_days, initial_conditions, dates, bds, n_ensembles, jitter_pct, extend_mode, u_ts)
    if nargin < 9 || isempty(jitter_pct), jitter_pct = 0.10; end
    if nargin < 10 || isempty(extend_mode), extend_mode = 'persistence'; end

    rng(42,'twister');
    n_days = size(meteo_data,1); n_all = n_days + forecast_days; F = size(meteo_data,2);
    extended_meteo = zeros(n_all, F); extended_meteo(1:n_days,:) = meteo_data;

    switch lower(extend_mode)
        case 'trend'
            for f = 1:F
                recent = meteo_data(max(1,n_days-29):n_days, f);
                slope = (recent(end) - recent(1)) / max(1, numel(recent)-1);
                for j = 1:forecast_days
                    extended_meteo(n_days+j,f) = meteo_data(end,f) + slope*j;
                end
            end
        otherwise
            extended_meteo(n_days+1:end,:) = meteo_data(end,:);
    end

    % Extend u_ts by persistence for forecasting
    extended_u = [u_ts; repmat(u_ts(end), forecast_days, 1)];

    tspan = (1:n_all)';
    last_date = dates(end);
    forecast_dates = last_date + days(1:forecast_days);
    all_dates = [dates; forecast_dates(:)];
    extended_alpha = [alpha; repmat(alpha(end), forecast_days, 1)];

    % Build jitter bounds consistent with main lb/ub (18 params)
    coef_low  = -1; coef_high = 1;
    dcoef_low = -1e-6;  dcoef_high = 1e-6;
    lb = [bds.b_min, coef_low*ones(1,3), ...
          bds.r_min, coef_low*ones(1,3), ...
          bds.e_min, coef_low*ones(1,3), ...
          bds.d_min, dcoef_low*ones(1,3), ...
          bds.u_min, 0];
    ub = [bds.b_max, coef_high*ones(1,3), ...
          bds.r_max, coef_high*ones(1,3), ...
          bds.e_max, coef_high*ones(1,3), ...
          bds.d_max, dcoef_high*ones(1,3), ...
          bds.u_max, 0];

    P = numel(optimal_params);
    sim_SEIR_all = cell(n_ensembles,1);

    [S0,E0,I0,R0] = simulate_seir_model(optimal_params, extended_meteo, extended_alpha, tspan, initial_conditions, bds, extended_u);
    baseline = [S0,E0,I0,R0];
    sim_SEIR_all{1} = baseline;

    for k = 2:n_ensembles
        theta = optimal_params;
        for p = 1:min(P, numel(lb))
            theta(p) = theta(p) * (1 + jitter_pct*randn);
            theta(p) = min(max(theta(p), lb(p)), ub(p));
        end
        try
            [S,E,I,R] = simulate_seir_model(theta, extended_meteo, extended_alpha, tspan, initial_conditions, bds, extended_u);
            sim_SEIR_all{k} = [S,E,I,R];
        catch
            sim_SEIR_all{k} = baseline;
        end
    end

    S_mat = cat(3, sim_SEIR_all{:}); S_stack = squeeze(S_mat(:,1,:));
    E_stack = squeeze(S_mat(:,2,:)); I_stack = squeeze(S_mat(:,3,:)); R_stack = squeeze(S_mat(:,4,:));

    median_S = median(S_stack,2,'omitnan'); lo_S = quantile(S_stack,0.025,2); hi_S = quantile(S_stack,0.975,2);
    median_E = median(E_stack,2,'omitnan'); lo_E = quantile(E_stack,0.025,2); hi_E = quantile(E_stack,0.975,2);
    median_I = median(I_stack,2,'omitnan'); lo_I = quantile(I_stack,0.025,2); hi_I = quantile(I_stack,0.975,2);
    median_R = median(R_stack,2,'omitnan'); lo_R = quantile(R_stack,0.025,2); hi_R = quantile(R_stack,0.975,2);

    median_SEIR = [median_S, median_E, median_I, median_R];
    low_SEIR    = [lo_S,     lo_E,     lo_I,     lo_R];
    high_SEIR   = [hi_S,     hi_E,     hi_I,     hi_R];
end

%%% HELPER FUNCTION 4 %%%
function [rmse, mae, r2] = calculate_goodness_of_fit(observed, modeled)
    rmse = sqrt(mean((observed - modeled).^2, 1, 'omitnan'));
    mae  = mean(abs(observed - modeled), 1, 'omitnan');
    ss_res = sum((observed - modeled).^2, 1, 'omitnan');
    ss_tot = sum((observed - mean(observed, 1, 'omitnan')).^2, 1, 'omitnan');
    r2 = 1 - ss_res ./ max(ss_tot, eps);
    r2(~isfinite(r2)) = 0;
end

%%% HELPER FUNCTION 5 %%%
function [S, E, I, R, u_eff] = simulate_seir_model(params, meteo_data, alpha, ...
                                                   tspan, initial_conditions, bds, ...
                                                   u_series)
% SIMULATE_SEIR_MODEL (4-state, normalized)

    % ---- unpack params
    beta_params  = params( 1: 4);
    rho_params   = params( 5: 8);
    eps_params   = params( 9:12);
    delta_params = params(13:16);
    u_scale      = params(17);

    % ---- guards / defaults
    n = size(meteo_data,1);
    if nargin < 7 || isempty(u_series),  u_series  = zeros(n,1); end

    % default bounds for u if absent
    if ~isfield(bds,'u_min') || isempty(bds.u_min), bds.u_min = 0.05; end
    if ~isfield(bds,'u_max') || isempty(bds.u_max), bds.u_max = 0.95; end

    % ---- time-varying rates (log-linear meteorology effects)
    beta_t  = beta_params(1)  * exp(meteo_data * beta_params(2:4)');
    rho_t   = rho_params(1)   * exp(meteo_data * rho_params(2:4)');
    eps_t   = eps_params(1)   * exp(meteo_data * eps_params(2:4)');
    delta_t = delta_params(1) * exp(meteo_data * delta_params(2:4)');

    % clamp & repair 
    safebound = @(x,lo,hi) min(max(fillmissing(fillmissing(x,'previous'),'next'),lo),hi);
    beta_t  = safebound(beta_t,  bds.b_min, bds.b_max);
    rho_t   = safebound(rho_t,   bds.r_min, bds.r_max);
    eps_t   = safebound(eps_t,   bds.e_min, bds.e_max);
    delta_t = safebound(delta_t, bds.d_min, bds.d_max);

    % ---- interventions (scaled & clamped)
    u_eff = u_scale .* u_series(:);
    u_eff = min(max(u_eff, bds.u_min), bds.u_max);

    % Ensure alpha matches tspan length
    n_tspan = numel(tspan);
    n_alpha = numel(alpha);
    
    if isscalar(alpha)
        alpha = repmat(alpha, n_tspan, 1);
    elseif n_alpha == n_tspan
        alpha = alpha(:);   
    elseif n_alpha < n_tspan
        alpha_extended = [alpha(:); repmat(alpha(end), n_tspan - n_alpha, 1)];
        alpha = alpha_extended;
    else
        alpha = alpha(1:n_tspan);
    end

    % ---- initial conditions (normalized)
    y0 = initial_conditions(:)';           % [S0,E0,I0,R0] 
    if ~isfinite(sum(y0)) || sum(y0) <= 0, y0 = [0.99, 0.005, 0.005, 0]; end
    y0 = y0 ./ sum(y0);

    % ---- dimension checks
    need = [n_tspan, size(beta_t,1), size(rho_t,1), size(eps_t,1), ...
            size(delta_t,1), numel(u_eff), numel(alpha)];
    if any(need ~= need(1))
        error('Length mismatch: t=%d, beta=%d, rho=%d, epsilon=%d, delta=%d, u=%d, alpha=%d', need);
    end

    % ---- ODE solve
    dt = median(diff(tspan));
    opts = odeset( ...
    'RelTol',1e-5, ...
    'AbsTol',1e-8, ...
    'MaxStep', max(1,2*dt), ...
    'NonNegative',1:4);
    rhs  = @(t,y) seir_rhs_4state(t, y, tspan, beta_t, rho_t, eps_t, delta_t, alpha, u_eff);

    try
        [~, Y] = ode15s(rhs, tspan, y0, opts);
        S = Y(:,1); E = Y(:,2); I = Y(:,3); R = Y(:,4);   % R equals r_c
    catch ME
        warning('SEIR:SolverFailed','SEIR solver failed: %s', ME.message);
        nd = numel(tspan); S=nan(nd,1); E=nan(nd,1); I=nan(nd,1); R=nan(nd,1);
    end
end

%%% HELPER FUNCTION 6 %%%
function dydt = seir_rhs_4state(t, y, tgrid, beta_t, rho_t, eps_t, delta_t, alpha, u_t)
    % ---- interpolate safely (stiff-safe)
    b = interp1(tgrid, beta_t,  t, 'pchip', 'extrap');
    r = interp1(tgrid, rho_t,   t, 'pchip', 'extrap');
    e = interp1(tgrid, eps_t,   t, 'pchip', 'extrap');
    d = interp1(tgrid, delta_t, t, 'pchip', 'extrap');
    u = interp1(tgrid, u_t,     t, 'pchip', 'extrap');
    a = interp1(tgrid, alpha,   t, 'pchip', 'extrap');

    % ---- States (positivity enforced)
    S = max(y(1),0);
    E = max(y(2),0);
    I = max(y(3),0);
    R = max(y(4),0);

    % ---- Effective transmission
    beff = (1 - u) * b;

    % ---- Normalized SEIR with deaths
    dS = a*(1 - S) - beff*S*I + d*I*S;
    dE = beff*S*I - (e + a)*E + d*I*E;
    dI = e*E - (r + d + a)*I - d*I^2;
    dR = r*I - (a - d*I)*R;

    dydt = [dS; dE; dI; dR];
end

%%% HELPER FUNCTION 7 %%%
function err = seir_objective_function(params, meteo_data, observed_data, ...
                                       alpha, tspan, verbose, ...
                                       computed_param, init_cond, bds, ...
                                       u_series)

    % ----- defaults / guards
    if nargin < 9 || isempty(bds)
      error('Missing required argument: bds (bounds struct must be provided).'); end
    if nargin < 8  || isempty(init_cond),      init_cond      = observed_data(1,:); end
    if nargin < 7  || isempty(computed_param), computed_param = [];                 end
    if nargin < 10 || isempty(u_series),       u_series       = zeros(size(meteo_data,1),1); end

    try
        % ----- simulate model (Helper 5)
        init = init_cond(:)';   % [S0,E0,I0,R0] 
        [S,E,I,R] = simulate_seir_model(params, meteo_data, alpha, ...
                                        tspan, init, bds, u_series);
        if any(isnan(S)) || numel(S) ~= size(observed_data,1)
            err = 1e6; return;
        end
        model = [S,E,I,R];     

        % -----  State loss (Huber) 
        % 1.) Residuals
        res = (observed_data - model);   % [T x 4], columns = [S,E,I,R]

        % 2) State-level weights (relative importance of compartments)
        %    [S,   E,    I,    R]
        w_state = [0.05, 0.40, 0.50, 0.05];

        % 3) Time-level weights (higher during outbreak peak)
        I_obs   = observed_data(:,3);                % Infectious column
        I_max   = max(I_obs + eps);                  % Avoid division by zero
        rel_I   = I_obs ./ I_max;                    % Normalize to [0,1]
        time_w  = 1 + 4 * rel_I;                     % Scale 

        % 4) Combine state and time weights
        W_state = repmat(w_state, size(res,1), 1);  
        W_time  = repmat(time_w, 1, 4);              
        W_full  = W_state .* W_time;                 

        % 5) Huber threshold 
        deltaH = 4 * std(res(:), 'omitnan');
        if ~isfinite(deltaH) || deltaH == 0
            deltaH = 1e-3;
        end

        % 6) Huber loss computation
        absr  = abs(res);
        huber = (absr <= deltaH) .* (0.5 .* res.^2) + ...
                (absr >  deltaH) .* (deltaH .* (absr - 0.5 * deltaH));

        % 7) Weighted mean root error across all states and time points
        state_err = sqrt( mean(huber .* W_full, 'all', 'omitnan') );

        % ----- parameter-trajectory penalty 
        lambda_params = 0.05;
        cp = computed_param;

        % Reconstruct param trajectories
        beta_params  = params( 1: 4);
        rho_params   = params( 5: 8);
        eps_params   = params( 9:12);
        delta_params = params(13:16);
        u_scale      = params(17);

        %  meteo effects 
        beta_env = beta_params(1)  * exp(meteo_data * beta_params(2:4)');
        rho_env   = rho_params(1)   * exp(meteo_data * rho_params(2:4)');
        eps_env   = eps_params(1)   * exp(meteo_data * eps_params(2:4)');
        delta_env = delta_params(1) * exp(meteo_data * delta_params(2:4)');

        %  bounds
        beta_env = max(min(beta_env, bds.b_max), bds.b_min);
        rho_env   = max(min(rho_env,   bds.r_max), bds.r_min);
        eps_env   = max(min(eps_env,   bds.e_max), bds.e_min);
        delta_env = max(min(delta_env, bds.d_max), bds.d_min);

        u_eff    = min(max(u_scale .* u_series(:), bds.u_min), bds.u_max);
        beta_env_eff = (1 - u_eff) .* beta_env;

        if ~isempty(cp)
            T = min(size(cp,1), numel(beta_env_eff));
            Pobs = cp(1:T, :);
            Pmod = [beta_env(1:T), eps_env(1:T), rho_env(1:T), u_eff(1:T), delta_env(1:T)];

            pres = Pobs - Pmod;
            wP = [1.0, 0.8, 0.8, 1.0, 0];          % no weight on delta
            wP = repmat(wP, T, 1);

            dH2 = 3*std(pres(:),'omitnan');
            if ~isfinite(dH2) || dH2==0, dH2 = 1e-3; end

            ap  = abs(pres);
            huber_p   = (ap<=dH2).*0.5.*pres.^2 + (ap>dH2).*(dH2*(ap - 0.5*dH2));
            param_err = sqrt(mean((huber_p .* wP), 'all', 'omitnan'));
        else
            param_err = 0;
        end

        % ----- smoothness penalty on rate paths 
        lambda_smooth = 0.002;     %  0.001–0.03
        sm = @(x) mean(diff(x).^2,'omitnan');
        smooth_pen = sm(beta_env_eff) + sm(rho_env) + sm(eps_env) + 0.2*sm(delta_env);

        reg = 0.01 * sqrt(mean(params.^2, 'omitnan'));

        err = state_err + lambda_params*param_err + lambda_smooth*smooth_pen + reg;
        if ~isfinite(err), err = 1e6; end

        if verbose
            fprintf('Objective=%.6f  (state=%.6f, param=%.6f, smooth=%.6f, reg=%.6f)\n', ...
                err, state_err, lambda_params*param_err, lambda_smooth*smooth_pen, reg);
        end

    catch ME
        warning('Objective failed: %s', getReport(ME,'basic','hyperlinks','off'));
        err = 1e6;
    end
end

%%% HELPER FUNCTION 8 %%%
function varargout = replaceBadValues(windowSize, varargin)
    n = numel(varargin);
    varargout = cell(1,n);

    for k = 1:n
        x = varargin{k};
        x(~isfinite(x)) = NaN;

        try
            x = fillmissing(x, 'movmedian', max(3, windowSize));
        catch
            x = fillmissing(x, 'linear');
        end
 
        if numel(x) >= windowSize && mod(windowSize,2)==1
            try
                x = medfilt1(x, windowSize);
            catch
                x = movmean(x, windowSize, 'omitnan');
            end
        else
            x = movmean(x, max(3, floor(windowSize/2)*2+1), 'omitnan');
        end

        x(~isfinite(x)) = nan;
        x = fillmissing(x, 'nearest');
        varargout{k} = x;
    end
end

%%% HELPER FUNCTION 9 %%% 
function shaded_band_eps(ax, x, ylo, ymed, yhi, rgb, title_str, ylab_sym, mix)
    if nargin < 9, mix = 0.2; end
    hold(ax,'on');
    band = 1 - mix*(1 - rgb);                  
    x = x(:); ylo = ylo(:); ymed = ymed(:); yhi = yhi(:);
    fill(ax, [x; flipud(x)], [ylo; flipud(yhi)], band, 'EdgeColor','none');
    plot(ax, x, ymed, 'Color', rgb, 'LineWidth', 1.8);
    grid(ax,'on'); box(ax,'off');
    ylabel(ax, ylab_sym, 'Interpreter','none');
    title(ax, sprintf('%s (95%%%% band)', title_str), 'Interpreter','none');
    set(ax,'FontSize',9,'LineWidth',0.8);
end
