%%% LSTM-SEIR-FORECAST MODEL %%%
% NOTE: Ensure that the data file
% 'Epidemic and meteorological data_Nepal.xlsx'
% is located in the same folder.

%% ===================== PART A: Data Preprocessing =====================
fprintf('\n========== PART A: DATA PREPROCESSING ==========\n');

% 1) Load Data
data  = readtable('Epidemic and meteorological data_Nepal.xlsx');
I     = data.I;
R     = data.R_c;
DD    = data.Death_Daily;
N     = data.N_Living;
T2M   = data.T2M;
RH2M  = data.RH2M;
WS2M  = data.WS2M;
u_t   = data.u_t;
v_t   = data.v_t;
dates = data.Date;
n_days = height(data);

% 2) Weather features (6)
weather_features = [T2M, RH2M, WS2M, T2M.*RH2M, T2M.^2, RH2M.^2];

% 3) Birth rate by year
y = year(dates);
alpha = zeros(size(dates));
alpha(y==2020) = 5.65479e-05;
alpha(y==2021) = 5.60274e-05;
alpha(y==2022) = 5.52329e-05;

% 4) Settings
rho_0 = 1/5;
epsilon_0 = 1/7;
vaccine_efficacy = 0.60;

r_min = 1/28; r_max = 0.6;
e_min = 1/21; e_max = 0.6;
b_min = 5e-4; b_max = 1.6;
d_min = 0;    d_max = 1e-3;

time_lag   = 7;
span_param = 15;
polyorder  = 3;
windowSize = 14;

% 5) Intervention with lag
u_combined = 1 - (1 - u_t).*(1 - v_t.*vaccine_efficacy);
u_combined = min(max(u_combined, 0.05), 0.95);

u_pad = [nan(time_lag,1); u_combined(1:end-time_lag)];
u_ts  = movmean(u_pad, 14, 'omitnan','Endpoints','shrink');
u_ts  = fillmissing(u_ts,'nearest');
u_ts  = min(max(u_ts, 0.05), 0.95);

% 6) Weather lag
wf_pad = [nan(time_lag,6); weather_features(1:end-time_lag,:)];

% 7) Remove initial lag period
keep_idx = (time_lag+1):n_days;
dates = dates(keep_idx);
I     = I(keep_idx);
R     = R(keep_idx);
DD    = DD(keep_idx);
N     = N(keep_idx);
u_ts  = u_ts(keep_idx);
alpha = alpha(keep_idx);
weather_features = wf_pad(keep_idx,:);
n_days = numel(dates);

% 8) Smooth 
alpha            = max(sgolayfilt(alpha, polyorder, span_param), 0);
weather_smoothed = sgolayfilt(weather_features, polyorder, span_param);

I_s = max(sgolayfilt(I, polyorder, span_param), 0);
R_s = max(sgolayfilt(R, polyorder, span_param), 0);
D_s = max(movmean(DD, 14, 'omitnan'), 0);

% 9) DFI
delta_t = D_s ./ max(I_s, 1);
delta_t = sgolayfilt(delta_t, polyorder, span_param);
delta_t = min(max(delta_t, d_min), d_max);

% 10) Normalize
I_sn = min(max(I_s ./ N, 0), 1);
R_sn = min(max(R_s ./ N, 0), 1);

% 11) E estimation (3-method blend)
fprintf('Estimating Exposed (E) ...\n');
delta_I = [0; diff(I_sn)];
delta_I = sgolayfilt(delta_I, polyorder, span_param);

% M1 gamma convolution
incub_shape = 5.8; incub_scale = 0.9; max_incub_days = 21;
t_incub = 0:max_incub_days;
incub_kernel = gampdf(t_incub, incub_shape, incub_scale);
incub_kernel = incub_kernel / sum(incub_kernel);
E_method1 = conv(delta_I, incub_kernel, 'same') / epsilon_0;

% M2 growth multiplier
growth_rate = delta_I ./ max(I_sn, 1e-6);
growth_rate = sgolayfilt(growth_rate, polyorder, span_param);
E_to_I_multiplier = 1.5 + (1/epsilon_0) * growth_rate;
E_to_I_multiplier = min(max(E_to_I_multiplier, 1.2), 4.0);
E_method2 = I_sn .* E_to_I_multiplier;

% M3 model-based reconstruction
numerator = delta_I + (rho_0 + delta_t + alpha).*I_sn - delta_t.*(I_sn.^2);
E_method3 = numerator ./ max(epsilon_0, 1e-8);
E_method3 = sgolayfilt(E_method3, polyorder, span_param);
E_method3 = max(E_method3, 1e-6);

E_sn = 0.1*E_method1 + 0.2*E_method2 + 0.7*E_method3;
E_sn = sgolayfilt(E_sn, polyorder, span_param);
E_sn = max(E_sn, 1e-6);

% Ensure E > I 
needs_adjustment = (E_sn ./ max(I_sn,1e-6)) < 1;
E_sn(needs_adjustment) = 1.2 * I_sn(needs_adjustment);
fprintf('Adjusted %d time points to ensure E > I\n', sum(needs_adjustment));

% 12) Reconstruct S + renormalize
S_sn = 1 - E_sn - I_sn - R_sn;
TS   = max(S_sn + E_sn + I_sn + R_sn, 1e-6);
S_sn = S_sn./TS; E_sn = E_sn./TS; I_sn = I_sn./TS; R_sn = R_sn./TS;

% 13) Derivatives + Smoothing
dS_s = sgolayfilt(gradient(S_sn), polyorder, span_param);
dE_s = sgolayfilt(gradient(E_sn), polyorder, span_param);
dI_s = sgolayfilt(gradient(I_sn), polyorder, span_param);
dR_s = sgolayfilt(gradient(R_sn), polyorder, span_param);

% 14) Parameters (rho -> epsilon -> beta)
fprintf('Estimating parameters (rho -> epsilon -> beta)...\n');

% rho from dR
rho_SEIR = (dR_s + (alpha - delta_t .* I_sn).*R_sn) ./ max(I_sn,1e-6);
rho_SEIR = real(rho_SEIR);
rho_SEIR = fillmissing(rho_SEIR,'movmedian',windowSize);
rho_SEIR = min(max(rho_SEIR, r_min), r_max);

% epsilon from dI
epsilon_SEIR = (dI_s + (rho_SEIR + delta_t + alpha).*I_sn - delta_t.*I_sn.^2) ./ max(E_sn,1e-6);
epsilon_SEIR = real(epsilon_SEIR);
epsilon_SEIR = fillmissing(epsilon_SEIR,'movmedian',windowSize);
epsilon_SEIR = min(max(epsilon_SEIR, e_min), e_max);

% beta (intrinsic) from dE 
beta_SEIR = (dE_s + (epsilon_SEIR + alpha).*E_sn - delta_t.*I_sn.*E_sn) ./ max((1-u_ts).*S_sn.*I_sn, 1e-8);
beta_SEIR = real(beta_SEIR);
beta_SEIR = fillmissing(beta_SEIR,'movmedian',windowSize);
beta_SEIR = min(max(beta_SEIR, b_min), b_max);

% 15) Smooth + outlier repair + bounds
beta_SEIR    = sgolayfilt(beta_SEIR,    polyorder, span_param);
rho_SEIR     = sgolayfilt(rho_SEIR,     polyorder, span_param);
epsilon_SEIR = sgolayfilt(epsilon_SEIR, polyorder, span_param);

[beta_SEIR, rho_SEIR, epsilon_SEIR] = replaceBadValues(windowSize, beta_SEIR, rho_SEIR, epsilon_SEIR);

beta_SEIR    = min(max(beta_SEIR,    b_min), b_max);
rho_SEIR     = min(max(rho_SEIR,     r_min), r_max);
epsilon_SEIR = min(max(epsilon_SEIR, e_min), e_max);

fprintf('PART A COMPLETE\n\n');

%% ===================== PART B: LSTM Training =====================
fprintf('========== PART B: LSTM TRAINING (MULTI-TASK) ==========\n');

% 1 ----- Build feature table (15 features) -----
featureNames = {'S_sn','E_sn','I_sn','R_sn','beta_SEIR','rho_SEIR','epsilon_SEIR', ...
                'u_ts','delta_t','T2M','RH2M','WS2M','TRH','TT','RHRH'};

combinedData = table( ...
    S_sn,E_sn,I_sn,R_sn, beta_SEIR,rho_SEIR,epsilon_SEIR, ...
    u_ts,delta_t, ...
    weather_smoothed(:,1),weather_smoothed(:,2),weather_smoothed(:,3), ...
    weather_smoothed(:,4),weather_smoothed(:,5),weather_smoothed(:,6), ...
    'VariableNames', featureNames);

DM = table2array(combinedData);

% 2 ----- Sequence settings -----
seqlnth     = 14;
numFeatures = size(DM,2);
numSamples  = n_days - seqlnth;

% 3 ----- Build sequences & targets -----
X      = zeros(numSamples, seqlnth, numFeatures);
Y_comb = zeros(numSamples, 7);
for i = 1:numSamples
    X(i,:,:)    = DM(i:i+seqlnth-1, :);
    Y_comb(i,:) = DM(i+seqlnth, [5 6 7 1 2 3 4]); % [beta rho eps S E I R]
end
pred_time_indices = seqlnth + (1:numSamples);

% 4 ----- Train/Validation split -----
trainRatio = 0.85;
nTrain = floor(trainRatio * numSamples);

XTrain = X(1:nTrain,:,:);
YTrain = Y_comb(1:nTrain,:);

XVal   = X(nTrain+1:end,:,:);
YVal   = Y_comb(nTrain+1:end,:);

% 5 ----- Normalize features -----
Xtr = reshape(XTrain, [], numFeatures);
fm  = mean(Xtr, 1);
fs  = std(Xtr, 0, 1);  fs(fs==0) = 1;

XTrainN = (XTrain - reshape(fm,[1,1,numFeatures])) ./ reshape(fs,[1,1,numFeatures]);
XValN   = (XVal   - reshape(fm,[1,1,numFeatures])) ./ reshape(fs,[1,1,numFeatures]);

% 6 ----- Convert to cell -----
XTrainC = cell(nTrain,1);
for i = 1:nTrain, XTrainC{i} = squeeze(XTrainN(i,:,:))'; end

nVal = size(XValN,1);
XValC = cell(nVal,1);
for i = 1:nVal, XValC{i} = squeeze(XValN(i,:,:))'; end

% 7 ----- Normalize targets -----
pm = mean(YTrain, 1);
ps = std(YTrain, 0, 1);  ps(ps==0) = 1;

YTrainN = (YTrain - pm) ./ ps;
YValN   = (YVal   - pm) ./ ps;

% 8 ----- Network -----
layers = [
    sequenceInputLayer(numFeatures)
    bilstmLayer(64,'OutputMode','sequence')
    dropoutLayer(0.3)
    lstmLayer(96,'OutputMode','last')
    dropoutLayer(0.25)
    fullyConnectedLayer(64)
    reluLayer
    dropoutLayer(0.2)
    fullyConnectedLayer(32)
    reluLayer
    dropoutLayer(0.15)
    fullyConnectedLayer(7)
    regressionLayer
];
% 9 ----- Options -----
opts = trainingOptions('adam', ...
    'MaxEpochs',           300, ...
    'MiniBatchSize',       32, ...
    'InitialLearnRate',    5e-4, ...
    'LearnRateSchedule',   'piecewise', ...
    'LearnRateDropFactor', 0.5, ...
    'LearnRateDropPeriod', 30, ...
    'ValidationData',      {XValC, YValN}, ...
    'Shuffle',             'every-epoch', ...
    'ValidationFrequency', 10, ...
    'ValidationPatience',  20, ...
    'L2Regularization',    0.01, ...
    'GradientThreshold',   3, ...
    'OutputNetwork',       'best-validation-loss', ...
    'Plots',               'training-progress', ...
    'Verbose',             0);

fprintf('Training Multi-Task BiLSTM...\n');
net = trainNetwork(XTrainC, YTrainN, layers, opts);

% 10 ----- Full-period prediction -----
XFullN = (X - reshape(fm,[1,1,numFeatures])) ./ reshape(fs,[1,1,numFeatures]);
XFullC = cell(size(XFullN,1),1);
for i = 1:size(XFullN,1), XFullC{i} = squeeze(XFullN(i,:,:))'; end

YhatN = double(predict(net, XFullC));
Yhat  = YhatN .* ps + pm;

beta_pred    = Yhat(:,1);  % intrinsic
rho_pred     = Yhat(:,2);
epsilon_pred = Yhat(:,3);

S_pred_lstm = Yhat(:,4);
E_pred_lstm = Yhat(:,5);
I_pred_lstm = Yhat(:,6);
R_pred_lstm = Yhat(:,7);

% Remove outliers, and Bounds 
[beta_pred, rho_pred, epsilon_pred] = replaceBadValues(windowSize, beta_pred, rho_pred, epsilon_pred);

beta_pred    = min(max(beta_pred,    b_min), b_max);
rho_pred     = min(max(rho_pred,     r_min), r_max);
epsilon_pred = min(max(epsilon_pred, e_min), e_max);

% Effective beta 
beta_pred_eff = (1 - u_ts(pred_time_indices)) .* beta_pred;

beta_pred_full    = nan(n_days,1);
rho_pred_full     = nan(n_days,1);
epsilon_pred_full = nan(n_days,1);

S_pred_lstm_full  = nan(n_days,1);
E_pred_lstm_full  = nan(n_days,1);
I_pred_lstm_full  = nan(n_days,1);
R_pred_lstm_full  = nan(n_days,1);

beta_pred_full(pred_time_indices)    = beta_pred;
rho_pred_full(pred_time_indices)     = rho_pred;
epsilon_pred_full(pred_time_indices) = epsilon_pred;

S_pred_lstm_full(pred_time_indices)  = S_pred_lstm;
E_pred_lstm_full(pred_time_indices)  = E_pred_lstm;
I_pred_lstm_full(pred_time_indices)  = I_pred_lstm;
R_pred_lstm_full(pred_time_indices)  = R_pred_lstm;

fprintf('PART B COMPLETE\n\n');

%% ===================== PART C: ODE Integration =====================
fprintf('========== PART C: ODE INTEGRATION ==========\n');

t_all = (1:n_days)';
T0    = seqlnth;

x0_init = [S_sn(T0); E_sn(T0); I_sn(T0); R_sn(T0)];
x0_init = x0_init / max(sum(x0_init), 1e-12);

% Direct replacement
beta_comb = beta_SEIR;
rho_comb  = rho_SEIR;
eps_comb  = epsilon_SEIR;

% Replace with LSTM after T0
idx_after_T0 = pred_time_indices >= T0+1;
if any(idx_after_T0)
    beta_comb(pred_time_indices(idx_after_T0)) = beta_pred(idx_after_T0);
    rho_comb(pred_time_indices(idx_after_T0))  = rho_pred(idx_after_T0);
    eps_comb(pred_time_indices(idx_after_T0))  = epsilon_pred(idx_after_T0);
end

% outlier repair 
beta_comb = fillmissing(beta_comb, 'movmedian', windowSize);
rho_comb  = fillmissing(rho_comb,  'movmedian', windowSize);
eps_comb  = fillmissing(eps_comb,  'movmedian', windowSize);

% Bounds
beta_comb = min(max(beta_comb, b_min), b_max);
rho_comb  = min(max(rho_comb,  r_min), r_max);
eps_comb  = min(max(eps_comb,  e_min), e_max);

% Interpolation functions
beta_fn    = @(tt) interp1(t_all, beta_comb, tt, 'makima', beta_comb(end));
rho_fn     = @(tt) interp1(t_all, rho_comb,  tt, 'makima', rho_comb(end));
epsilon_fn = @(tt) interp1(t_all, eps_comb,  tt, 'makima', eps_comb(end));

u_fn     = @(tt) min(max(interp1(t_all, u_ts,    tt, 'pchip', u_ts(end)), 0), 0.95);
delta_fn = @(tt) max(interp1(t_all, delta_t, tt, 'pchip', delta_t(end)), 0);
alpha_fn = @(tt) max(interp1(t_all, alpha,   tt, 'pchip', alpha(end)),   0);

%  Tolerances 
tspan_ode = (T0:n_days)';
opts_ode  = odeset('RelTol', 1e-9, ...
                   'AbsTol', 1e-11, ...
                   'MaxStep', 0.1, ...  
                   'NonNegative', 1:4);  

% ode15s
[~, y_sol] = ode15s(@(t,y) seir_ode_fixed(t,y,beta_fn,rho_fn,epsilon_fn, ...
                                           u_fn,delta_fn,alpha_fn), ...
                    tspan_ode, x0_init, opts_ode);

% Normalize
TS_ode = max(sum(y_sol,2), 1e-12);
y_sol  = y_sol ./ TS_ode;

S_ode = y_sol(:,1);
E_ode = y_sol(:,2);
I_ode = y_sol(:,3);
R_ode = y_sol(:,4);

% Construct full prediction
S_pred_ode = [S_sn(1:T0-1); S_ode];
E_pred_ode = [E_sn(1:T0-1); E_ode];
I_pred_ode = [I_sn(1:T0-1); I_ode];
R_pred_ode = [R_sn(1:T0-1); R_ode];

fprintf('PART C COMPLETE (Direct LSTM parameters from T0+1)\n\n');

%% ===================== PART D: Metrics =====================
fprintf('========== PART D: METRICS ==========\n');

valid_idx = pred_time_indices;

[mae_b, rmse_b, r2_b] = compute_metrics(beta_SEIR(valid_idx),    beta_pred);
[mae_r, rmse_r, r2_r] = compute_metrics(rho_SEIR(valid_idx),     rho_pred);
[mae_e, rmse_e, r2_e] = compute_metrics(epsilon_SEIR(valid_idx), epsilon_pred);

[mae_S_lstm, rmse_S_lstm, r2_S_lstm] = compute_metrics(S_sn(valid_idx), S_pred_lstm);
[mae_E_lstm, rmse_E_lstm, r2_E_lstm] = compute_metrics(E_sn(valid_idx), E_pred_lstm);
[mae_I_lstm, rmse_I_lstm, r2_I_lstm] = compute_metrics(I_sn(valid_idx), I_pred_lstm);
[mae_R_lstm, rmse_R_lstm, r2_R_lstm] = compute_metrics(R_sn(valid_idx), R_pred_lstm);

ode_idx = (T0:n_days)'; 
[mae_S_ode, rmse_S_ode, r2_S_ode] = compute_metrics(S_sn(ode_idx), S_pred_ode(ode_idx));
[mae_E_ode, rmse_E_ode, r2_E_ode] = compute_metrics(E_sn(ode_idx), E_pred_ode(ode_idx));
[mae_I_ode, rmse_I_ode, r2_I_ode] = compute_metrics(I_sn(ode_idx), I_pred_ode(ode_idx));
[mae_R_ode, rmse_R_ode, r2_R_ode] = compute_metrics(R_sn(ode_idx), R_pred_ode(ode_idx));

fprintf('\n--- Parameter Predictions (LSTM) ---\n');
fprintf('beta: MAE=%.5f | RMSE=%.5f | R²=%.4f\n', mae_b, rmse_b, r2_b);
fprintf('rho: MAE=%.5f | RMSE=%.5f | R²=%.4f\n', mae_r, rmse_r, r2_r);
fprintf('epsilon: MAE=%.5f | RMSE=%.5f | R²=%.4f\n', mae_e, rmse_e, r2_e);

fprintf('\n--- State Predictions (Direct LSTM) ---\n');
fprintf('S: MAE=%.6f | RMSE=%.6f | R²=%.4f\n', mae_S_lstm, rmse_S_lstm, r2_S_lstm);
fprintf('E: MAE=%.6f | RMSE=%.6f | R²=%.4f\n', mae_E_lstm, rmse_E_lstm, r2_E_lstm);
fprintf('I: MAE=%.6f | RMSE=%.6f | R²=%.4f\n', mae_I_lstm, rmse_I_lstm, r2_I_lstm);
fprintf('R: MAE=%.6f | RMSE=%.6f | R²=%.4f\n', mae_R_lstm, rmse_R_lstm, r2_R_lstm);

fprintf('\n--- State Predictions (ODE Integration, T0:end) ---\n');
fprintf('S: MAE=%.6f | RMSE=%.6f | R²=%.4f\n', mae_S_ode, rmse_S_ode, r2_S_ode);
fprintf('E: MAE=%.6f | RMSE=%.6f | R²=%.4f\n', mae_E_ode, rmse_E_ode, r2_E_ode);
fprintf('I: MAE=%.6f | RMSE=%.6f | R²=%.4f\n', mae_I_ode, rmse_I_ode, r2_I_ode);
fprintf('R: MAE=%.6f | RMSE=%.6f | R²=%.4f\n', mae_R_ode, rmse_R_ode, r2_R_ode);

%% ===================== PART E: Forecast with R_t Calculation =====================
fprintf('\n========== PART E: FORECAST WITH R_t ==========\n');

forecast_days = 60;

u_future     = u_ts(end);
delta_future = delta_t(end);

% DOY climatology weather
startF  = dates(end) + days(1);
doyF    = day(startF + days(0:forecast_days-1), 'dayofyear')';
doyHist = day(dates, 'dayofyear');

Wdim = size(weather_smoothed,2);
W_doy_mean = nan(366, Wdim);
for d = 1:366
    idx = (doyHist == d);
    if any(idx), W_doy_mean(d,:) = mean(weather_smoothed(idx,:), 1, 'omitnan'); end
end

weather_future = zeros(forecast_days, Wdim);
for k = 1:forecast_days
    d = doyF(k);
    if all(isfinite(W_doy_mean(d,:))), weather_future(k,:) = W_doy_mean(d,:);
    else, weather_future(k,:) = weather_smoothed(end,:);
    end
end

win_raw = DM(end-seqlnth+1:end, :);
xwin    = ((win_raw - fm) ./ fs)';

S_forecast = zeros(forecast_days,1);
E_forecast = zeros(forecast_days,1);
I_forecast = zeros(forecast_days,1);
R_forecast = zeros(forecast_days,1);

for k = 1:forecast_days
    yhatN = double(predict(net, {xwin}));
    yhat  = yhatN .* ps + pm;

    b = min(max(yhat(1), b_min), b_max);
    r = min(max(yhat(2), r_min), r_max);
    e = min(max(yhat(3), e_min), e_max);

    S = min(max(yhat(4),0),1);
    E = min(max(yhat(5),0),1);
    I = min(max(yhat(6),0),1);
    Rr = min(max(yhat(7),0),1);

    TS = max(S+E+I+Rr, 1e-12);
    S = S/TS; E = E/TS; I = I/TS; Rr = Rr/TS;

    S_forecast(k)=S; E_forecast(k)=E; I_forecast(k)=I; R_forecast(k)=Rr;

    next_row  = [S,E,I,Rr, b,r,e, u_future,delta_future, weather_future(k,:)];
    next_rowN = (next_row - fm) ./ fs;
    xwin = [xwin(:,2:end), next_rowN(:)];
end

% R_t at last data day 
last_day   = n_days;
beta_last  = beta_pred(end);
rho_last   = rho_pred(end);
eps_last   = epsilon_pred(end);
alpha_last = alpha(last_day);
delta_last = delta_t(last_day);
u_last     = u_ts(last_day);
S_last     = S_pred_lstm(end);

R0  = (beta_last * eps_last) / ((eps_last + alpha_last) * (rho_last + delta_last + alpha_last));
R_t = R0 * (1 - u_last) * S_last;

fprintf('Effective Reproduction Number at forecast start (day %d):\n', last_day);
fprintf('  R_t = %.4f\n', R_t);

if R_t < 1
    stability_status = 'Disease-Free Equilibrium (DFE) - Epidemic declining';
    marker_color = [0 0.7 0];
elseif R_t < 1.5
    stability_status = 'Near-threshold - Endemic Equilibrium (EE) possible';
    marker_color = [1 0.6 0];
else
    stability_status = 'Endemic Equilibrium (EE) - Epidemic growing';
    marker_color = [0.9 0 0];
end

fprintf('  Stability: %s\n', stability_status);
fprintf('Forecast complete: %d days (Direct LSTM recursive + DOY weather)\n', forecast_days);

%% ===================== PART F: Visualization =====================
fprintf('\n========== PART F: VISUALIZATION ==========\n');

time_data = (1:n_days)'; 
figs = {};
fignames = {};

labelFS  = 11;
metricFS = 9;
legendFS = 9;
setAxesBold = @(ax) set(ax,'FontSize',9,'LineWidth',0.9,'Box','on');

% ---  bold Greek for titles  ---
betaChar = char(946);                 % beta
rhoChar  = char(961);                 % rho
vepsChar = char(hex2dec('03F5'));     %  var-epsilon. 

%% F1: Parameters (Computed vs LSTM)

figs{end+1} = figure('Name','F1_Parameters','Color','w','Position',[40,40,500,400]);
fignames{end+1} = 'F1_Parameters';

subplot(3,1,1);
plot(time_data, beta_SEIR, '-b','LineWidth',1.8); hold on;
plot(time_data, beta_pred_full, '--r','LineWidth',1.8);
xline(T0,':k','LineWidth',1.4); grid on;
ylabel([betaChar  '(Transmission)'], 'Interpreter','none','FontSize',labelFS,'FontWeight','bold');
legend({'Computed','LSTM'},'Location','best','FontSize',legendFS-3);
title(sprintf('%s: MAE=%.5f | RMSE=%.5f | R²=%.4f', ...
      betaChar, mae_b, rmse_b, r2_b), ...
      'Interpreter','none','FontSize',metricFS,'FontWeight','bold');
setAxesBold(gca);

subplot(3,1,2);
plot(time_data, rho_SEIR, '-b','LineWidth',1.8); hold on;
plot(time_data, rho_pred_full, '--r','LineWidth',1.8);
xline(T0,':k','LineWidth',1.4); grid on;
ylabel([rhoChar  '(Recovery)'], 'Interpreter','none','FontSize',labelFS,'FontWeight','bold');
legend({'Computed','LSTM'},'Location','best','FontSize',legendFS-3);
title(sprintf('%s: MAE=%.5f | RMSE=%.5f | R²=%.4f', ...
      rhoChar, mae_r, rmse_r, r2_r), ...
      'Interpreter','none','FontSize',metricFS,'FontWeight','bold');
setAxesBold(gca);

subplot(3,1,3);
plot(time_data, epsilon_SEIR, '-b','LineWidth',1.8); hold on;
plot(time_data, epsilon_pred_full, '--r','LineWidth',1.8);
xline(T0,':k','LineWidth',1.4); grid on;
ylabel([vepsChar  '(Incubation)'], 'Interpreter','none','FontSize',labelFS,'FontWeight','bold');
xlabel('Day','Interpreter','tex','FontSize',labelFS,'FontWeight','bold');
legend({'Computed','LSTM'},'Location','best','FontSize',legendFS-3);
title(sprintf('%s: MAE=%.5f | RMSE=%.5f | R²=%.4f', ...
      vepsChar, mae_e, rmse_e, r2_e), ...
      'Interpreter','none','FontSize',metricFS,'FontWeight','bold');
setAxesBold(gca);

%% F2: States (Data vs Direct LSTM)
figs{end+1} = figure('Name','F2_States_LSTM','Color','w','Position',[100,100,1100,750]);
fignames{end+1} = 'F2_States_LSTM';

subplot(2,2,1);
plot(time_data,S_sn,'-b','LineWidth',1.8); hold on;
plot(time_data,S_pred_lstm_full,'--r','LineWidth',1.8);
xline(T0,':k','LineWidth',1.4); grid on;
xlabel('Day','FontSize',labelFS,'FontWeight','bold','Interpreter','tex');
ylabel('Susceptible Fraction (S)','FontSize',labelFS,'FontWeight','bold','Interpreter','tex');
title(sprintf('S: MAE=%.6f | RMSE=%.6f | R^2=%.4f', mae_S_lstm, rmse_S_lstm, r2_S_lstm), ...
      'FontSize',metricFS,'FontWeight','bold','Interpreter','tex');
legend('Data','LSTM','Location','best','FontSize',legendFS); ylim([0.95 1]);
setAxesBold(gca);

subplot(2,2,2);
plot(time_data,E_sn,'-b','LineWidth',1.8); hold on;
plot(time_data,E_pred_lstm_full,'--r','LineWidth',1.8);
xline(T0,':k','LineWidth',1.4); grid on;
xlabel('Day','FontSize',labelFS,'FontWeight','bold','Interpreter','tex');
ylabel('Exposed Fraction (E)','FontSize',labelFS,'FontWeight','bold','Interpreter','tex');
title(sprintf('E: MAE=%.6f | RMSE=%.6f | R^2=%.4f', mae_E_lstm, rmse_E_lstm, r2_E_lstm), ...
      'FontSize',metricFS,'FontWeight','bold','Interpreter','tex');
legend('Estimated','LSTM','Location','best','FontSize',legendFS);
setAxesBold(gca);

subplot(2,2,3);
plot(time_data,I_sn,'-b','LineWidth',1.8); hold on;
plot(time_data,I_pred_lstm_full,'--r','LineWidth',1.8);
xline(T0,':k','LineWidth',1.4); grid on;
xlabel('Day','FontSize',labelFS,'FontWeight','bold','Interpreter','tex');
ylabel('Infected Fraction (I)','FontSize',labelFS,'FontWeight','bold','Interpreter','tex');
title(sprintf('I: MAE=%.6f | RMSE=%.6f | R^2=%.4f', mae_I_lstm, rmse_I_lstm, r2_I_lstm), ...
      'FontSize',metricFS,'FontWeight','bold','Interpreter','tex');
legend('Data','LSTM','Location','best','FontSize',legendFS);
setAxesBold(gca);

subplot(2,2,4);
plot(time_data,R_sn,'-b','LineWidth',1.8); hold on;
plot(time_data,R_pred_lstm_full,'--r','LineWidth',1.8);
xline(T0,':k','LineWidth',1.4); grid on;
xlabel('Day','FontSize',labelFS,'FontWeight','bold','Interpreter','tex');
ylabel('Recovered Fraction (R_c)','FontSize',labelFS,'FontWeight','bold','Interpreter','tex');
title(sprintf('R_c: MAE=%.6f | RMSE=%.6f | R^2=%.4f', mae_R_lstm, rmse_R_lstm, r2_R_lstm), ...
      'FontSize',metricFS,'FontWeight','bold','Interpreter','tex');
legend('Data','LSTM','Location','best','FontSize',legendFS);
setAxesBold(gca);

%% F3: States (Data vs ODE Integration) 
figs{end+1} = figure('Name','F3_States_ODE','Color','w','Position',[100,100,1100,750]);
fignames{end+1} = 'F3_States_ODE';

subplot(2,2,1);
plot(time_data,S_sn,'-b','LineWidth',1.8); hold on;
plot(time_data,S_pred_ode,'--r','LineWidth',1.8);
xline(T0,':k','LineWidth',1.4); grid on;
xlabel('Day','FontSize',labelFS,'FontWeight','bold','Interpreter','tex');
ylabel('Susceptible Fraction (S)','FontSize',labelFS,'FontWeight','bold','Interpreter','tex');
title(sprintf('S: MAE=%.6f | RMSE=%.6f | R^2=%.4f', mae_S_ode, rmse_S_ode, r2_S_ode), ...
      'FontSize',metricFS,'FontWeight','bold','Interpreter','tex');
legend('Data','ODE','Location','best','FontSize',legendFS); ylim([0.95 1]);
setAxesBold(gca);

subplot(2,2,2);
plot(time_data,E_sn,'-b','LineWidth',1.8); hold on;
plot(time_data,E_pred_ode,'--r','LineWidth',1.8);
xline(T0,':k','LineWidth',1.4); grid on;
xlabel('Day','FontSize',labelFS,'FontWeight','bold','Interpreter','tex');
ylabel('Exposed Fraction (E)','FontSize',labelFS,'FontWeight','bold','Interpreter','tex');
title(sprintf('E: MAE=%.6f | RMSE=%.6f | R^2=%.4f', mae_E_ode, rmse_E_ode, r2_E_ode), ...
      'FontSize',metricFS,'FontWeight','bold','Interpreter','tex');
legend('Estimated','ODE','Location','best','FontSize',legendFS);
setAxesBold(gca);

subplot(2,2,3);
plot(time_data,I_sn,'-b','LineWidth',1.8); hold on;
plot(time_data,I_pred_ode,'--r','LineWidth',1.8);
xline(T0,':k','LineWidth',1.4); grid on;
xlabel('Day','FontSize',labelFS,'FontWeight','bold','Interpreter','tex');
ylabel('Infected Fraction (I)','FontSize',labelFS,'FontWeight','bold','Interpreter','tex');
title(sprintf('I: MAE=%.6f | RMSE=%.6f | R^2=%.4f', mae_I_ode, rmse_I_ode, r2_I_ode), ...
      'FontSize',metricFS,'FontWeight','bold','Interpreter','tex');
legend('Data','ODE','Location','best','FontSize',legendFS);
setAxesBold(gca);

subplot(2,2,4);
plot(time_data,R_sn,'-b','LineWidth',1.8); hold on;
plot(time_data,R_pred_ode,'--r','LineWidth',1.8);
xline(T0,':k','LineWidth',1.4); grid on;
xlabel('Day','FontSize',labelFS,'FontWeight','bold','Interpreter','tex');
ylabel('Recovered Fraction (R_c)','FontSize',labelFS,'FontWeight','bold','Interpreter','tex');
title(sprintf('R_c: MAE=%.6f | RMSE=%.6f | R^2=%.4f', mae_R_ode, rmse_R_ode, r2_R_ode), ...
      'FontSize',metricFS,'FontWeight','bold','Interpreter','tex');
legend('Data','ODE','Location','best','FontSize',legendFS);
setAxesBold(gca);

%% F4: Forecast with R_t marker 
%% =====================================================================
figs{end+1} = figure('Name','F4_Forecast','Color','w','Position',[120,120,760,550]);
fignames{end+1} = 'F4_Forecast_Rt';

labelFS4  = 9;
tickFS4   = 8;
titleFS4  = 10;
legendFS4 = 8;

time_full = [time_data; time_data(end) + (1:forecast_days)'];
nHist = numel(time_data);
tF    = time_full(nHist+1:end);

S_hist = S_pred_lstm(:);
E_hist = E_pred_lstm(:);
I_hist = I_pred_lstm(:);
R_hist = R_pred_lstm(:);

Lhist = min([nHist,numel(S_hist),numel(E_hist),numel(I_hist),numel(R_hist)]);
tHist = time_data(1:Lhist);

S_hist = S_hist(1:Lhist);
E_hist = E_hist(1:Lhist);
I_hist = I_hist(1:Lhist);
R_hist = R_hist(1:Lhist);

S_fcst = S_forecast(:);
E_fcst = E_forecast(:);
I_fcst = I_forecast(:);
R_fcst = R_forecast(:);

time_plot = [tHist; tF];
S_full = [S_hist; S_fcst];
E_full = [E_hist; E_fcst];
I_full = [I_hist; I_fcst];
R_full = [R_hist; R_fcst];

% CI bands
W = min(60,Lhist); idxW = (Lhist-W+1):Lhist;
sigS = max(std(diff(S_hist(idxW)),'omitnan'),1e-6);
sigE = max(std(diff(E_hist(idxW)),'omitnan'),1e-6);
sigI = max(std(diff(I_hist(idxW)),'omitnan'),1e-6);
sigR = max(std(diff(R_hist(idxW)),'omitnan'),1e-6);

h = (1:forecast_days)'; kCI = 1.96; infl = sqrt(h);
S_lo = max(S_fcst - kCI*sigS.*infl,0); S_hi = min(S_fcst + kCI*sigS.*infl,1);
E_lo = max(E_fcst - kCI*sigE.*infl,0); E_hi = min(E_fcst + kCI*sigE.*infl,1);
I_lo = max(I_fcst - kCI*sigI.*infl,0); I_hi = min(I_fcst + kCI*sigI.*infl,1);
R_lo = max(R_fcst - kCI*sigR.*infl,0); R_hi = min(R_fcst + kCI*sigR.*infl,1);

cS=[0.00 0.45 0.74];
cE=[0.85 0.33 0.65];
cI=[0.85 0.10 0.10];
cR=[0.20 0.60 0.20];

% Axes positions
axS  = axes('Position',[0.10 0.71 0.86 0.20]); hold(axS,'on');
axEI = axes('Position',[0.10 0.39 0.86 0.23]); hold(axEI,'on');
axR  = axes('Position',[0.10 0.10 0.86 0.20]); hold(axR,'on');

% TOP: S
fill(axS,[tF;flipud(tF)],[S_lo;flipud(S_hi)],cS,...
     'FaceAlpha',0.12,'EdgeColor','none','HandleVisibility','off');
pS = plot(axS,time_plot,S_full,'-','LineWidth',1.6,'Color',cS,'DisplayName','S (LSTM)');
pFS_S = xline(axS,tHist(end),'--k','LineWidth',1.2,'DisplayName','Forecast Start');
ylabel(axS,'S','FontSize',labelFS4,'FontWeight','bold');
grid(axS,'on');
ylim(axS,[max(min(S_full)-0.004,0),min(max(S_full)+0.004,1)]);
set(axS,'FontSize',tickFS4,'LineWidth',0.8,'Box','on');

legS = legend(axS,[pS pFS_S],{'S (LSTM)','Forecast Start'},...
    'Orientation','horizontal','FontSize',legendFS4,'Location','northeast','Box','on');

% MIDDLE: E & I with R_t marker 
fill(axEI,[tF;flipud(tF)],[E_lo;flipud(E_hi)],cE,...
     'FaceAlpha',0.12,'EdgeColor','none','HandleVisibility','off');
fill(axEI,[tF;flipud(tF)],[I_lo;flipud(I_hi)],cI,...
     'FaceAlpha',0.12,'EdgeColor','none','HandleVisibility','off');

pE = plot(axEI,time_plot,E_full,'-','LineWidth',1.4,'Color',cE,'DisplayName','E (LSTM)');
pI = plot(axEI,time_plot,I_full,'-','LineWidth',1.4,'Color',cI,'DisplayName','I (LSTM)');
pFS_EI = xline(axEI,tHist(end),'--k','LineWidth',1.2,'DisplayName','Forecast Start');

% ---  R_t markers  ---
E_at_forecast = E_hist(end);
I_at_forecast = I_hist(end);

plot(axEI,tHist(end),E_at_forecast,'o','MarkerSize',5,'LineWidth',1.1,...
     'MarkerEdgeColor',marker_color,'MarkerFaceColor',marker_color,...
     'DisplayName',sprintf('R_t = %.3f',R_t));
plot(axEI,tHist(end),I_at_forecast,'o','MarkerSize',5,'LineWidth',1.1,...
     'MarkerEdgeColor',marker_color,'MarkerFaceColor',marker_color,...
     'HandleVisibility','off');

% R_t numeric annotation 
text(axEI,tHist(end)+15,max(E_at_forecast,I_at_forecast)*1.3,...
     sprintf('R_t = %.3f',R_t),...
     'FontSize',9,'FontWeight','bold','Color',marker_color,...
     'VerticalAlignment','bottom','Interpreter','none');

ylabel(axEI,'E, I','FontSize',labelFS4,'FontWeight','bold');
grid(axEI,'on');
ylim(axEI,[0,min(max([E_full;I_full])*1.3,1)]);
set(axEI,'FontSize',tickFS4,'LineWidth',0.8,'Box','on');

% Stability interpretation 
if R_t < 1
    status_msg = 'Equilibrium Status: Disease-Free Equilibrium (DFE) | R_t < 1: Epidemic declining, interventions effective';
elseif R_t < 1.5
    status_msg = 'Equilibrium Status: Near-threshold (Transitional) | 1 \le R_t < 1.5: Endemic Equilibrium (EE) possible, monitor closely';
else
    status_msg = 'Equilibrium Status: Endemic Equilibrium (EE) | R_t \ge 1.5: Epidemic growing, strengthen interventions';
end

yStatus = -0.10;
BULLET  = char(9679);   

%  Status text  
text(axEI,0.5,yStatus,status_msg,'Units','normalized',...
     'FontSize',8,'FontWeight','bold','Color','k',...
     'HorizontalAlignment','center','VerticalAlignment','top',...
     'Interpreter','none');

text(axEI,0.08,yStatus,BULLET,'Units','normalized',...
     'FontSize',8,'FontWeight','bold','Color',marker_color,...
     'HorizontalAlignment','center','VerticalAlignment','top',...
     'Interpreter','none');

% BOTTOM: R_c
fill(axR,[tF;flipud(tF)],[R_lo;flipud(R_hi)],cR,...
     'FaceAlpha',0.12,'EdgeColor','none','HandleVisibility','off');
pR = plot(axR,time_plot,R_full,'-','LineWidth',1.6,'Color',cR,'DisplayName','R_c (LSTM)');
pFS_R = xline(axR,tHist(end),'--k','LineWidth',1.2,'DisplayName','Forecast Start');

ylabel(axR,'R_c','FontSize',labelFS4,'FontWeight','bold');
xlabel(axR,'Day','FontSize',labelFS4,'FontWeight','bold');
grid(axR,'on');
ylim(axR,[0,min(max(R_full)*1.15,1)]);
set(axR,'FontSize',tickFS4,'LineWidth',0.8,'Box','on');

legR = legend(axR,[pR pFS_R],{'R_c (LSTM)','Forecast Start'},...
    'Orientation','horizontal','FontSize',legendFS4,'Location','northwest','Box','on');

% X-axis settings
xmaxWanted = max(tF(end),1200);
xt = [100 300 600 900 1200];
set([axS axEI axR],'XLim',[tHist(1) xmaxWanted]);
xticks(axR,xt);
set(axS,'XTickLabel',[]);
set(axEI,'XTickLabel',[]);
linkaxes([axS axEI axR],'x');

% Legend for E, I  
legEI = legend(axEI,[pE pI pFS_EI],...
    {'E (LSTM)','I (LSTM)','Forecast Start'},...
    'Orientation','horizontal','FontSize',legendFS4,'Location','northeast','Box','on');
%% Save figures 
outdir = 'figures';
if ~exist(outdir,'dir'), mkdir(outdir); end

for k = 1:numel(figs)
    if ~ishandle(figs{k}), continue; end
    basefile = fullfile(outdir, fignames{k});
    print(figs{k}, [basefile '.eps'], '-depsc', '-vector', '-r300');
    print(figs{k}, [basefile '.png'], '-dpng',  '-r300');
    print(figs{k}, [basefile '.pdf'], '-dpdf',  '-bestfit');
end

fprintf('\n========== COMPLETE ==========\nSaved EPS/PNG/PDF in "%s"\n', outdir);

%% ===================== Helper Functions =====================
% 1)
function varargout = replaceBadValues(windowSize, varargin)
    n = numel(varargin);
    varargout = cell(1,n);
    for k = 1:n
        x = varargin{k}(:);
        xm = movmedian(x, windowSize, 'omitnan');
        xa = movmad(x, windowSize, 1, 'omitnan'); xa(xa==0)=eps;
        out = abs(x - xm) > 3*xa;
        x(out) = xm(out);
        varargout{k} = x;
    end
end

% 2)
function dydt = seir_ode_fixed(t, y, beta_fn, rho_fn, epsilon_fn, u_fn, delta_fn, alpha_fn)
    y = max(min(y(:),1),0);
    S=y(1); E=y(2); I=y(3); R=y(4);

    beta    = max(beta_fn(t),    1e-8);      % intrinsic
    rho     = max(rho_fn(t),     1e-8);
    epsl    = max(epsilon_fn(t), 1e-8);
    u       = min(max(u_fn(t), 0), 0.95);
    delta   = max(delta_fn(t),   0);
    alpha   = max(alpha_fn(t),   0);

    lambda  = (1-u) * beta * S * I;

    % Model equation
    dS = alpha*(1-S) - lambda + delta*S*I;
    dE = lambda - (epsl+alpha)*E + delta*I*E;
    dI = epsl*E - (rho+delta+alpha)*I + delta*I^2;
    dR = rho*I - (alpha-delta*I)*R;

    dydt = [dS; dE; dI; dR];
end

% 3)
function [mae, rmse, r2] = compute_metrics(y, yhat)
    y = y(:); yhat = yhat(:);
    n = min(numel(y), numel(yhat));
    if n==0, mae=NaN; rmse=NaN; r2=NaN; return; end
    y = y(1:n); yhat = yhat(1:n);
    ok = isfinite(y) & isfinite(yhat);
    y = y(ok); yhat = yhat(ok);
    if isempty(y), mae=NaN; rmse=NaN; r2=NaN; return; end
    err = yhat - y;
    mae = mean(abs(err));
    rmse = sqrt(mean(err.^2));
    ssres = sum((y - yhat).^2);
    sstot = sum((y - mean(y)).^2) + eps;
    r2 = 1 - ssres/sstot;
end
