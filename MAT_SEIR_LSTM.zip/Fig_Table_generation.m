%% plot_figs_tables_from_mat.m
%  Displays Fig 1-4 on screen + prints Table 1-3 to command window.
%  No files are saved.
%
%  Usage (command window):
%      run('plot_figs_tables_from_mat.m')

clear; clc; close all;

%% Load
load('v29_figs_lean.mat');
fprintf('Loaded v29_figs_lean.mat  (n_days=%d)\n', n_days);

%% Shared display settings
chosenFont = 'Times New Roman';
set(groot,'DefaultAxesFontName',chosenFont,'DefaultTextFontName',chosenFont, ...
    'DefaultLegendFontName',chosenFont,'DefaultAxesFontWeight','bold', ...
    'DefaultTextInterpreter','tex','DefaultLegendInterpreter','tex', ...
    'DefaultAxesTickLabelInterpreter','tex');

bfs=9; lfs=7; LW=1.5; mkSz=4; lw_fcst=LW+1.2;
blendW=@(c,a) a.*c+(1-a).*ones(size(c));
sAx=@(ax) set(ax,'FontSize',bfs,'FontWeight','bold','LineWidth',1.0,'Box','on','TickLabelInterpreter','tex');
S_data={[0.00 0.18 0.45],'-','o',[0.00 0.18 0.45]};
S_lstm={[0.72 0.08 0.00],'--','^',[0.72 0.08 0.00]};
S_fcst={[0 0 0],'-.','d',[0 0 0]};
ci_blend=blendW([0.55 0.25 0.75],0.72);
ci_edge=[0.55 0.25 0.75]*0.70;
t_axis=(1:n_days)';
sp1=max(1,floor(n_days/18)); spH=sp1;

%% FIG 1 - Parameters
fig1=figure('Color','w','Position',[80 80 600 520],'PaperPositionMode','auto');
pLbl={'\beta(t)','\rho(t)','\epsilon(t)'};
pObs={beta_SEIR,rho_SEIR,epsilon_SEIR};
pPrd={beta_pred_full,rho_pred_full,epsilon_pred_full};
axF1=gobjects(1,3);
for k=1:3
    axF1(k)=subplot(3,1,k); hold on;
    yl_obs=[min(pObs{k})*0.88,max(pObs{k})*1.12];
    if diff(yl_obs)<1e-6, yl_obs=yl_obs+[-1e-4 1e-4]; end
    idx=1:sp1:n_days;
    plot(t_axis,pObs{k},'-','Color',S_data{1},'LineWidth',LW,'HandleVisibility','off');
    plot(idx,pObs{k}(idx),'o','Color',S_data{1},'MarkerFaceColor',S_data{1},'MarkerSize',mkSz,'DisplayName','SEIR (estimated)');
    vld_p=find(~isnan(pPrd{k}));
    if ~isempty(vld_p)
        plot(t_axis,pPrd{k},'--','Color',S_lstm{1},'LineWidth',LW,'HandleVisibility','off');
        idxL=vld_p(1):sp1:vld_p(end);
        plot(idxL,pPrd{k}(idxL),'s','Color',S_lstm{1},'MarkerFaceColor',S_lstm{1},'MarkerSize',mkSz,'DisplayName','SEIR-LSTM');
    end
    ylabel(pLbl{k},'FontSize',bfs+4,'FontWeight','bold','Interpreter','tex','Color',[0 0 0]);
    if k==3, xlabel('\bfDay','FontSize',bfs,'Interpreter','tex'); end
    ylim(yl_obs); grid off; sAx(gca);
    if k==1
        drawnow;
        lg1=legend('show','Box','off','FontSize',lfs+2);
        set(lg1,'AutoUpdate','off','FontName',chosenFont,'Interpreter','tex','Color','none','EdgeColor','none','TextColor',[0 0 0]);
        lg1.Units='normalized'; p1=axF1(1).Position;
        lg1.Position=[p1(1)+p1(3)-p1(3)*0.28-0.01,p1(2)+p1(4)*0.56,p1(3)*0.28,p1(4)*0.45];
    end
end
linkaxes(axF1,'x'); xlim(axF1(1),[1 n_days]);
set(findall(fig1,'-property','FontName'),'FontName',chosenFont);

%% FIG 2 - States + Forecast
forecast_days=numel(I_fc); t_fcst_ax=n_days+(1:forecast_days);
sObs={S_sn,E_sn,I_sn,R_sn}; sOde={S_ode_full,E_ode_full,I_ode_full,R_ode_full};
sFst={S_fc,E_fc,I_fc,R_fc}; sLbl={'\bfs','\bfe','\bfi','\bfr'};
fig2=figure('Color','w','Position',[80 80 600 560],'PaperPositionMode','auto');
axH=gobjects(1,4);
for k=1:4
    axH(k)=subplot(4,1,k); hold on;
    all_v=[sObs{k}(:);sFst{k}(:);sOde{k}(isfinite(sOde{k}))];
    all_v=all_v(isfinite(all_v)&all_v>=0);
    dr=max(all_v)-min(all_v); pad=max(0.05*dr,1e-5); yl_hi=max(all_v)+pad;
    if k==2||k==3, yl_lo=-0.04*dr; else, yl_lo=max(0,min(all_v)-pad); end
    if yl_hi<=yl_lo+1e-8, yl_hi=yl_lo+1e-3; end
    if k==3
        x=t_fcst_ax; ylo=I_ci_lo(:)'; yhi=I_ci_hi(:)';
        valid=isfinite(x)&isfinite(ylo)&isfinite(yhi);
        if any(valid)
            xv=[x(valid),fliplr(x(valid))]; yv=[ylo(valid),fliplr(yhi(valid))];
            fill(gca,xv,yv,ci_blend,'FaceAlpha',1.0,'EdgeColor','none','LineWidth',0.5,'HandleVisibility','off');
        end
    end
    idxH=1:spH:n_days;
    plot(t_axis,sObs{k},'-','Color',S_data{1},'LineWidth',LW,'HandleVisibility','off');
    plot(t_axis(idxH),sObs{k}(idxH),'o','Color',S_data{1},'MarkerFaceColor',S_data{1},'MarkerSize',mkSz,'DisplayName','Observed/Estimated');
    vld_ode=find(~isnan(sOde{k}));
    if ~isempty(vld_ode)
        sp_ode=max(1,floor(numel(vld_ode)/18));
        plot(vld_ode,sOde{k}(vld_ode),'--','Color',S_lstm{1},'LineWidth',LW,'HandleVisibility','off');
        plot(vld_ode(1:sp_ode:end),sOde{k}(vld_ode(1:sp_ode:end)),'^','Color',S_lstm{1},'MarkerFaceColor',S_lstm{1},'MarkerSize',mkSz,'DisplayName','ODE (SEIR-LSTM)');
    end
    plot([t_axis(end);t_fcst_ax(:)],[sObs{k}(end);sFst{k}(:)],'-.','Color',S_fcst{1},'LineWidth',lw_fcst,'DisplayName','Forecast');
    if k==3
        patch([NaN NaN],[NaN NaN],ci_blend,'FaceAlpha',1.0,'EdgeColor',ci_edge,'DisplayName','95% Bootstrap CI');
        Rt_at_end=Rt_NGM_full(find(~isnan(Rt_NGM_full),1,'last'));
        if isnan(Rt_at_end), Rt_at_end=1.0; end
        I_at_end=I_sn(n_days); yr=yl_hi-yl_lo;
        x_txt=n_days-0.06*(n_days-1); y_txt=I_at_end+0.13*yr;
        plot(n_days,I_at_end,'ko','MarkerSize',5,'MarkerFaceColor','w','LineWidth',1.2,'HandleVisibility','off');
        quiver(x_txt,y_txt,n_days-x_txt,I_at_end+0.04*yr-y_txt,'k','LineWidth',0.9,'MaxHeadSize',0.5,'AutoScale','off','HandleVisibility','off');
        text(x_txt,y_txt+0.03*yr,sprintf('R_t = %.3f',Rt_at_end),'FontSize',lfs,'FontName',chosenFont,'FontWeight','bold','HorizontalAlignment','center','VerticalAlignment','bottom','Interpreter','tex');
    end
    xline(n_days,'--k','LineWidth',1.0,'HandleVisibility','off');
    ylabel(sLbl{k},'FontSize',bfs+1,'FontWeight','bold','Interpreter','tex');
    if k==4, xlabel('\bfDay','FontSize',bfs,'Interpreter','tex'); end
    ylim([yl_lo,yl_hi]); grid off; sAx(gca);
end
linkaxes(axH,'x'); xlim(axH(1),[1,n_days+forecast_days+5]); drawnow;
lg2=legend(axH(3),'show','Box','off','FontSize',lfs+1);
set(lg2,'AutoUpdate','off','FontName',chosenFont,'Interpreter','tex','Color','none','EdgeColor','none','TextColor',[0 0 0]);
lg2.Units='normalized'; p3=axH(3).Position; xl3=get(axH(3),'XLim');
nd_f=(n_days-xl3(1))/(xl3(2)-xl3(1)); lg2_w=p3(3)*0.26; lg2_h=p3(4)*0.32;
lg2_x=max(p3(1)+0.004,min(p3(1)+p3(3)*(nd_f-0.018)-lg2_w,p3(1)+p3(3)-lg2_w-0.004));
lg2_y=max(p3(2)+0.004,min(p3(2)+p3(4)*0.51,p3(2)+p3(4)-lg2_h-0.004));
lg2.Position=[lg2_x,lg2_y,lg2_w,lg2_h];
set(findall(fig2,'-property','FontName'),'FontName',chosenFont);

%% FIG 3 - Rt + daily incidence
c_epi_fwd=[0.00 0.18 0.45]; c_epi_sm=[0.10 0.55 0.10]; c_ngm=[0.80 0.10 0.05];
sp_fwd=max(1,floor(n_days/12)); sp_sm=max(1,floor(n_days/12)); off_sm=max(1,floor(sp_sm/2));
fig3=figure('Color','w','Position',[100 80 740 280],'PaperPositionMode','auto');
ax_top=subplot(2,1,1); hold(ax_top,'on');
plot(ax_top,t_axis,EpiR_fwd_aligned,'-','Color',c_epi_fwd,'LineWidth',LW,'HandleVisibility','off');
plot(ax_top,t_axis(1:sp_fwd:end),EpiR_fwd_aligned(1:sp_fwd:end),'o','MarkerFaceColor',c_epi_fwd,'MarkerEdgeColor','k','MarkerSize',mkSz+3,'LineWidth',0.5,'DisplayName','EpiFilter (forward)');
idx_sm=min(off_sm,n_days):sp_sm:n_days;
plot(ax_top,t_axis,EpiR_sm_aligned,'--','Color',c_epi_sm,'LineWidth',LW,'HandleVisibility','off');
plot(ax_top,t_axis(idx_sm),EpiR_sm_aligned(idx_sm),'^','MarkerFaceColor',c_epi_sm,'MarkerEdgeColor',c_epi_sm*0.6,'MarkerSize',mkSz+2,'LineWidth',0.5,'DisplayName','EpiFilter (smoother)');
vld_rt=find(~isnan(Rt_NGM_full));
if ~isempty(vld_rt)
    plot(ax_top,vld_rt,Rt_NGM_full(vld_rt),'-.','Color',c_ngm,'LineWidth',LW+0.8,'DisplayName','LSTM-NGM');
end
yline(ax_top,1,'k--','LineWidth',0.9,'HandleVisibility','off');
ylabel(ax_top,'R_t','FontSize',bfs+2,'FontWeight','bold','Interpreter','tex');
ylim(ax_top,[0 6]); grid(ax_top,'off'); sAx(ax_top);
lg3=legend(ax_top,'show','Location','northeast','Box','off');
set(lg3,'AutoUpdate','off','Interpreter','tex','FontName',chosenFont,'FontSize',lfs+2,'TextColor',[0 0 0]);
ax_bot=subplot(2,1,2); hold(ax_bot,'on');
I_daily_plot=max(incd_raw(:),0); avg7=movmean(I_daily_plot,[6 0],'omitnan');
patch(ax_bot,[t_axis(:)',fliplr(t_axis(:)')],[I_daily_plot',zeros(1,n_days)],[0.55 0.55 0.55],'EdgeColor','none','DisplayName','Daily cases');
plot(ax_bot,t_axis,avg7,'-','Color',[0.85 0.10 0.10],'LineWidth',LW,'DisplayName','7-day avg');
ylim(ax_bot,[0,max(I_daily_plot)*1.15]);
ylabel(ax_bot,'Daily cases','FontSize',bfs,'FontWeight','bold','Interpreter','tex');
xlabel(ax_bot,'Day','FontSize',bfs,'FontWeight','bold','Interpreter','tex');
grid(ax_bot,'off'); sAx(ax_bot);
lg3b=legend(ax_bot,'show','Location','northeast','Box','off');
set(lg3b,'AutoUpdate','off','Interpreter','tex','FontName',chosenFont,'FontSize',lfs+2,'TextColor',[0 0 0]);
linkaxes([ax_top,ax_bot],'x'); xlim(ax_top,[1,n_days]);
set(findall(fig3,'-property','FontName'),'FontName',chosenFont);

%% FIG 4 - MIA (n=30)
% ens_mean_n30 is (5 x 3 x 3) in MATLAB: dim1=n_sigma, dim2=n_met, dim3=n_param
perturb_lvl_v=perturb_lvl(:)';
met_lbl_pr={'T_m','RH','WS'};
[sigma_sorted,sidx]=sort(perturb_lvl_v);
R2_mat=nan(3,3); b_ols_mat=nan(3,3);
for pm_i=1:3
    for v=1:3
        y=squeeze(ens_mean_n30(:,v,pm_i)); y=y(sidx);
        b=(sigma_sorted*sigma_sorted')\(sigma_sorted*y);
        yh=b*sigma_sorted'; SSr=sum((y(:)-yh(:)).^2); SSt=sum(y(:).^2);
        b_ols_mat(pm_i,v)=b;
        if SSt>eps, R2_mat(pm_i,v)=1-SSr/SSt; end
    end
end
c_T=[0.00 0.35 0.60]; c_RH=[0.80 0.20 0.00]; c_WS=[0.10 0.50 0.10];
ann_colors={[0.00 0.20 0.45];[0.65 0.10 0.00];[0.05 0.35 0.05]};
mia_sty={c_T,'-','o',c_T; c_RH,'--','s',c_RH; c_WS,':','^',c_WS};
ci_ls={'-','--',':'}; ci_lw_v=[0.7 0.7 0.7]; ci_alpha_v=[0.12 0.10 0.08];
mYlb={'$\Delta\beta$','$\Delta\rho$','$\Delta\varepsilon$'};
dsp_names={'$T_m$','RH','WS'};
mImp=cell(3,1);
for pm_i=1:3
    mImp{pm_i}=cell(3,1);
    for v=1:3, mImp{pm_i}{v}=squeeze(ens_mean_n30(:,v,pm_i)); end
end
fig_mia=figure('Color','w','Position',[120 120 1100 round(198*1.8)],'PaperPositionMode','auto');
for sp=1:3
    ax=subplot(1,3,sp); hold on;
    for wv=[3,2,1]
        fill_clr=blendW(mia_sty{wv,1},ci_alpha_v(wv));
        lo_v=squeeze(ens_bslo_n30(:,wv,sp)); hi_v=squeeze(ens_bshi_n30(:,wv,sp));
        fill([perturb_lvl_v,fliplr(perturb_lvl_v)],[lo_v(:)',fliplr(hi_v(:)')],...
            fill_clr,'FaceAlpha',1.0,'EdgeColor','none','HandleVisibility','off');
    end
    for wv=1:3
        col=mia_sty{wv,1};
        lo_v=squeeze(ens_bslo_n30(:,wv,sp)); hi_v=squeeze(ens_bshi_n30(:,wv,sp));
        plot(perturb_lvl_v,hi_v(:)','LineStyle',ci_ls{wv},'Color',col,'LineWidth',ci_lw_v(wv),'HandleVisibility','off');
        plot(perturb_lvl_v,lo_v(:)','LineStyle',ci_ls{wv},'Color',col,'LineWidth',ci_lw_v(wv),'HandleVisibility','off');
    end
    for wv=1:3
        sc=mia_sty(wv,:);
        plot(perturb_lvl_v,mImp{sp}{wv}(:)','LineStyle',sc{2},'Color',sc{1},'LineWidth',LW+0.3,...
            'Marker',sc{3},'MarkerFaceColor',sc{4},'MarkerEdgeColor',sc{1},'MarkerSize',mkSz+1,'DisplayName',dsp_names{wv});
    end
    yline(0,'--','Color',[0.45 0.45 0.45],'LineWidth',0.9,'HandleVisibility','off');
    xlabel('$\sigma$','FontSize',bfs+3,'FontWeight','bold','Interpreter','latex');
    ylabel(mYlb{sp},'FontSize',bfs+3,'FontWeight','bold','Interpreter','latex');
    xlim([-2.3 2.3]); grid off;
    set(gca,'FontSize',bfs,'FontName',chosenFont,'Box','on','LineWidth',0.8,'FontWeight','bold');
    if sp==1
        lg1=legend('Box','off','FontSize',lfs+3);
        set(lg1,'AutoUpdate','off','FontName',chosenFont,'Interpreter','latex');
        drawnow; lg1.Units='normalized'; lg1.Position=[0.14,0.78,0.10,0.12];
    end
    drawnow; ax_now=gca; yl=ax_now.YLim; xl=ax_now.XLim;
    y_step=(yl(2)-yl(1))*0.06; y_top=yl(2)-0.4*y_step; x_pos=xl(2)-0.1*diff(xl);
    for v=1:3
        if isnan(R2_mat(sp,v)), continue; end
        text(ax_now,x_pos,y_top-(v-1)*y_step,sprintf('\\bfR^2(%s)=%.2f',met_lbl_pr{v},R2_mat(sp,v)),...
            'FontSize',9,'Color',ann_colors{v},'HorizontalAlignment','right','VerticalAlignment','top',...
            'FontName',chosenFont,'Interpreter','tex','BackgroundColor','none','EdgeColor','none','Margin',2,'Clipping','on');
    end
end
ax1=subplot(1,3,1); ax1_pos=ax1.Position(:)';
ax_leg=axes('Position',ax1_pos,'Color','none','XColor','none','YColor','none','HitTest','off');
hold(ax_leg,'on'); h_prx=gobjects(3,1);
for wv=1:3
    h_prx(wv)=fill(ax_leg,NaN,NaN,blendW(mia_sty{wv,1},ci_alpha_v(wv)),...
        'EdgeColor',mia_sty{wv,1},'LineStyle',ci_ls{wv},'LineWidth',1.2);
end
lg2=legend(ax_leg,h_prx,{'95\% BCI ($T_m$)','95\% BCI (RH)','95\% BCI (WS)'},...
    'Box','off','FontSize',lfs+1,'Interpreter','latex');
set(lg2,'AutoUpdate','off','FontName',chosenFont); drawnow;
lg2.Units='normalized';
lg2.Position=[ax1_pos(1)+0.04,ax1_pos(2)+0.01,ax1_pos(3)*0.68,ax1_pos(4)*0.20];
set(findall(fig_mia,'-property','FontName'),'FontName',chosenFont);

%% TABLE 1 - Walk-Forward CV
% cv_r2 (n_folds x 3): cols=beta/rho/eps
% cv_shade (n_folds x 2): cols=day_lo/day_hi
n_f=size(cv_r2,1); folds=(1:n_f)';
day_lo=cv_shade(:,1); day_hi=cv_shade(:,2);
fprintf('\n');
fprintf('================================================================\n');
fprintf('  TABLE 1 - Walk-Forward Cross-Validation Results\n');
fprintf('================================================================\n');
fprintf('  %-6s  %-12s  %-9s  %-9s  %-9s  %-9s  %-9s  %-9s\n',...
    'Fold','Day Range','R2_beta','R2_rho','R2_eps','MAE_beta','MAE_rho','MAE_eps');
fprintf('  %s\n',repmat('-',1,80));
for i=1:n_f
    fprintf('  %-6d  [%3d-%3d]     %-9.4f  %-9.4f  %-9.4f  %-9.4f  %-9.4f  %-9.4f\n',...
        i,day_lo(i),day_hi(i),cv_r2(i,1),cv_r2(i,2),cv_r2(i,3),cv_mae(i,1),cv_mae(i,2),cv_mae(i,3));
end
fprintf('  %s\n',repmat('-',1,80));
fprintf('  %-6s  %-12s  %-9.4f  %-9.4f  %-9.4f  %-9.4f  %-9.4f  %-9.4f\n',...
    'Mean','',mean(cv_r2(:,1)),mean(cv_r2(:,2)),mean(cv_r2(:,3)),...
    mean(cv_mae(:,1)),mean(cv_mae(:,2)),mean(cv_mae(:,3)));
fprintf('================================================================\n');

%% TABLE 2 - Full-Data Metrics
var_lbl={'beta','rho','epsilon','S','E','I','R','Rt_NGM'};
MAE_v  =[mae_b; mae_r; mae_e; mae_S; mae_E; mae_I; mae_R; mae_Rt];
RMSE_v =[rmse_b;rmse_r;rmse_e;rmse_S;rmse_E;rmse_I;rmse_R;rmse_Rt];
R2_v   =[r2_b;  r2_r;  r2_e;  r2_S;  r2_E;  r2_I;  r2_R;  r2_Rt];
nRMSE_v=[nrmse_b;nrmse_r;nrmse_e;nrmse_S;nrmse_E;nrmse_I;nrmse_R;nrmse_Rt];
Pearson_v=[NaN;NaN;NaN;NaN;pearson_E;pearson_I;NaN;NaN];
CCC_v    =[NaN;NaN;NaN;NaN;ccc_E;    ccc_I;    NaN;NaN];
fprintf('\n');
fprintf('================================================================\n');
fprintf('  TABLE 2 - Full-Data Prediction Metrics\n');
fprintf('================================================================\n');
fprintf('  %-10s  %10s  %10s  %8s  %8s  %8s  %8s\n',...
    'Variable','MAE','RMSE','R2','nRMSE','Pearson','CCC');
fprintf('  %s\n',repmat('-',1,72));
for i=1:numel(var_lbl)
    if isnan(Pearson_v(i))
        fprintf('  %-10s  %10.4e  %10.4e  %8.4f  %8.4f\n',...
            var_lbl{i},MAE_v(i),RMSE_v(i),R2_v(i),nRMSE_v(i));
    else
        fprintf('  %-10s  %10.4e  %10.4e  %8.4f  %8.4f  %8.4f  %8.4f\n',...
            var_lbl{i},MAE_v(i),RMSE_v(i),R2_v(i),nRMSE_v(i),Pearson_v(i),CCC_v(i));
    end
end
fprintf('================================================================\n');

%% TABLE 3 - MIA Summary
param_lbl={'beta','rho','epsilon'}; met_lbl={'T','RH','WS'};
fprintf('\n');
fprintf('================================================================\n');
fprintf('  TABLE 3 - MIA Summary (OLS Slope + Sign Consistency)\n');
fprintf('================================================================\n');
fprintf('  %-10s  %-6s  %+14s  %18s\n','Parameter','Met','OLS_Slope','Sign_Consistency');
fprintf('  %s\n',repmat('-',1,56));
for pm_i=1:3
    for v=1:3
        fprintf('  %-10s  %-6s  %+14.4e  %18.3f\n',...
            param_lbl{pm_i},met_lbl{v},mia_slope_mat(pm_i,v),sign_consist_n30(pm_i,v));
    end
end
fprintf('================================================================\n');
