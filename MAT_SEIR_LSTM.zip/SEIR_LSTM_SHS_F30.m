%% SEIR_LSTM_SHS_V30
%  Author: [SHS] 
%  Date: 2025-11-15

clear; clc; close all;
rng(42, 'twister');
%% ==================== TUNED/OPTIMIZED PARAMETERS ====================
tau.T2M = 10; tau.RH2M = 7; tau.WS2M = 9; tau.u_t = 8; tau_max = 10;

smth_win = 14; sg_win = 7; sg_deg = 3; win_Size = 14; smooth_win_Rt = 7;

HP.hdnsz1 = 83;          HP.hdnsz2 = 54;     HP.fcSize = 58;
HP.dropR  = 0.2035;      HP.dropR2 = 0.3926;
HP.ILR    = 6.9808e-05;  HP.LRDF = 0.6340;   HP.LRDP = 36;
HP.L2Reg  = 1.2479e-03;  HP.GT   = 1.2302;   HP.MB   = 95;

lam_phys_S = 0.7553;  lam_phys_E = 1.7381;
lam_phys_I = 0.2151;  lam_phys_R = 1.0971;
lam_mass   = 0.4327;  lam_rho_Rt = 0.3291;
lam_eps_reg_base = 0.05;
% Manually Tuned
kappa_nudge_S = 0.1;  kappa_nudge_E = 0.5;
kappa_nudge_I = 0.7;  kappa_nudge_R = 0.1;
restart_interval = 1;

%% ==================== PART 1: DATA LOADING & PREPROCESSING ====================
fprintf('=== PART 1: Data Loading & Preprocessing ===\n');
data      = readtable('Epidemic and meteorological data_Nepal.xlsx');
I_raw     = data.I;         R_raw    = data.R_c;    DD         = data.Death_Daily;
N_pop     = data.N_Living;  T2M      = data.T2M;    RH2M       = data.RH2M;
WS2M      = data.WS2M;      u_t      = data.u_t;    v_t        = data.v_t;
incd_raw  = data.I_Daily;   dates    = data.Date;   n_days_raw = height(data);
fprintf('  Raw data: %d days\n', n_days_raw);

epsilon_fixed = 1/5.1;      v_e = 0.65;
b_min=1e-5;  b_max=1.8;     r_min=1/28;  r_max=1/2;
e_min=1/14;  e_max=1/1.25;  u_min=0;   u_max=0.95;
d_min=0;     d_max=1e-4;    R_lo=0.005; R_hi=6.0;
dth_lag=3;   eta_base=0.01; R_grid_n=2500;
prior_mean=0.95;            prior_sd=0.25;
lambda_E4=0.08; theta=0.65; n_iter=25; tol=1e-5;

% Bounds struct
bounds.b_min=b_min; bounds.b_max=b_max;
bounds.r_min=r_min; bounds.r_max=r_max;
bounds.e_min=e_min; bounds.e_max=e_max;
bounds.R_hi =R_hi;

u_comb = 1-(1-u_t).*(1-v_t.*v_e);
u_comb = min(max(u_comb,u_min),u_max);
u_pad  = [nan(tau.u_t,1); u_comb(1:end-tau.u_t)];
u_ts   = movmean(u_pad,[7 0],'omitnan','Endpoints','shrink');
u_ts   = fillmissing(u_ts,'nearest');
u_ts   = min(max(u_ts,u_min),u_max);

y_yr=year(dates); alpha=zeros(n_days_raw,1);
alpha(y_yr==2020)=5.65479e-05; alpha(y_yr==2021)=5.60274e-05;
alpha(y_yr==2022)=5.52329e-05;

T2M_lag  = fillmissing(lagmatrix(T2M,  tau.T2M),  'nearest');
RH2M_lag = fillmissing(lagmatrix(RH2M, tau.RH2M), 'nearest');
WS2M_lag = fillmissing(lagmatrix(WS2M, tau.WS2M), 'nearest');
met_lag  = [T2M_lag, RH2M_lag, WS2M_lag];

keep = (tau_max+1):n_days_raw;
dates    = dates(keep);    I_raw    = I_raw(keep);     R_raw    = R_raw(keep);
DD       = DD(keep);       N_pop    = N_pop(keep);     u_ts     = u_ts(keep);
alpha    = alpha(keep);    met_lag  = met_lag(keep,:); incd_raw = incd_raw(keep);
n_days   = numel(keep);
fprintf('  After lag alignment: %d days (tau_max=%d)\n', n_days, tau_max);
fprintf('  Lags applied: T2M:%d  RH2M:%d  WS2M:%d  u_t:%d\n', ...
    tau.T2M, tau.RH2M, tau.WS2M, tau.u_t);

alpha_s    = max(causal_smooth(alpha,smth_win),0);
met_smooth = causal_smooth(met_lag,smth_win);
I_s        = max(causal_smooth(I_raw,smth_win),0);
R_s        = max(causal_smooth(R_raw,smth_win),0);
D_s        = max(causal_smooth(DD,smth_win),0);
incd_sm    = max(causal_smooth(incd_raw,smth_win),0);
I_sftd     = fillmissing([nan(dth_lag,1); I_s(1:end-dth_lag)],'nearest');
delta_t    = causal_smooth(min(max(D_s./max(I_sftd,1),d_min),d_max),smth_win);

I_sn      = min(max(I_s./N_pop,0),1);
R_sn      = min(max(R_s./N_pop,0),1);
incd_norm = incd_sm./max(N_pop,1);
I_raw_norm= min(max(I_raw./N_pop,0),1);
fprintf('  Preprocessing complete (all smoothing: %d-day trailing window)\n',smth_win);

%% ==================== PART 2: E(t) RECONSTRUCTION ====================
fprintf('\n=== PART 2: E(t) Reconstruction ===\n');

incub_kern   = gampdf(0:21,5.8,0.9);
incub_kern   = incub_kern/sum(incub_kern);
incub_kern_c = flipud(incub_kern(:));  % for Rt_proxy renewal loop

% Survival-kernel: surv_kern(tau) = P(incubation > tau)
cdf_incub = cumsum(incub_kern(:));
surv_kern = max(1 - cdf_incub, 0);
surv_kern = surv_kern / max(sum(surv_kern),1e-12);
T_surv    = numel(surv_kern);

% Single convolution
E_incub_raw = zeros(n_days,1);
for tt = 1:n_days
    avail = min(tt, T_surv);
    E_incub_raw(tt) = surv_kern(1:avail)' * incd_norm(tt:-1:tt-avail+1);
end
E_incub_raw = max(E_incub_raw, 0);
E_m1 = causal_smooth(max(E_incub_raw, 1e-6), smth_win);  % E_m1 = E_incub by construction

dI_prlm = causal_deriv_sg(I_sn,sg_win,sg_deg);
rho_prlm = causal_smooth(min(max(fillmissing(real( ...
    (causal_deriv_sg(R_sn,sg_win,sg_deg)+alpha_s.*R_sn-delta_t.*I_sn.*R_sn) ...
    ./(I_sn+1e-6)),'movmedian',[win_Size 0]),r_min),r_max),smth_win);
E_prlm  = causal_smooth(max( ...
    (dI_prlm+(rho_prlm+delta_t+alpha_s).*I_sn-delta_t.*I_sn.^2)./epsilon_fixed, ...
    1e-6),smth_win);
E_incub = causal_smooth(max(E_incub_raw,0),smth_win);
E_incub = max(E_incub, 0.5*I_sn);
E_prlm  = max(E_prlm, E_incub);
S_pre = max(1-E_prlm-I_sn-R_sn,0);
TS    = max(S_pre+E_prlm+I_sn+R_sn,1e-6);
S_sn  = S_pre./TS;  E_sn = E_prlm./TS;
I_sn  = I_sn./TS;   R_sn = R_sn./TS;

dE_s = causal_deriv_sg(E_sn,sg_win,sg_deg);
dI_s = causal_deriv_sg(I_sn,sg_win,sg_deg);
dR_s = causal_deriv_sg(R_sn,sg_win,sg_deg);
I_safe = I_sn+1e-6;  S_safe = S_sn+1e-6;

rho_init_pre = causal_smooth(min(max(fillmissing(real( ...
    (dR_s+alpha_s.*R_sn-delta_t.*I_sn.*R_sn)./I_safe), ...
    'movmedian',[win_Size 0]),r_min),r_max),smth_win);

grth = causal_smooth(dI_s./I_safe,smth_win);
E_m2 = max(I_sn.*min(max(1.05+grth/epsilon_fixed,1.05),6.0),1e-6);
dI_sm  = causal_smooth(dI_s,smth_win); dI_std = std(dI_sm)+1e-10;
fast_g = dI_sm>0.5*dI_std;  slow_g = dI_sm>0 & ~fast_g;  decl = dI_sm<=0;
w1 = 0.20*fast_g + 0.15*slow_g + 0.55*decl;
w2 = 0.05*fast_g + 0.10*slow_g + 0.15*decl;
w3 = 0.75*fast_g + 0.75*slow_g + 0.30*decl;

roll7_pre = movsum(incd_sm,[6 0],'omitnan');  rel_pre = roll7_pre>=10;
kern_len  = numel(incub_kern_c);  Rt_proxy = nan(n_days,1);
for tt=2:n_days
    avail=min(tt-1,kern_len-1);  if avail<1, continue; end
    lam=incub_kern_c(2:avail+1)'*incd_sm(tt-1:-1:tt-avail);
    if lam>1e-8 && rel_pre(tt), Rt_proxy(tt)=incd_sm(tt)/lam; end
end
Rt_proxy = causal_smooth(max(min(fillmissing(Rt_proxy,'movmedian',[win_Size 0]),R_hi),0),smth_win);
Rt_rel   = Rt_proxy>0 & isfinite(Rt_proxy);

rho_iter = rho_init_pre;
eps_iter = epsilon_fixed*ones(n_days,1);
M3_0  = max(dI_s+(rho_init_pre+delta_t+alpha_s).*I_sn-delta_t.*I_sn.^2,0);
E_m3  = causal_smooth(max(M3_0./epsilon_fixed,1e-6),smth_win);
E_curr= causal_smooth(max(w1.*E_m1+w2.*E_m2+w3.*E_m3,1e-6),smth_win);
E_ph1 = I_sn.*((rho_init_pre+delta_t+alpha_s)./max(epsilon_fixed,1e-6));
E_curr= max(E_curr, max(E_ph1,0.5*I_sn));

for iter=1:n_iter
    E_prev = E_curr;
    rho_k  = causal_smooth(min(max(fillmissing(real( ...
        (dR_s+alpha_s.*R_sn-delta_t.*I_sn.*R_sn)./I_safe), ...
        'movmedian',[win_Size 0]),r_min),r_max),smth_win);
    M3_k   = dI_s+(rho_k+delta_t+alpha_s).*I_sn-delta_t.*I_sn.^2;
    eps_k  = causal_smooth(min(max(fillmissing(real(M3_k./max(E_prev,1e-6)), ...
        'movmedian',[win_Size 0]),e_min),e_max),smth_win);
    E_ph1_k= max(I_sn.*((rho_k+delta_t+alpha_s-delta_t.*I_sn)./max(eps_k,1e-6)),0.5*I_sn);
    E_m3_k = causal_smooth(max(max(M3_k,0)./max(eps_k,1e-6),1e-6),smth_win);
    beta_prx=causal_smooth(min(max((dE_s+(eps_k+alpha_s).*E_prev-delta_t.*I_sn.*E_prev)./ ...
        max((1-u_ts).*S_safe.*I_safe,1e-8),b_min),b_max),smth_win);
    E_m4   = min(max(Rt_proxy.*(rho_k+delta_t+alpha_s).*I_sn./ ...
        max(beta_prx.*(1-u_ts).*S_safe,1e-8),0.5*I_sn),5*I_sn);
    E_m4(~Rt_rel) = E_m3_k(~Rt_rel);
    E_new  = causal_smooth(max( ...
        (1-lambda_E4).*(w1.*E_m1+w2.*E_m2+w3.*E_m3_k)+lambda_E4.*E_m4,1e-6),smth_win);
    E_curr = max(theta*E_new+(1-theta)*E_prev, E_ph1_k);
    rho_iter = rho_k;  eps_iter = eps_k;
    if norm(E_curr-E_prev)/(norm(E_prev)+1e-8)<tol, break;
    end
end
fprintf('  E reconstruction converged at iter %d\n',iter);
[~,i_E_pk]=max(E_sn); [~,i_I_pk]=max(I_sn);
fprintf('  E peak at day %d, I peak at day %d, lead = %d days\n', ...
    i_E_pk, i_I_pk, i_I_pk-i_E_pk);

E_ph1_f = max(I_sn.*((rho_iter+delta_t+alpha_s-delta_t.*I_sn)./max(eps_iter,1e-6)),0.5*I_sn);
E_sn    = max(E_curr, E_ph1_f);
S_tmp   = max(1-E_sn-I_sn-R_sn,0);
TS      = max(S_tmp+E_sn+I_sn+R_sn,1e-6);
S_sn    = S_tmp./TS;  E_sn = E_sn./TS;
I_sn    = I_sn./TS;   R_sn = R_sn./TS;
fprintf('  Mass balance max error: %.2e\n',max(abs(S_sn+E_sn+I_sn+R_sn-1)));

%% ==================== PART 3: EPIFILTER FOR R_t ESTIMATE ====================
fprintf('\n=== PART 3: EpiFilter ===\n');

SI_vrnt = {
    datetime(2020,5,8),  datetime(2020,10,31), 'Wild-type', 5.5, 3.5, 28;
    datetime(2020,11,1), datetime(2021,4,30),  'Alpha',     5.0, 3.2, 25;
    datetime(2021,5,1),  datetime(2021,12,15), 'Delta',     4.7, 2.8, 22;
    datetime(2021,12,16),datetime(2022,12,31), 'Omicron',   3.5, 2,   18;
};
n_vrnt = size(SI_vrnt,1);

si_pmf_vrnt = cell(n_vrnt,1);  si_mx_vrnt = zeros(n_vrnt,1);
for vv=1:n_vrnt
    si_mn=SI_vrnt{vv,4}; si_sd=SI_vrnt{vv,5}; si_mx=SI_vrnt{vv,6};
    pmf_v=gampdf((0:si_mx)',(si_mn/si_sd)^2,si_sd^2/si_mn);
    pmf_v(1)=0;  sv=sum(pmf_v);
    if sv>0, pmf_v=pmf_v/sv; else, pmf_v=zeros(si_mx+1,1); pmf_v(2)=1; end
    si_pmf_vrnt{vv}=pmf_v;  si_mx_vrnt(vv)=si_mx;
end

tau_lgst=14;  t_epoch=dates(1);  t_dates_num=days(dates-t_epoch);
t_trns=zeros(n_vrnt,1);
for vv=1:n_vrnt, t_trns(vv)=days(SI_vrnt{vv,1}-t_epoch); end
max_si_g=max(si_mx_vrnt);
si_pmf_daily=cell(n_days,1);
for t=1:n_days
    tn=t_dates_num(t);  w_v=ones(n_vrnt,1);
    for vv=1:n_vrnt
        w_v(vv)=w_v(vv)*(1/(1+exp(-(tn-t_trns(vv))/tau_lgst)));
        if vv<n_vrnt
            w_v(vv)=w_v(vv)*(1-1/(1+exp(-(tn-t_trns(vv+1))/tau_lgst)));
        end
    end
    w_sum=sum(w_v);
    if w_sum>1e-12, w_v=w_v/w_sum; else, w_v=zeros(n_vrnt,1); w_v(1)=1; end
    pmf_mix=zeros(max_si_g+1,1);
    for vv=1:n_vrnt
        if w_v(vv)<1e-9, continue; end
        pv=si_pmf_vrnt{vv};
        pmf_mix(1:numel(pv))=pmf_mix(1:numel(pv))+w_v(vv)*pv;
    end
    pmf_mix(1)=0;  sm=sum(pmf_mix);
    if sm>0, pmf_mix=pmf_mix/sm; else, pmf_mix(2)=1; end
    si_pmf_daily{t}=pmf_mix;
end

R_grid   = linspace(R_lo,R_hi,R_grid_n)';  dR_step=R_grid(2)-R_grid(1);
[R1,R2]  = meshgrid(R_grid,R_grid);
T_mat_raw= normpdf(R1,R2,sqrt(eta_base));  T_mat_raw(R1<R_lo|R1>R_hi)=0;
col_sums = sum(T_mat_raw,1)*dR_step;  col_sums(col_sums==0)=1;
T_mat    = (T_mat_raw./col_sums)*dR_step;
prior_R  = normpdf(R_grid,prior_mean,prior_sd);  prior_R=max(prior_R,0);
prior_R  = prior_R/(sum(prior_R)*dR_step);  pR_curr=prior_R*dR_step;

incd_ef  = max(round(movmean(incd_raw,7,'omitnan')),0);
rolling7 = movsum(incd_ef,7,'omitnan');  reliable=rolling7>=10;

pR_filt    = zeros(R_grid_n,n_days);
EpiR_fwd   = nan(n_days,1);
EpiR_lo_fwd= nan(n_days,1);
EpiR_hi_fwd= nan(n_days,1);
for t=1:n_days
    pmf_t=si_pmf_daily{t};  avail_t=min(t-1,numel(pmf_t)-1);  Lambda_t=0;
    if avail_t>=1
        Lambda_t=pmf_t(2:avail_t+1)'*incd_ef(t-1:-1:t-avail_t);
    end
    Lambda_t=max(Lambda_t,1e-8);
    if t==1
        pR_pred=pR_curr;
    else
        pR_pred=T_mat*pR_curr;  pR_pred=max(pR_pred,0);
        s=sum(pR_pred);
        if s>0, pR_pred=pR_pred/s; else, pR_pred=ones(R_grid_n,1)/R_grid_n; end
    end
    if reliable(t)
        log_lik=incd_ef(t).*log(R_grid*Lambda_t+1e-300)-R_grid*Lambda_t;
        log_lik=log_lik-max(log_lik);  lik=exp(log_lik);
        pR_post=pR_pred.*lik;  s=sum(pR_post);
        if s>1e-300, pR_post=pR_post/s; else, pR_post=pR_pred; end
    else
        pR_post=pR_pred;
    end
    pR_filt(:,t)=pR_post;  pR_curr=pR_post;
    if reliable(t)
        EpiR_fwd(t)=sum(R_grid.*pR_post);
        cdf=cumsum(pR_post);
        lo=find(cdf>=0.025,1,'first'); if isempty(lo),lo=1; end
        hi=find(cdf>=0.975,1,'first'); if isempty(hi),hi=R_grid_n; end
        EpiR_lo_fwd(t)=R_grid(lo);  EpiR_hi_fwd(t)=R_grid(hi);
    end
end
fprintf('  Forward filter: mean Rt = %.3f\n',mean(EpiR_fwd,'omitnan'));

pR_smooth = zeros(R_grid_n,n_days);
pR_smooth(:,n_days)=pR_filt(:,n_days);
for t=n_days-1:-1:1
    p_pred_next=max(T_mat*pR_filt(:,t),1e-300);
    p_tmp=pR_filt(:,t).*(T_mat'*(pR_smooth(:,t+1)./p_pred_next));
    s=sum(p_tmp);
    if s>0, pR_smooth(:,t)=p_tmp/s; else, pR_smooth(:,t)=pR_filt(:,t); end
end

EpiR_sm_raw  = nan(n_days,1);
EpiR_sm_lo95 = nan(n_days,1);
EpiR_sm_hi95 = nan(n_days,1);
for t=1:n_days
    if reliable(t)
        p=pR_smooth(:,t);  EpiR_sm_raw(t)=sum(R_grid.*p);
        cdf=cumsum(p);
        lo=find(cdf>=0.025,1,'first'); if isempty(lo),lo=1; end
        hi=find(cdf>=0.975,1,'first'); if isempty(hi),hi=R_grid_n; end
        EpiR_sm_lo95(t)=R_grid(lo);  EpiR_sm_hi95(t)=R_grid(hi);
    end
end
fprintf('  Smoothed estimate: mean Rt = %.3f\n',mean(EpiR_sm_raw,'omitnan'));

epi_lag=tau_max+1;
EpiR_fwd_fll = fillmissing(EpiR_fwd,'movmedian',[win_Size 0]);
EpiR_sm_fll  = fillmissing(EpiR_sm_raw,'movmedian',[win_Size 0]);
EpiR_fwd_aligned = max(causal_smooth(fillmissing( ...
    [nan(epi_lag,1);EpiR_fwd_fll(1:end-epi_lag)],'nearest'),smth_win),0);
EpiR_sm_aligned  = max(causal_smooth(fillmissing( ...
    [nan(epi_lag,1);EpiR_sm_fll(1:end-epi_lag)],'nearest'),smth_win),0);
tmp_lo = fillmissing(EpiR_sm_lo95,'movmedian',[win_Size 0]);
EpiR_lo95_aligned = max(causal_smooth(fillmissing( ...
    [nan(epi_lag,1);tmp_lo(1:end-epi_lag)],'nearest'),smth_win),0);
tmp_hi = fillmissing(EpiR_sm_hi95,'movmedian',[win_Size 0]);
EpiR_hi95_aligned = max(causal_smooth(fillmissing( ...
    [nan(epi_lag,1);tmp_hi(1:end-epi_lag)],'nearest'),smth_win),0);
clear tmp_lo tmp_hi;

%% ==================== PART 4: lsqnonlin PARAMETER ESTIMATION ====================
fprintf('\n=== PART 4: Ground-Truth Parameter Estimation ===\n');

dS_s    = causal_deriv_sg(S_sn,sg_win,sg_deg);
dE_s    = causal_deriv_sg(E_sn,sg_win,sg_deg);
dI_s    = causal_deriv_sg(I_sn,sg_win,sg_deg);
dR_s    = causal_deriv_sg(R_sn,sg_win,sg_deg);
I_safe  = I_sn+1e-6;  S_safe  = S_sn+1e-6;
SI_safe = (1-u_ts).*S_safe.*I_safe+1e-6;

beta_ws = causal_smooth(min(max(fillmissing(real( ...
    (dE_s+(eps_iter+alpha_s).*E_sn-delta_t.*I_sn.*E_sn)./SI_safe), ...
    'movmedian',[win_Size 0]),b_min),b_max),smth_win);

lsq_opts = optimoptions('lsqnonlin','Display','off','MaxIterations',400, ...
    'FunctionTolerance',1e-7,'StepTolerance',1e-7);
lb=[b_min,r_min,e_min];  ub=[b_max,r_max,e_max];
beta_SEIR    = zeros(n_days,1);
rho_SEIR     = zeros(n_days,1);
epsilon_SEIR = zeros(n_days,1);
x0 = [beta_ws(1),rho_iter(1),eps_iter(1)];
prev_p = x0;  lambda_reg=2e-5;  lambda_Rt=0.40;

epoch_bnd = false(n_days,1);
for vv=1:n_vrnt
    idx_vv=find(dates>=SI_vrnt{vv,1},1,'first');
    if ~isempty(idx_vv)&&idx_vv>=1&&idx_vv<=n_days
        epoch_bnd(idx_vv)=true;
    end
end

for t=1:n_days
    if epoch_bnd(t)
        x0=[beta_ws(t),rho_iter(t),eps_iter(t)]; prev_p=x0;
    end
    Rt_tgt_t=EpiR_fwd_fll(t);  lam_Rt_t=lambda_Rt;
    if isnan(Rt_tgt_t)||Rt_tgt_t<=0||Rt_tgt_t>R_hi, lam_Rt_t=0; end
    fn=@(p)[seir_residual(p,S_sn(t),E_sn(t),I_sn(t),R_sn(t),u_ts(t), ...
             delta_t(t),alpha_s(t),dS_s(t),dE_s(t),dI_s(t),dR_s(t), ...
             Rt_tgt_t,lam_Rt_t); sqrt(lambda_reg)*(p-prev_p)'];
    
    [p_opt,~,~,ef]=lsqnonlin(fn,[beta_ws(t),rho_iter(t),eps_iter(t)],lb,ub,lsq_opts);
    if ef<0, p_opt=x0; end
    beta_SEIR(t)=p_opt(1);  rho_SEIR(t)=p_opt(2);  epsilon_SEIR(t)=p_opt(3);
    prev_p=p_opt;  x0=p_opt;
end

beta_SEIR    = min(max(causal_smooth(beta_SEIR,   7),b_min),b_max);
rho_SEIR     = min(max(causal_smooth(rho_SEIR,    7),r_min),r_max);
epsilon_SEIR = min(max(causal_smooth(epsilon_SEIR,7),e_min),e_max);
[beta_SEIR,rho_SEIR,epsilon_SEIR] = replaceBadValues(win_Size,beta_SEIR,rho_SEIR,epsilon_SEIR);
% NGM Formula
beta_SEIR_eff = causal_smooth((1-u_ts).*beta_SEIR,7);
Rt_SEIR = max(causal_smooth((beta_SEIR_eff.*epsilon_SEIR.*S_sn)./ ...
    max((epsilon_SEIR+alpha_s).*(rho_SEIR+delta_t+alpha_s),1e-8),smooth_win_Rt),0);

fprintf('  beta:[%.4f,%.4f]  rho:[%.4f,%.4f]  eps:[%.4f,%.4f]\n', ...
    min(beta_SEIR),max(beta_SEIR),min(rho_SEIR),max(rho_SEIR), ...
    min(epsilon_SEIR),max(epsilon_SEIR));

%% ==================== PART 5: FEATURE MATRIX ====================
fprintf('\n=== PART 5: Feature Matrix Construction ===\n');

col_S=1; col_E=2; col_I=3; col_R=4; col_u=5; col_d=6; 
col_T=7; col_RH=8; col_WS=9; col_Rt=10;

numFtr = 10;  sqln = 28;
DM = [S_sn, E_sn, I_sn, R_sn, u_ts, delta_t, met_smooth, EpiR_fwd_aligned];
numSmpl = n_days-sqln;  pred_time_inds = sqln+(1:numSmpl);

X_full = zeros(numSmpl,sqln,numFtr);  Y_full = zeros(numSmpl,3);
for i=1:numSmpl
    X_full(i,:,:) = DM(i:i+sqln-1,:);
    Y_full(i,:)   = [beta_SEIR(i+sqln), rho_SEIR(i+sqln), epsilon_SEIR(i+sqln)];
end

last_p = [beta_SEIR(pred_time_inds-1), rho_SEIR(pred_time_inds-1), ...
          epsilon_SEIR(pred_time_inds-1)];
Y_d    = Y_full - last_p;

nVal = max(30,floor(0.15*numSmpl));  nTrn = numSmpl-nVal;
Xtr_flat = reshape(X_full(1:nTrn,:,:),[],numFtr);
fm = mean(Xtr_flat,1);  fs = std(Xtr_flat,0,1);  fs(fs==0)=1;

pm_d = mean(Y_d(1:nTrn,:),1,'omitnan');
ps_d = std( Y_d(1:nTrn,:),0,1,'omitnan');
ps_d_floors = [0.010, 0.005, 0.007];
ps_d = max(ps_d, ps_d_floors);

lw = [0.9, 1, 1];    lw_sqrt = sqrt(lw);

YN_full = (Y_d-pm_d)./ps_d.*lw_sqrt;
XN_full = (X_full-reshape(fm,[1,1,numFtr]))./reshape(fs,[1,1,numFtr]);
XC_full = cell(numSmpl,1);
for i=1:numSmpl, XC_full{i}=squeeze(XN_full(i,:,:))'; end

XTrnC = XC_full(1:nTrn);      YTrnN = YN_full(1:nTrn,:);
XValC = XC_full(nTrn+1:end);  YValN = YN_full(nTrn+1:end,:);

fprintf('  numFtr=%d: S,E,I,R,u,delta,T,RH,WS,EpiRt\n',numFtr);
fprintf('  Y_d stats (train) — beta:%.4f  rho:%.4f  eps:%.4f\n', ...
    std(Y_d(1:nTrn,1),'omitnan'),std(Y_d(1:nTrn,2),'omitnan'),std(Y_d(1:nTrn,3),'omitnan'));
fprintf('  ps_d used         — beta:%.4f  rho:%.4f  eps:%.4f\n',ps_d(1),ps_d(2),ps_d(3));
fprintf('  Training samples: %d  |  Val samples: %d\n',nTrn,nVal);

%% ==================== PART 6: SEIR-LSTM TRAINING ====================
fprintf('\n=== PART 6: PINN-LSTM Training ===\n');

epoch_flag = zeros(n_days,1);
for vv=1:n_vrnt
    idx_vv=find(dates>=SI_vrnt{vv,1},1,'first');
    if ~isempty(idx_vv)
        for tt=1:n_days
            epoch_flag(tt)=epoch_flag(tt)+1/(1+exp(-(tt-idx_vv)/7));
        end
    end
end
epoch_flag = epoch_flag/max(epoch_flag+1e-8);

max_epochs = 200;    patience   = 30;
warmup_epochs = 5;   lr_warmup_start = HP.ILR/10;
plateau_patience = 35; lr_decay_factor = 0.60;   lr_min = 1e-6;

Rt_ref_tr   = EpiR_fwd_aligned(pred_time_inds);
reliable_tr = reliable(pred_time_inds);

layers = build_layers(HP, numFtr);  net = dlnetwork(layers);

avg_grad=[]; avg_sq_g=[]; iter_count=0; best_loss=inf; best_net=net;
epoch_losses=zeros(max_epochs,1); val_losses=zeros(max_epochs,1); no_improve=0;
plateau_count=0; best_val_for_plateau=inf;
cur_lr=lr_warmup_start; lr_at_plateau_start=HP.ILR;
prev_val_loss_mon=nan; init_phys_res=nan; prev_gap_mon=nan;
lam_sum_mon=lam_phys_S+lam_phys_E+lam_phys_I+lam_phys_R+lam_mass+lam_rho_Rt;

fprintf('  %-3s  %-12s %-12s %-10s %-13s %-13s %-13s\n', ...
    'Ep','Train-Loss','Val-Loss','LR','ValPlateau%','TV_Gap','PhysRes%');
fprintf('  %s\n', repmat('-',1,80));

for epoch=1:max_epochs
    if epoch<=warmup_epochs
        cur_lr=lr_warmup_start+(HP.ILR-lr_warmup_start)*(epoch-1)/max(warmup_epochs-1,1);
        lr_at_plateau_start=cur_lr;
    end

    idx_shuf=randperm(nTrn); n_batch=ceil(nTrn/HP.MB); ep_loss=0;
    for b=1:n_batch
        b_start=(b-1)*HP.MB+1; b_end=min(b*HP.MB,nTrn);
        bidx=idx_shuf(b_start:b_end);
        bw=pack_batch(bidx,XN_full,S_sn,E_sn,I_sn,R_sn,u_ts,delta_t, ...
                      alpha_s,sqln,Rt_ref_tr,reliable_tr,epoch_flag(pred_time_inds));
        [loss,grads]=dlfeval(@pinn_loss_fn,net,bw, ...
            lam_phys_S,lam_phys_E,lam_phys_I,lam_phys_R,lam_mass,lam_rho_Rt, ...
            lam_eps_reg_base,YN_full(bidx,:),lw_sqrt,pm_d,ps_d,last_p(bidx,:),bounds);
        grads=dlupdate(@(g) norm_clip(g,HP.GT), grads);
        iter_count=iter_count+1;
        [net,avg_grad,avg_sq_g]=adamupdate(net,grads,avg_grad,avg_sq_g, ...
            iter_count,cur_lr,0.9,0.999,HP.L2Reg);
        ep_loss=ep_loss+extractdata(loss);
    end
    epoch_losses(epoch)=ep_loss/n_batch;

    vl=0;
    for vi=1:numel(XValC)
        val_global_i=nTrn+vi;
        t0_day=pred_time_inds(val_global_i);
        win_s=max(1,t0_day-sqln+1); win_e=t0_day; n_win=win_e-win_s+1;
        bw_v=struct();
        bw_v.X       =XC_full{val_global_i};
        bw_v.Rt_ref  =Rt_ref_tr(val_global_i);
        bw_v.reliable=reliable_tr(val_global_i);
        bw_v.ef      =epoch_flag(pred_time_inds(val_global_i));
        bw_v.S =S_sn(win_s:win_e);  bw_v.E =E_sn(win_s:win_e);
        bw_v.Iv=I_sn(win_s:win_e);  bw_v.R =R_sn(win_s:win_e);
        bw_v.u =u_ts(win_s:win_e);  bw_v.d =delta_t(win_s:win_e);
        bw_v.a =alpha_s(win_s:win_e);
        if n_win<sqln
            pad=sqln-n_win;
            bw_v.S =[repmat(bw_v.S(1), pad,1);  bw_v.S];
            bw_v.E =[repmat(bw_v.E(1), pad,1);  bw_v.E];
            bw_v.Iv=[repmat(bw_v.Iv(1),pad,1); bw_v.Iv];
            bw_v.R =[repmat(bw_v.R(1), pad,1);  bw_v.R];
            bw_v.u =[repmat(bw_v.u(1), pad,1);  bw_v.u];
            bw_v.d =[repmat(bw_v.d(1), pad,1);  bw_v.d];
            bw_v.a =[repmat(bw_v.a(1), pad,1);  bw_v.a];
        end
        loss_v=dlfeval(@pinn_loss_fn,net,{bw_v}, ...
            lam_phys_S,lam_phys_E,lam_phys_I,lam_phys_R,lam_mass,lam_rho_Rt, ...
            lam_eps_reg_base,YN_full(val_global_i,:),lw_sqrt,pm_d,ps_d, ...
            last_p(val_global_i,:),bounds);
        vl=vl+extractdata(loss_v);
    end
    val_losses(epoch)=vl/numel(XValC);

    if val_losses(epoch)<best_loss
        best_loss=val_losses(epoch); best_net=net; no_improve=0;
    else
        no_improve=no_improve+1;
    end

    if epoch>warmup_epochs
        if val_losses(epoch)<best_val_for_plateau
            best_val_for_plateau=val_losses(epoch);
            plateau_count=0; lr_at_plateau_start=cur_lr;
        else
            plateau_count=plateau_count+1;
            frac=plateau_count/plateau_patience;
            cosine_factor=0.5*(1+cos(pi*frac));
            lr_target=max(lr_at_plateau_start*lr_decay_factor,lr_min);
            new_lr=max(lr_target+(lr_at_plateau_start-lr_target)*cosine_factor,lr_min);
            if new_lr<cur_lr-1e-10, cur_lr=new_lr; end
        end
        if plateau_count>=plateau_patience
            new_lr_final=max(lr_at_plateau_start*lr_decay_factor,lr_min);
            if new_lr_final<lr_at_plateau_start-1e-10
                fprintf('  [LR cycle end] epoch %d: %.2e -> %.2e\n', ...
                    epoch,lr_at_plateau_start,new_lr_final);
                cur_lr=new_lr_final; avg_grad=[]; avg_sq_g=[];
                lr_at_plateau_start=new_lr_final;
            end
            plateau_count=0; best_val_for_plateau=val_losses(epoch);
        end
    end

    if mod(epoch,5)==0 || epoch==1
        if isnan(prev_val_loss_mon)||prev_val_loss_mon==0
            vp_str='    --     ';
        else
            vp_pct=100*(val_losses(epoch)-prev_val_loss_mon)/abs(prev_val_loss_mon);
            if vp_pct<-5, vtag='vv'; elseif vp_pct<-1, vtag='v ';
            elseif vp_pct<1, vtag='->'; else, vtag='^ '; end
            vp_str=sprintf('%+6.1f%% %s',vp_pct,vtag);
        end
        prev_val_loss_mon=val_losses(epoch);

        gap=epoch_losses(epoch)-val_losses(epoch);
        if isnan(prev_gap_mon)
            gap_str='    --     ';
        else
            dgap=gap-prev_gap_mon;
            if gap<0, gap_str=sprintf('%+7.4f inv',gap);
            elseif dgap>0.5*abs(gap), gap_str=sprintf('%+7.4f OVF',gap);
            else, gap_str=sprintf('%+7.4f ok ',gap);
            end
        end
        prev_gap_mon=gap;

        phys_proxy=epoch_losses(epoch)*lam_sum_mon/(1+lam_sum_mon);
        if isnan(init_phys_res), init_phys_res=phys_proxy+eps; end
        phys_pct=100*phys_proxy/init_phys_res;
        if phys_pct<50, ptag='stab'; elseif phys_pct<90, ptag='conv'; else, ptag='high'; end
        phys_str=sprintf('%5.1f%% %s',phys_pct,ptag);

        fprintf('%-3d  %-12.6f %-12.6f %-10.2e %-13s %-13s %-13s\n', ...
            epoch,epoch_losses(epoch),val_losses(epoch),cur_lr, ...
            vp_str,gap_str,phys_str);
    end

    if no_improve>=patience
        fprintf('Early stopping at epoch %d\n',epoch); break;
    end
end
net=best_net;
fprintf('Training complete. Best val loss: %.6f\n',best_loss);

%% ==================== PART 7: WALK-FORWARD CV ====================
fprintf('\n=== PART 7: Walk-Forward Cross-Validation ===\n');

cv_trn_init=200; cv_val_len=100; cv_step=100;
cv_starts=(cv_trn_init+1):cv_step:(numSmpl-cv_val_len+1);
n_folds=numel(cv_starts);
beta_pred_cv_full = nan(n_days,1);
rho_pred_cv_full  = nan(n_days,1);
eps_pred_cv_full  = nan(n_days,1);

fold_data=cell(n_folds,1);
for fold=1:n_folds
    vs=cv_starts(fold);  ve=min(vs+cv_val_len-1,numSmpl);
    nT=vs-1;  nV=ve-vs+1;
    vt_f=pred_time_inds(vs:ve);
    fd.vs=vs; fd.ve=ve; fd.nT=nT; fd.nV=nV; fd.vt=vt_f;
    fd.shade_lo=vt_f(1); fd.shade_hi=vt_f(end);
    fd.skip=(nT<cv_trn_init||nV<5);
    if ~fd.skip
        fd.X_trn=X_full(1:nT,:,:);  fd.X_val=X_full(vs:ve,:,:);
        fd.lp_trn=last_p(1:nT,:);   fd.lp_val=last_p(vs:ve,:);
        fd.Y_trn=Y_full(1:nT,:);    fd.Y_val=Y_full(vs:ve,:);
        fd.beta_ref=beta_SEIR(vt_f); fd.rho_ref=rho_SEIR(vt_f);
        fd.epsilon_ref=epsilon_SEIR(vt_f);
        fd.Rt_ref_fold=Rt_ref_tr(1:nT);
        fd.rel_fold=reliable_tr(1:nT);
        fd.ef_fold=epoch_flag(pred_time_inds(1:nT));
        fd.val_sample_inds = vs:ve;
    else
        fd.X_trn=[]; fd.X_val=[]; fd.lp_trn=[]; fd.lp_val=[];
        fd.Y_trn=[]; fd.Y_val=[]; fd.beta_ref=[]; fd.rho_ref=[];
        fd.epsilon_ref=[]; fd.Rt_ref_fold=[]; fd.rel_fold=[]; fd.ef_fold=[];
        fd.val_sample_inds=[];
    end
    fold_data{fold}=fd;
end

cv_r2=nan(n_folds,3); cv_mae=nan(n_folds,3); cv_shade=zeros(n_folds,2);
cv_Yh=cell(n_folds,1); cv_vt=cell(n_folds,1);

for fold=1:n_folds
    fd=fold_data{fold};
    if fd.skip, continue; end
    nT_loc=fd.nT;  nV_loc=fd.nV;

    Xtr_cv_f=reshape(fd.X_trn,[],numFtr);          fm_cv=mean(Xtr_cv_f,1);
    fs_cv=std(Xtr_cv_f,0,1);  fs_cv(fs_cv==0)=1;   Yd_cv=fd.Y_trn-fd.lp_trn;
    pm_cv=mean(Yd_cv,1,'omitnan'); ps_cv=std(Yd_cv,0,1,'omitnan');
    ps_cv=max(ps_cv,ps_d_floors);

    XTrnN_cv=(fd.X_trn-reshape(fm_cv,[1,1,numFtr]))./reshape(fs_cv,[1,1,numFtr]);
    XValN_cv=(fd.X_val-reshape(fm_cv,[1,1,numFtr]))./reshape(fs_cv,[1,1,numFtr]);
    XTrnC_cv=cell(nT_loc,1);
    for ii=1:nT_loc, XTrnC_cv{ii}=squeeze(XTrnN_cv(ii,:,:))'; end
    XValC_cv=cell(nV_loc,1);
    for ii=1:nV_loc, XValC_cv{ii}=squeeze(XValN_cv(ii,:,:))'; end
    YTrnN_cv=(Yd_cv-pm_cv)./ps_cv.*lw_sqrt;
    YValN_cv=(fd.Y_val-fd.lp_val-pm_cv)./ps_cv.*lw_sqrt;

    ep_cv=min(60,max(30,round(60*nT_loc/numSmpl)));
    net_cv=finetune_from_net(net,HP,XTrnC_cv,YTrnN_cv,XValC_cv,YValN_cv, ...
        ep_cv,15, ...
        lam_phys_S,lam_phys_E,lam_phys_I,lam_phys_R,lam_mass,lam_rho_Rt,lam_eps_reg_base, ...
        lw_sqrt,pm_cv,ps_cv,S_sn,E_sn,I_sn,R_sn, ...
        u_ts,delta_t,alpha_s,sqln,fd.X_trn,fd.lp_trn, ...
        fd.Rt_ref_fold,fd.rel_fold,fd.ef_fold, ...
        fd.val_sample_inds,pred_time_inds,bounds);

    Yh_cv_f=zeros(nV_loc,3);
    for ii=1:nV_loc
        p_raw=extractdata(predict(net_cv,dlarray(XValC_cv{ii},'CBT')));
        p_raw=p_raw(:,end);
        Yh_cv_f(ii,:)=fd.lp_val(ii,:)+decode_yd(p_raw,lw_sqrt,ps_cv,pm_cv);
    end
    Yh_cv_f(:,1)=min(max(Yh_cv_f(:,1),b_min),b_max);
    Yh_cv_f(:,2)=min(max(Yh_cv_f(:,2),r_min),r_max);
    Yh_cv_f(:,3)=min(max(Yh_cv_f(:,3),e_min),e_max);

    vt_f=fd.vt;
    Sc_cv=S_sn(vt_f(1)-1); Ec_cv=E_sn(vt_f(1)-1);
    Ic_cv=I_sn(vt_f(1)-1); Rc_cv=R_sn(vt_f(1)-1);
    for ii=1:nV_loc
        ti_cv=vt_f(ii);
        if mod(ii-1,restart_interval)==0 && ii>1
            Sc_cv=S_sn(ti_cv-1); Ec_cv=E_sn(ti_cv-1);
            Ic_cv=I_sn(ti_cv-1); Rc_cv=R_sn(ti_cv-1);
        end
        b_i=Yh_cv_f(ii,1); r_i=Yh_cv_f(ii,2); e_i_cv=Yh_cv_f(ii,3);
        u_i=u_ts(ti_cv); d_i=delta_t(ti_cv); a_i=alpha_s(ti_cv);
        foi=(1-u_i)*b_i*Sc_cv*Ic_cv;
        dSc=a_i*(1-Sc_cv)-foi+d_i*Ic_cv*Sc_cv;
        dEc=foi-(e_i_cv+a_i)*Ec_cv+d_i*Ic_cv*Ec_cv;
        dIc=e_i_cv*Ec_cv-(r_i+d_i+a_i)*Ic_cv+d_i*Ic_cv*Ic_cv;
        dRc=r_i*Ic_cv-a_i*Rc_cv+d_i*Ic_cv*Rc_cv;
        Sc_cv=max(Sc_cv+dSc,0); Ec_cv=max(Ec_cv+dEc,0);
        Ic_cv=max(Ic_cv+dIc,0); Rc_cv=max(Rc_cv+dRc,0);
        tot=Sc_cv+Ec_cv+Ic_cv+Rc_cv;
        if tot>1e-8
            Sc_cv=Sc_cv/tot; Ec_cv=Ec_cv/tot;
            Ic_cv=Ic_cv/tot; Rc_cv=Rc_cv/tot;
        end
        Sc_cv=(1-kappa_nudge_S)*Sc_cv+kappa_nudge_S*S_sn(ti_cv);
        Ec_cv=(1-kappa_nudge_E)*Ec_cv+kappa_nudge_E*E_sn(ti_cv);
        Ic_cv=(1-kappa_nudge_I)*Ic_cv+kappa_nudge_I*I_sn(ti_cv);
        Rc_cv=(1-kappa_nudge_R)*Rc_cv+kappa_nudge_R*R_sn(ti_cv);
        tot=Sc_cv+Ec_cv+Ic_cv+Rc_cv;
        if tot>1e-8
            Sc_cv=Sc_cv/tot; Ec_cv=Ec_cv/tot;
            Ic_cv=Ic_cv/tot; Rc_cv=Rc_cv/tot;
        end
    end

    [m1,~,r1,~] =compute_metrics(fd.beta_ref,    Yh_cv_f(:,1));
    [m2,~,r2f,~]=compute_metrics(fd.rho_ref,     Yh_cv_f(:,2));
    [m3,~,r3,~] =compute_metrics(fd.epsilon_ref, Yh_cv_f(:,3));

    cv_shade(fold,:)=[fd.shade_lo,fd.shade_hi];
    cv_mae(fold,:)=[m1,m2,m3];  cv_r2(fold,:)=[r1,r2f,r3];
    cv_Yh{fold}=Yh_cv_f;  cv_vt{fold}=fd.vt;
end

for fold=1:n_folds
    if isempty(cv_vt{fold}), continue; end
    vt=cv_vt{fold};  Yh_cv=cv_Yh{fold};
    beta_pred_cv_full(vt)=Yh_cv(:,1);
    rho_pred_cv_full(vt) =Yh_cv(:,2);
    eps_pred_cv_full(vt) =Yh_cv(:,3);
    fprintf('  Fold %d: beta R2=%.4f  rho R2=%.4f  eps R2=%.4f\n',fold, ...
        cv_r2(fold,1),cv_r2(fold,2),cv_r2(fold,3));
end
ok_fn=@(x) x(isfinite(x));
fprintf('\n  CV Mean R2: beta=%.4f  rho=%.4f  eps=%.4f\n', ...
    mean(ok_fn(cv_r2(:,1))),mean(ok_fn(cv_r2(:,2))),mean(ok_fn(cv_r2(:,3))));

%% ==================== PART 8: FULL-DATA PREDICTIONS ====================
fprintf('\n=== PART 8: Full-Data Predictions ===\n');

beta_pred_full = nan(n_days,1); rho_pred_full = nan(n_days,1); epsilon_pred_full = nan(n_days,1);
for i=1:numSmpl
    p_raw=extractdata(predict(net,dlarray(XC_full{i},'CBT'))); p_raw=p_raw(:,end);
    yd_i=decode_yd(p_raw,lw_sqrt,ps_d,pm_d);   p_rec=last_p(i,:)+yd_i;
    beta_pred_full(pred_time_inds(i))   =min(max(p_rec(1),b_min),b_max);
    rho_pred_full(pred_time_inds(i))    =min(max(p_rec(2),r_min),r_max);
    epsilon_pred_full(pred_time_inds(i))=min(max(p_rec(3),e_min),e_max);
end

S_ode_full=nan(n_days,1); E_ode_full=nan(n_days,1);
I_ode_full=nan(n_days,1); R_ode_full=nan(n_days,1);

v_start=pred_time_inds(1);
Sc=S_sn(v_start-1); Ec=E_sn(v_start-1); Ic=I_sn(v_start-1); Rc=R_sn(v_start-1);
for i=1:numSmpl
    ti=pred_time_inds(i);
    if mod(i-1,restart_interval)==0 && i>1
        Sc=S_sn(ti-1); Ec=E_sn(ti-1); Ic=I_sn(ti-1); Rc=R_sn(ti-1);
    end
    b_i=beta_pred_full(ti); r_i=rho_pred_full(ti); e_i=epsilon_pred_full(ti);
    if isnan(b_i)||isnan(e_i), continue; end
    u_i=u_ts(ti); d_i=delta_t(ti); a_i=alpha_s(ti);
    foi=(1-u_i)*b_i*Sc*Ic;
    dSc=a_i*(1-Sc)-foi+d_i*Ic*Sc;
    dEc=foi-(e_i+a_i)*Ec+d_i*Ic*Ec;
    dIc=e_i*Ec-(r_i+d_i+a_i)*Ic+d_i*Ic*Ic;
    dRc=r_i*Ic-a_i*Rc+d_i*Ic*Rc;
    Sc=max(Sc+dSc,0); Ec=max(Ec+dEc,0); Ic=max(Ic+dIc,0); Rc=max(Rc+dRc,0);
    tot=Sc+Ec+Ic+Rc;
    if tot>1e-8, Sc=Sc/tot; Ec=Ec/tot; Ic=Ic/tot; Rc=Rc/tot; end
    Sc=(1-kappa_nudge_S)*Sc+kappa_nudge_S*S_sn(ti);
    Ec=(1-kappa_nudge_E)*Ec+kappa_nudge_E*E_sn(ti);
    Ic=(1-kappa_nudge_I)*Ic+kappa_nudge_I*I_sn(ti);
    Rc=(1-kappa_nudge_R)*Rc+kappa_nudge_R*R_sn(ti);
    tot=Sc+Ec+Ic+Rc;
    if tot>1e-8, Sc=Sc/tot; Ec=Ec/tot; Ic=Ic/tot; Rc=Rc/tot; end
    S_ode_full(ti)=Sc; E_ode_full(ti)=Ec; I_ode_full(ti)=Ic; R_ode_full(ti)=Rc;
end
vld_i=find(isfinite(I_ode_full));
if ~isempty(vld_i)
    tmp=causal_smooth(I_ode_full(vld_i),5);  
    I_ode_full(vld_i)=tmp(:);
end

beta_eff_full=nan(n_days,1); Rt_NGM_full=nan(n_days,1);
vld=find(~isnan(beta_pred_full)&~isnan(epsilon_pred_full)&~isnan(rho_pred_full));
if ~isempty(vld)
    beff_raw=causal_smooth(beta_pred_full(vld).*(1-u_ts(vld)),7);
    beta_eff_full(vld)=beff_raw(:);
    Rt_NGM_raw=(beta_eff_full(vld).*epsilon_pred_full(vld).*max(S_sn(vld),0))./ ...
        max((epsilon_pred_full(vld)+alpha_s(vld)).*(rho_pred_full(vld)+delta_t(vld)+alpha_s(vld)),1e-8);
    Rt_NGM_full(vld)=max(causal_smooth(Rt_NGM_raw(:),smooth_win_Rt),0);
end

valid_idx=pred_time_inds;
[mae_b,rmse_b,r2_b,nrmse_b]   =compute_metrics(beta_SEIR(valid_idx),    beta_pred_full(valid_idx));
[mae_r,rmse_r,r2_r,nrmse_r]   =compute_metrics(rho_SEIR(valid_idx),     rho_pred_full(valid_idx));
[mae_e,rmse_e,r2_e,nrmse_e]   =compute_metrics(epsilon_SEIR(valid_idx), epsilon_pred_full(valid_idx));
[mae_S,rmse_S,r2_S,nrmse_S]   =compute_metrics(S_sn(valid_idx),         S_ode_full(valid_idx));
[mae_E,rmse_E,r2_E,nrmse_E]   =compute_metrics(E_sn(valid_idx),         E_ode_full(valid_idx));
[mae_I,rmse_I,r2_I,nrmse_I]   =compute_metrics(I_sn(valid_idx),         I_ode_full(valid_idx));
[mae_R,rmse_R,r2_R,nrmse_R]   =compute_metrics(R_sn(valid_idx),         R_ode_full(valid_idx));

I_obs_valid=I_sn(valid_idx);    I_prd_valid=I_ode_full(valid_idx);
ok_I=isfinite(I_obs_valid)&isfinite(I_prd_valid);
pearson_I=corr(I_obs_valid(ok_I),I_prd_valid(ok_I),'Type','Pearson');
[ccc_I,bias_I]=compute_ccc(I_obs_valid(ok_I),I_prd_valid(ok_I));

E_obs_valid=E_sn(valid_idx);    E_prd_valid=E_ode_full(valid_idx);
ok_E=isfinite(E_obs_valid)&isfinite(E_prd_valid);
pearson_E=corr(E_obs_valid(ok_E),E_prd_valid(ok_E),'Type','Pearson');
[ccc_E,bias_E]=compute_ccc(E_obs_valid(ok_E),E_prd_valid(ok_E));

reliable_valid=reliable(valid_idx);
Rt_SEIR_valid=max(fillmissing(Rt_SEIR(valid_idx),'movmedian',[win_Size 0]),0);
Rt_SEIR_valid=max(causal_smooth(Rt_SEIR_valid,smooth_win_Rt),0);
Rt_NGM_valid =Rt_NGM_full(valid_idx);
ok_rt_seir   =isfinite(Rt_SEIR_valid)&isfinite(Rt_NGM_valid)&reliable_valid;
[mae_Rt,rmse_Rt,r2_Rt,nrmse_Rt]=compute_metrics( ...
    Rt_SEIR_valid(ok_rt_seir),Rt_NGM_valid(ok_rt_seir));

fprintf('   S R2=%.4f and R R2=%.4f expected high (near-monotone).\n',r2_S,r2_R);
fprintf('   I  R2=%.4f  MAE=%.4e  nRMSE=%.4f (kappa_I=%.2f)\n',r2_I,mae_I,nrmse_I,kappa_nudge_I);
fprintf('   I  Pearson-r=%.4f  CCC=%.4f  Bias=%.2e\n',pearson_I,ccc_I,bias_I);
fprintf('   E  R2=%.4f  MAE=%.4e  Pearson-r=%.4f  CCC=%.4f\n',r2_E,mae_E,pearson_E,ccc_E);
fprintf('   Rt R2=%.4f  MAE=%.4f  (Rt_NGM vs Rt_SEIR)\n',r2_Rt,mae_Rt);

metrics_table=table( ...
    {'beta';'rho';'epsilon';'S';'E';'I';'R';'Rt_NGM_vs_SEIR'}, ...
    [mae_b;mae_r;mae_e;mae_S;mae_E;mae_I;mae_R;mae_Rt], ...
    [rmse_b;rmse_r;rmse_e;rmse_S;rmse_E;rmse_I;rmse_R;rmse_Rt], ...
    [r2_b;r2_r;r2_e;r2_S;r2_E;r2_I;r2_R;r2_Rt], ...
    [nrmse_b;nrmse_r;nrmse_e;nrmse_S;nrmse_E;nrmse_I;nrmse_R;nrmse_Rt], ...
    'VariableNames',{'Variable','MAE','RMSE','R2','nRMSE'});
disp(metrics_table);
writetable(metrics_table,'metrics_PINN_LSTM.csv');

%% ==================== PART 9: 100-DAY ROLLING FORECAST ====================
fprintf('\n=== PART 9: 100-Day Rolling Forecast ===\n');

forecast_days=100;
u_future=u_ts(end); delta_future=delta_t(end); alpha_future=alpha_s(end);

startF =dates(end)+days(1);
doyF   =day(startF+days(0:forecast_days-1),'dayofyear')';
doyHist=day(dates,'dayofyear');
W_doy  =nan(366,3);
for d=1:366
    idx_d=(doyHist==d);
    if any(idx_d), W_doy(d,:)=mean(met_smooth(idx_d,:),1,'omitnan'); end
end
weather_f=zeros(forecast_days,3);
for k=1:forecast_days
    d=doyF(k);
    if all(isfinite(W_doy(d,:))), weather_f(k,:)=W_doy(d,:);
    else, weather_f(k,:)=met_smooth(end,:); end
end

pool_I_raw=nan(n_folds*cv_val_len,1); pidx=0;
for fold=1:n_folds
    if isempty(cv_vt{fold}), continue; end
    vt_f2=cv_vt{fold}; n_blk=numel(vt_f2);
    pool_I_raw(pidx+(1:n_blk))=I_sn(vt_f2)-I_ode_full(vt_f2); pidx=pidx+n_blk;
end
pool_I=pool_I_raw(isfinite(pool_I_raw));
if numel(pool_I)<14
    vld_res=find(isfinite(I_ode_full)&isfinite(I_sn));
    pool_I=I_sn(vld_res)-I_ode_full(vld_res);
    fprintf('  [Note] CV pool empty - using full-data ODE residuals for CI bootstrap\n');
end
ci_I=block_bootstrap_ci(pool_I,forecast_days,500,14,1.96);

win_raw=DM(end-sqln+1:end,:); xwin=((win_raw-fm)./fs)';
hist_win=min(28,n_days);
b_k=min(max(median(beta_SEIR(max(1,end-13):end)),b_min),b_max);
r_k=min(max(median(rho_SEIR( max(1,end-13):end)),r_min),r_max);
e_k=min(max(median(epsilon_SEIR(max(1,end-13):end)),e_min),e_max);
b_med=min(max(mean(beta_SEIR(max(1,end-hist_win+1):end)),b_min),b_max);
r_med=min(max(mean(rho_SEIR( max(1,end-hist_win+1):end)),r_min),r_max);
e_med=min(max(mean(epsilon_SEIR(max(1,end-hist_win+1):end)),e_min),e_max);
relax=0.08;

x_fcst=max([S_sn(end);E_sn(end);I_sn(end);R_sn(end)],0);
x_fcst=x_fcst/sum(x_fcst);
S_fc=zeros(forecast_days,1); E_fc=zeros(forecast_days,1);
I_fc=zeros(forecast_days,1); R_fc=zeros(forecast_days,1);
Rt_fc=zeros(forecast_days,1); beta_fc=zeros(forecast_days,1);
rho_fc=zeros(forecast_days,1); eps_fc=zeros(forecast_days,1);

x_fcst_r=x_fcst; xwin_tmp=xwin;
for k=1:forecast_days
    X_dl_k=dlarray(single(xwin_tmp),'CBT');
    p_raw_k=extractdata(predict(net,X_dl_k));
    p_raw_k=p_raw_k(:,end);
    yd=decode_yd(p_raw_k,lw_sqrt,ps_d,pm_d);
    b_k=(1-relax)*min(max(b_k+yd(1),b_min),b_max)+relax*b_med;
    r_k=(1-relax)*min(max(r_k+yd(2),r_min),r_max)+relax*r_med;
    e_k=(1-relax)*min(max(e_k+yd(3),e_min),e_max)+relax*e_med;
    b_k=double(b_k); r_k=double(r_k); e_k=double(e_k);
    u_f=double(u_future); d_f=double(delta_future); a_f=double(alpha_future);

    foi=(1-u_f)*b_k*x_fcst_r(1)*x_fcst_r(3);
    x_new=x_fcst_r+[a_f*(1-x_fcst_r(1))-foi+d_f*x_fcst_r(3)*x_fcst_r(1);
                    foi-(e_k+a_f)*x_fcst_r(2)+d_f*x_fcst_r(3)*x_fcst_r(2);
                    e_k*x_fcst_r(2)-(r_k+d_f+a_f)*x_fcst_r(3)+d_f*x_fcst_r(3)^2;
                    r_k*x_fcst_r(3)-a_f*x_fcst_r(4)+d_f*x_fcst_r(3)*x_fcst_r(4)];
    x_fcst_r=max(x_new,0); s=sum(x_fcst_r);
    if s>1e-8, x_fcst_r=x_fcst_r/s; else, x_fcst_r=[1;0;0;0]; end

    S_fc(k)=x_fcst_r(1); E_fc(k)=x_fcst_r(2);
    I_fc(k)=x_fcst_r(3); R_fc(k)=x_fcst_r(4);
    beta_fc(k)=b_k; rho_fc(k)=r_k; eps_fc(k)=e_k;
    Rt_fc(k)=max((b_k*(1-u_f)*e_k*x_fcst_r(1))/max((e_k+a_f)*(r_k+d_f+a_f),1e-8),0);

    next_row=[x_fcst_r(1),x_fcst_r(2),x_fcst_r(3),x_fcst_r(4), ...
              u_f,d_f,weather_f(k,:),0];
    xwin_tmp=[xwin_tmp(:,2:end), single(((next_row-fm)./fs)')];
end

I_ci_lo=max(I_fc+ci_I(:,1),0); I_ci_hi=min(I_fc+ci_I(:,2),1);
Rt_last=Rt_NGM_full(find(~isnan(Rt_NGM_full),1,'last'));
if Rt_last<1, stab='Declining'; elseif Rt_last<1.5, stab='Near-threshold'; else, stab='Growing'; end
fprintf('  Last Rt = %.4f [%s]\n',Rt_last,stab);

%% ==================== PART 10: MIA ====================
fprintf('\n=== PART 10: MIA ===\n');

perturb_lvl=[-2,-1,0,1,2];  n_perturb=numel(perturb_lvl);
T_std=std(met_smooth(:,1)); RH_std=std(met_smooth(:,2)); WS_std=std(met_smooth(:,3));
DM_pert=struct();
for p=1:n_perturb
    sig=perturb_lvl(p);
    DM_T=DM;  DM_T(:,col_T)=DM(:,col_T)+sig*T_std;    DM_pert(p).T=DM_T;
    DM_RH=DM; DM_RH(:,col_RH)=DM(:,col_RH)+sig*RH_std; DM_pert(p).RH=DM_RH;
    DM_WS=DM; DM_WS(:,col_WS)=DM(:,col_WS)+sig*WS_std; DM_pert(p).WS=DM_WS;
end
last_p_mia=last_p(1:nTrn,:);
var_names_mia={'T','RH','WS'};

n_ens=30;  n_boot_mia=500;
ens_mia=zeros(n_ens,n_perturb,3,3);
fprintf('  Training MIA ensemble (n_ens=%d)...\n',n_ens);

for e_i=1:n_ens
    rng(e_i*13+7,'twister');
    net_e=build_and_train_dl(HP,numFtr,XTrnC,YTrnN,XValC,YValN, ...
        50,10, ...
        lam_phys_S,lam_phys_E,lam_phys_I,lam_phys_R,lam_mass,lam_rho_Rt,lam_eps_reg_base, ...
        lw_sqrt,pm_d,ps_d,S_sn,E_sn,I_sn,R_sn, ...
        u_ts,delta_t,alpha_s,sqln,X_full(1:nTrn,:,:),last_p_mia, ...
        Rt_ref_tr(1:nTrn),reliable_tr(1:nTrn),epoch_flag(pred_time_inds(1:nTrn)), ...
        (nTrn+1):(nTrn+nVal), pred_time_inds, bounds);
    mia_e=zeros(n_perturb,3,3);
    for wv=1:3
        [bv,rv,ev]=rolling_mia_batch(DM_pert,var_names_mia{wv},net_e,fm,fs, ...
            pm_d,ps_d,lw_sqrt,sqln,n_perturb, ...
            b_min,b_max,r_min,r_max,e_min,e_max,last_p_mia);
        mia_e(:,1,wv)=bv; mia_e(:,2,wv)=rv; mia_e(:,3,wv)=ev;
    end
    ens_mia(e_i,:,:,:)=mia_e;
    fprintf('    Ensemble member %d/%d done\n',e_i,n_ens);
end

ens_mean=squeeze(mean(ens_mia,1));
ens_bslo=zeros(n_perturb,3,3);  ens_bshi=zeros(n_perturb,3,3);
for pm_i=1:3
    for v=1:3
        bm=zeros(n_boot_mia,n_perturb);
        for b=1:n_boot_mia
            ib=randi(n_ens,n_ens,1);
            bm(b,:)=mean(ens_mia(ib,:,pm_i,v),1);
        end
        tmp_lo=prctile(bm,2.5,1)';  ens_bslo(:,pm_i,v)=tmp_lo;
        tmp_hi=prctile(bm,97.5,1)'; ens_bshi(:,pm_i,v)=tmp_hi;
    end
end

sign_consist=zeros(3,3);
for pm_i=1:3
    for v=1:3
        slopes=squeeze(ens_mia(:,end,pm_i,v)-ens_mia(:,1,pm_i,v));
        sign_consist(pm_i,v)=sum(slopes>0)/n_ens;
    end
end

beta_T=ens_mean(:,1,1); beta_RH=ens_mean(:,1,2); beta_WS=ens_mean(:,1,3);
rho_T=ens_mean(:,2,1);  rho_RH=ens_mean(:,2,2);  rho_WS=ens_mean(:,2,3);
eps_T=ens_mean(:,3,1);  eps_RH=ens_mean(:,3,2);  eps_WS=ens_mean(:,3,3);
var_names={'T','RH','WS'};

mia_table=table(perturb_lvl',beta_T,beta_RH,beta_WS,rho_T,rho_RH,rho_WS,eps_T,eps_RH,eps_WS, ...
    'VariableNames',{'Sigma','beta_T','beta_RH','beta_WS', ...
    'rho_T','rho_RH','rho_WS','eps_T','eps_RH','eps_WS'});
disp(mia_table);
writetable(mia_table,'mia_PINN_LSTM.csv');

%% ==================== PART 11: FIGURES ====================
fprintf('\n=== PART 11: Generating Figures ===\n');
outdir='figures_PINN_LSTM';
if ~exist(outdir,'dir'), mkdir(outdir); end
chosenFont='Times New Roman';
set(groot,'DefaultAxesFontName',chosenFont,'DefaultTextFontName',chosenFont, ...
    'DefaultLegendFontName',chosenFont,'DefaultAxesFontWeight','bold', ...
    'DefaultTextInterpreter','tex','DefaultLegendInterpreter','tex');
bfs=9; lfs=7; LW=1.5;
cfg_fig.useColor=true;
sAx=@(ax) set(ax,'FontSize',bfs,'FontWeight','bold','LineWidth',1.0, ...
                  'Box','on','TickLabelInterpreter','tex');
blendW  =@(c,a) a.*c+(1-a).*ones(size(c));
S_data  ={[0.00 0.18 0.45],'-', 'o',[0.00 0.18 0.45]};
S_lstm  ={[0.72 0.08 0.00],'--','^',[0.72 0.08 0.00]};
S_fcst  ={[0 0 0],         '-.',  'd',[0 0 0]};
ci_blend=blendW([0.55 0.25 0.75],0.72);
ci_edge =[0.55 0.25 0.75]*0.70;
lw_fcst =LW+1.2;
t_axis=1:n_days; mkSp=@(n) max(1,floor(n/18)); mkSz=4; sp1=mkSp(n_days);
var_colors=[0.85 0.93 0.97;0.85 0.97 0.85;0.97 0.97 0.75;0.97 0.88 0.75];
var_colors=blendW(var_colors,0.45);
var_start_idx=zeros(n_vrnt,1); var_end_idx=zeros(n_vrnt,1);
for vv=1:n_vrnt
    si2=find(dates>=SI_vrnt{vv,1},1,'first'); if isempty(si2),si2=1; end
    ei2=find(dates<=SI_vrnt{vv,2},1,'last');  if isempty(ei2),ei2=n_days; end
    var_start_idx(vv)=si2; var_end_idx(vv)=ei2;
end
set(groot,'DefaultTextInterpreter','tex');
set(groot,'DefaultAxesTickLabelInterpreter','tex');

%% Fig 1 - Parameters
fig1=figure('Color','w', ...
    'Position',[80 80 600 520], ...
    'PaperPositionMode','auto');

pLbl={'\beta (t)','\rho (t)','\epsilon (t)'};
pObs={beta_SEIR,rho_SEIR,epsilon_SEIR};
pPrd={beta_pred_full,rho_pred_full,epsilon_pred_full};

axF1=gobjects(1,3);

for k=1:3
    axF1(k)=subplot(3,1,k);
    hold on;
    yl_obs=[min(pObs{k})*0.88,max(pObs{k})*1.12];
    if diff(yl_obs)<1e-6
        yl_obs=yl_obs+[-1e-4 1e-4];
    end
    idx=1:sp1:n_days;
    plot(t_axis,pObs{k},'-','Color',S_data{1},'LineWidth',LW,'HandleVisibility','off');
    plot(idx,pObs{k}(idx),'o','Color',S_data{1},'MarkerFaceColor',S_data{1}, ...
        'MarkerSize',mkSz,'DisplayName','SEIR (estimated)');
    vld_p=find(~isnan(pPrd{k}));
    if ~isempty(vld_p)
        plot(t_axis,pPrd{k},'--','Color',S_lstm{1},'LineWidth',LW,'HandleVisibility','off');
        idxL=vld_p(1):sp1:vld_p(end);
        plot(idxL,pPrd{k}(idxL),'s','Color',S_lstm{1},'MarkerFaceColor',S_lstm{1}, ...
            'MarkerSize',mkSz,'DisplayName','SEIR-LSTM');
    end
    ylabel(pLbl{k},'FontSize',bfs+4,'FontWeight','bold', ...
        'Interpreter','tex','Color',[0 0 0]);
    if k==3
        xlabel('\bfDay','FontSize',bfs,'Interpreter','tex');
    end
    ylim(yl_obs); grid off;  sAx(gca);
    if k==1
        drawnow;
        lg1 = legend('show','Box','off','FontSize',lfs+2);
        set(lg1,'AutoUpdate','off','FontName',chosenFont,'Interpreter','tex', ...
            'Color','none','EdgeColor','none','TextColor',[0 0 0]);
        lg1.Units='normalized'; ax1_pos=axF1(1).Position; lg1_w=ax1_pos(3)*0.28;
        lg1_h=ax1_pos(4)*0.45; lg1_x=ax1_pos(1)+ax1_pos(3)-lg1_w-0.01;
        lg1_y=ax1_pos(2)+ax1_pos(4)*0.56; lg1.Position=[lg1_x lg1_y lg1_w lg1_h];
    end
end

linkaxes(axF1,'x'); xlim(axF1(1),[1 n_days]);
set(findall(fig1,'-property','FontName'),'FontName',chosenFont);
exportEPS(fig1,fullfile(outdir,'Fig1_Parameters.eps'), cfg_fig.useColor);

%% Fig 2 - States + Forecast
t_fcst_ax=n_days+(1:forecast_days);
sObs={S_sn,E_sn,I_sn,R_sn}; sFst={S_fc,E_fc,I_fc,R_fc};
sOde={S_ode_full,E_ode_full,I_ode_full,R_ode_full};
sLbl={'\bfs','\bfe','\bfi','\bfr'};

fig2=figure('Color','w','Position',[80 80 600 560],'PaperPositionMode','auto');

axH=gobjects(1,4); spH=mkSp(n_days);
for k=1:4
    axH(k)=subplot(4,1,k); hold on;
    all_v=[sObs{k};sFst{k};sOde{k}(isfinite(sOde{k}))]; all_v=all_v(isfinite(all_v)&all_v>=0);
    dr=max(all_v)-min(all_v); pad=max(0.05*dr,1e-5); yl_hi=max(all_v)+pad;
    if k==2 || k==3
        yl_lo=-0.04*dr;
    else
        yl_lo=max(0,min(all_v)-pad);
    end
    if yl_hi<=yl_lo+1e-8
        yl_hi=yl_lo+1e-3;
    end
    if k==3
        ci_shade_fill(gca,t_fcst_ax,I_ci_lo',I_ci_hi',ci_blend,ci_edge,cfg_fig.useColor);
    end
    idxH=1:spH:n_days;
    plot(t_axis,sObs{k},'-','Color',S_data{1},'LineWidth',LW,'HandleVisibility','off');
    plot(t_axis(idxH),sObs{k}(idxH),'o','Color',S_data{1},'MarkerFaceColor', ...
        S_data{1},'MarkerSize',mkSz,'DisplayName','Observed/Estimated');
    vld_ode=find(~isnan(sOde{k}));
    if ~isempty(vld_ode)
        sp_ode=max(1,floor(numel(vld_ode)/18));
        plot(vld_ode,sOde{k}(vld_ode),'--','Color',S_lstm{1},'LineWidth',LW, ...
            'HandleVisibility','off');
        plot(vld_ode(1:sp_ode:end), sOde{k}(vld_ode(1:sp_ode:end)),'^', ...
            'Color',S_lstm{1},'MarkerFaceColor',S_lstm{1}, ...
            'MarkerSize',mkSz,'DisplayName','ODE (SEIR-LSTM)');
    end
    plot([t_axis(end),t_fcst_ax],[sObs{k}(end),sFst{k}(:)'], '-.', ...
        'Color',S_fcst{1},'LineWidth',lw_fcst, 'DisplayName','Forecast');
    if k==3
        patch([NaN NaN],[NaN NaN],ci_blend,'FaceAlpha',1.0,'EdgeColor',ci_edge, ...
            'DisplayName','95% Bootstrap CI');
        Rt_at_end=Rt_NGM_full(find(~isnan(Rt_NGM_full),1,'last'));
        if isnan(Rt_at_end)
            Rt_at_end=1.0;
        end
        I_at_end=I_sn(n_days); yr=yl_hi-yl_lo;
        x_txt=n_days-0.06*(n_days-1); y_txt=I_at_end+0.13*yr;
        x_head=n_days; y_head=I_at_end+0.04*yr;
        plot(n_days,I_at_end,'ko','MarkerSize',5,'MarkerFaceColor','w', ...
            'LineWidth',1.2,'HandleVisibility','off');
        quiver(x_txt,y_txt,x_head-x_txt,y_head-y_txt,'k','LineWidth',0.9, ...
            'MaxHeadSize',0.5,'AutoScale','off','HandleVisibility','off');
        text(x_txt,y_txt+0.03*yr,sprintf('R_t = %.3f',Rt_at_end),'FontSize',lfs, ...
            'FontName',chosenFont,'FontWeight','bold','HorizontalAlignment','center', ...
            'VerticalAlignment','bottom','Interpreter','tex');
    end
    xline(n_days,'--k','LineWidth',1.0,'HandleVisibility','off');
    ylabel(sLbl{k},'FontSize',bfs+1,'FontWeight','bold','Interpreter','tex');
    if k==4
        xlabel('\bfDay','FontSize',bfs,'Interpreter','tex');
    end
    ylim([yl_lo,yl_hi]); grid off; sAx(gca);
end

linkaxes(axH,'x'); xlim(axH(1),[1,n_days+forecast_days+5]); drawnow;
lg2=legend(axH(3),'show','Box','off','FontSize',lfs+1);
set(lg2,'AutoUpdate','off','FontName',chosenFont,'Interpreter','tex', ...
    'Color','none','EdgeColor','none','TextColor',[0 0 0]);
lg2.Units='normalized'; ax3_pos=axH(3).Position; xl3=get(axH(3),'XLim');
nd_frac=(n_days-xl3(1))/(xl3(2)-xl3(1)); lg2_w=ax3_pos(3)*0.26;
lg2_h=ax3_pos(4)*0.32; lg2_x=ax3_pos(1)+ax3_pos(3)*(nd_frac-0.018)-lg2_w;
lg2_y=ax3_pos(2)+ax3_pos(4)*0.51;
lg2_x=max(ax3_pos(1)+0.004,min(lg2_x,ax3_pos(1)+ax3_pos(3)-lg2_w-0.004));
lg2_y=max(ax3_pos(2)+0.004,min(lg2_y,ax3_pos(2)+ax3_pos(4)-lg2_h-0.004));
lg2.Position=[lg2_x,lg2_y,lg2_w,lg2_h];
set(findall(fig2,'-property','FontName'),'FontName',chosenFont);
set(lg2,'FontName',chosenFont);
exportEPS(fig2,fullfile(outdir,'Fig2_States_Forecast.eps'),cfg_fig.useColor);

%% Fig 3 - Rt panel + daily cases
c_epi_fwd = [0.00 0.18 0.45];
c_epi_sm  = [0.10 0.55 0.10];
c_ngm     = [0.80 0.10 0.05];

mkSz_fwd = mkSz + 3; mkSz_sm  = mkSz + 2;

sp_fwd = max(1,floor(n_days/12));
sp_sm  = max(1,floor(n_days/12));
off_sm = max(1,floor(sp_sm/2));

fig3 = figure('Color','w','Position',[100 80 740 280],'PaperPositionMode','auto');

ax_top = subplot(2,1,1); hold(ax_top,'on');
yl5 = [0 6]; ylim(ax_top,yl5);

plot(ax_top,t_axis,EpiR_fwd_aligned,'-','Color',c_epi_fwd, ...
    'LineWidth',LW,'HandleVisibility','off');
plot(ax_top,t_axis(1:sp_fwd:end),EpiR_fwd_aligned(1:sp_fwd:end),'o', ...
    'MarkerFaceColor',c_epi_fwd,'MarkerEdgeColor','k','MarkerSize',mkSz_fwd, ...
    'LineWidth',0.5,'DisplayName','EpiFilter (forward)');

idx_sm = min(off_sm,n_days):sp_sm:n_days;
plot(ax_top,t_axis,EpiR_sm_aligned,'--','Color',c_epi_sm,'LineWidth',LW, ...
    'HandleVisibility','off');
plot(ax_top,t_axis(idx_sm), EpiR_sm_aligned(idx_sm),'^','MarkerFaceColor',c_epi_sm, ...
    'MarkerEdgeColor',c_epi_sm*0.6,'MarkerSize',mkSz_sm,'LineWidth',0.5, ...
    'DisplayName','EpiFilter (smoother)');

vld_rt = find(~isnan(Rt_NGM_full));
if ~isempty(vld_rt)
    plot(ax_top,vld_rt,Rt_NGM_full(vld_rt),'-.','Color',c_ngm, ...
        'LineWidth',LW+0.8,'DisplayName','LSTM-NGM');
end

yline(ax_top,1,'k--','LineWidth',0.9,'HandleVisibility','off');
ylabel(ax_top,'R_t','FontSize',bfs+2,'FontWeight','bold','Interpreter','tex');
ylim(ax_top,yl5); grid(ax_top,'off');
set(ax_top,'TickLabelInterpreter','tex'); sAx(ax_top);

lg3 = legend(ax_top,'show','Location','northeast','Box','off');
set(lg3,'AutoUpdate','off','Interpreter','tex','FontName',chosenFont, ...
    'FontSize',lfs+2,'TextColor',[0 0 0]);

ax_bot = subplot(2,1,2); hold(ax_bot,'on');
I_daily_plot = max(incd_raw,0); avg7 = movmean(I_daily_plot,[6 0],'omitnan');

patch(ax_bot,[t_axis,fliplr(t_axis)],[I_daily_plot',zeros(1,n_days)], ...
    [0.55 0.55 0.55],'EdgeColor','none','DisplayName','Daily cases');
plot(ax_bot,t_axis,avg7,'-','Color',[0.85 0.10 0.10], ...
    'LineWidth',LW,'DisplayName','7-day avg');

ylim(ax_bot,[0,max(I_daily_plot)*1.15]);
ylabel(ax_bot,'Daily cases','FontSize',bfs,'FontWeight','bold','Interpreter','tex');
xlabel(ax_bot,'Day','FontSize',bfs,'FontWeight','bold','Interpreter','tex');
grid(ax_bot,'off'); set(ax_bot,'TickLabelInterpreter','tex'); sAx(ax_bot);

lg3b = legend(ax_bot,'show','Location','northeast','Box','off');
set(lg3b,'AutoUpdate','off','Interpreter','tex','FontName',chosenFont, ...
    'FontSize',lfs+2,'TextColor',[0 0 0]);

linkaxes([ax_top,ax_bot],'x'); xlim(ax_top,[1,n_days]);
set(findall(fig3,'-property','FontName'),'FontName',chosenFont);
set(lg3,'FontName',chosenFont); set(lg3b,'FontName',chosenFont);
exportEPS(fig3,fullfile(outdir,'Fig3_Rt.eps'),cfg_fig.useColor);

%% ===== MIA (Fig4) =====

% Pre-compute all annotation quantities 
sigma_vec = perturb_lvl(:);         
R2_thresh = 0.99;
n_pm      = 3;   % params:   1=beta, 2=rho, 3=eps
n_mv      = 3;   % met vars: 1=T, 2=RH, 3=WS

R2_mat     = nan(n_pm, n_mv);
b_ols_mat  = nan(n_pm, n_mv);       
AI_mat     = nan(n_pm, n_mv);
mono_mat   = false(n_pm, n_mv);
linear_mat = false(n_pm, n_mv);

[sigma_sorted, sort_idx] = sort(sigma_vec);

for pm_i = 1:n_pm
    for v = 1:n_mv
        y_raw  = squeeze(ens_mean(:, pm_i, v));   
        y      = y_raw(sort_idx);                  

        b_ols  = (sigma_sorted' * sigma_sorted) \ (sigma_sorted' * y);
        y_hat  = b_ols * sigma_sorted;
        SS_res = sum((y - y_hat).^2);
        SS_tot = sum(y.^2);          

        if SS_tot < eps
            R2 = NaN;
        else
            R2 = 1 - SS_res / SS_tot;
        end

        b_ols_mat(pm_i,v) = b_ols;
        R2_mat(pm_i,v)    = R2;

        % strict monotonicity
        dy = diff(y);
        mono_mat(pm_i,v) = all(dy >= 0) || all(dy <= 0);

        % Linearity decision
        linear_mat(pm_i,v) = ~isnan(R2) && (R2 >= R2_thresh);

        y_neg2 = y(1);
        y_pos2 = y(end);
        if abs(y_neg2) < eps
            AI_mat(pm_i,v) = NaN;
        else
            AI_mat(pm_i,v) = (abs(y_pos2) - abs(y_neg2)) / abs(y_neg2) * 100;
        end
    end
end

% Summary
fprintf('\n=== MIA Linearity Analysis (R2 threshold = %.2f) ===\n', R2_thresh);
fprintf('%-5s %-5s  %+11s  %8s  %-10s  %-10s  %12s\n', ...
    'Par','Met','b_ols (slope)','R2','Linear?','Monotone?','Asymmetry(%)');
fprintf('%s\n', repmat('-',1,70));
param_lbl_pr = {'\beta','\rho','\varepsilon'};
met_lbl_pr   = {'T_m','RH','WS'};
for pm_i = 1:n_pm
    for v = 1:n_mv
        if linear_mat(pm_i,v); ls='yes'; else; ls='NO'; end
        if mono_mat(pm_i,v);   ms='yes'; else; ms='NO'; end
        if isnan(R2_mat(pm_i,v))
            fprintf('%-5s %-5s  %+11.3e  %8s  %-10s  %-10s  %+12.1f\n', ...
                param_lbl_pr{pm_i}, met_lbl_pr{v}, ...
                b_ols_mat(pm_i,v), 'NaN', ls, ms, AI_mat(pm_i,v));
        else
            fprintf('%-5s %-5s  %+11.3e  %8.4f  %-10s  %-10s  %+12.1f\n', ...
                param_lbl_pr{pm_i}, met_lbl_pr{v}, ...
                b_ols_mat(pm_i,v), R2_mat(pm_i,v), ls, ms, AI_mat(pm_i,v));
        end
    end
end

save(fullfile(outdir,'mia_linearity.mat'), ...
    'R2_mat','b_ols_mat','AI_mat','mono_mat','linear_mat','R2_thresh');
fprintf('  Linearity results saved: mia_linearity.mat\n');

% Figure drawing 

fprintf('Generating MIA figure (n=%d)...\n', size(ens_mia,1));

LW   = 1.5; mkSz = 4; bfs  = 9; lfs  = 7;

orig_h = 198; new_h = round(orig_h * 1.8);  fig_pos = [120 120 1100 new_h];

c_T  = [0.00 0.35 0.60];
c_RH = [0.80 0.20 0.00];
c_WS = [0.10 0.50 0.10];

% annotation colours 
ann_colors = {[0.00 0.20 0.45]; [0.65 0.10 0.00]; [0.05 0.35 0.05]};

mia_sty = {c_T,  '-',  'o', c_T;
           c_RH, '--', 's', c_RH;
           c_WS, ':',  '^', c_WS};

ci_ls    = {'-', '--', ':'};
ci_lw    = [0.7, 0.7, 0.7];
ci_alpha = [0.12, 0.10, 0.08];

mYlb      = {'$\Delta\beta$', '$\Delta\rho$', '$\Delta\varepsilon$'};
dsp_names = {'$T_m$','RH','WS'};

mImp = {
    {ens_mean(:,1,1), ens_mean(:,1,2), ens_mean(:,1,3)};
    {ens_mean(:,2,1), ens_mean(:,2,2), ens_mean(:,2,3)};
    {ens_mean(:,3,1), ens_mean(:,3,2), ens_mean(:,3,3)}
};

fig_mia = figure('Color','w','Position', fig_pos,'PaperPositionMode','auto');

for sp = 1:3                        
    ax = subplot(1,3,sp); hold on;

    % Layer 1
    for wv = [3, 2, 1]
        fill_clr = blendW(mia_sty{wv,1}, ci_alpha(wv));
        fill([perturb_lvl, fliplr(perturb_lvl)], ...
             [ens_bslo(:,sp,wv)', fliplr(ens_bshi(:,sp,wv)')], ...
             fill_clr,'FaceAlpha',1.0,'EdgeColor','none','HandleVisibility','off');
    end

    % Layer 2: BCI boundary lines  
    for wv = 1:3
        col = mia_sty{wv,1};
        plot(perturb_lvl, ens_bshi(:,sp,wv), ...
            'LineStyle', ci_ls{wv}, 'Color', col, ...
            'LineWidth', ci_lw(wv), 'HandleVisibility','off');
        plot(perturb_lvl, ens_bslo(:,sp,wv), ...
            'LineStyle', ci_ls{wv}, 'Color', col, ...
            'LineWidth', ci_lw(wv), 'HandleVisibility','off');
    end

    % Layer 3: mean curves
    for wv = 1:3
        sc = mia_sty(wv,:);
        plot(perturb_lvl, mImp{sp}{wv}, ...
            'LineStyle',       sc{2}, ...
            'Color',           sc{1}, ...
            'LineWidth',       LW + 0.3, ...
            'Marker',          sc{3}, ...
            'MarkerFaceColor', sc{4}, ...
            'MarkerEdgeColor', sc{1}, ...
            'MarkerSize',      mkSz + 1, ...
            'DisplayName',     dsp_names{wv});
    end

    yline(0, '--', 'Color',[0.45 0.45 0.45], ...
        'LineWidth', 0.9, 'HandleVisibility','off');

    % axis labels 
    xlabel('$\sigma$', ...
        'FontSize',bfs+3, 'FontWeight','bold', 'Interpreter','latex');
    ylabel(mYlb{sp}, ...
        'FontSize',bfs+3, 'FontWeight','bold', 'Interpreter','latex');

    % Legend 1
    if sp == 1
    lg1 = legend('Box','off', 'FontSize',lfs+3);
    set(lg1, 'AutoUpdate','off', 'FontName',chosenFont, 'Interpreter','latex');
    drawnow;
    lg1.Units = 'normalized';
    lg1.Position = [0.14, 0.78, 0.10, 0.12]; 
    end

    xlim([-2.3 2.3]); grid off;
    set(gca, 'FontSize',bfs, 'FontName',chosenFont, ...
        'Box','on', 'LineWidth',0.8, 'FontWeight','bold');

    % R² annotations 
    drawnow;                          
    ax_now = gca;
    yl = ax_now.YLim; xl = ax_now.XLim; y_step = (yl(2) - yl(1)) * 0.06;
    y_top  = yl(2) - 0.4 * y_step;  x_pos  = xl(2) - 0.1 * diff(xl);   

    for v = 1:3
        if isnan(R2_mat(sp,v)); continue; end
        ann_str = sprintf('\\bfR^2(%s)=%.2f', met_lbl_pr{v}, R2_mat(sp,v));
        y_pos   = y_top - (v-1) * y_step;
        text(ax_now, x_pos, y_pos, ann_str, ...
            'FontSize',            9, ...
            'Color',               ann_colors{v}, ...
            'HorizontalAlignment', 'right', ...   
            'VerticalAlignment',   'top', ...
            'FontName',            chosenFont, ...
            'Interpreter',         'tex', ...
            'BackgroundColor',     'none', ...    
            'EdgeColor',           'none', ...
            'Margin',              2, ...
            'Clipping',            'on');
    end
end

% Legend 2
ax1     = subplot(1,3,1); ax1_pos = ax1.Position(:)';        

ax_leg = axes('Position', ax1_pos, ...
              'Color',    'none', ...
              'XColor',   'none', ...
              'YColor',   'none', ...
              'HitTest',  'off');
hold(ax_leg, 'on');

h_prx = gobjects(3,1);
for wv = 1:3
    col      = mia_sty{wv,1};
    fill_clr = blendW(col, ci_alpha(wv));
    ls       = ci_ls{wv};
    h_prx(wv) = fill(ax_leg, NaN, NaN, fill_clr, ...
        'EdgeColor', col,'LineStyle', ls,'LineWidth', 1.2);
end

lg2 = legend(ax_leg, h_prx, ...
    {'95\% BCI ($T_m$)', '95\% BCI (RH)', '95\% BCI (WS)'}, ...
    'Box',  'off','FontSize', lfs+1,'Interpreter','latex');

set(lg2, 'AutoUpdate','off', 'FontName',chosenFont);
drawnow;
% Place lg2 at bottom-left 
lg2.Units = 'normalized';
lg2.Position = [ax1_pos(1) + 0.04,ax1_pos(2) + 0.01,  ...           
                ax1_pos(3) * 0.68,ax1_pos(4) * 0.20]; ...        

set(findall(fig_mia,'-property','FontName'),'FontName',chosenFont);
exportEPS(fig_mia, fullfile(outdir,'Fig5_MIA_n30.eps'), cfg_fig.useColor);
fprintf('  Saved: Fig4_MIA_n30.eps\n');
fprintf('Done.\n');
fprintf('\n  Figures saved to ./%s/\n',outdir);
fprintf('=== ANALYSIS COMPLETE (v30) ===\n');

%% ============================================================
%%              LOCAL HELPER FUNCTIONS
%% ============================================================

function y = causal_smooth(x,w)
    if isvector(x)
        y=movmean(x(:),[w-1,0],'omitnan','Endpoints','shrink');
        if isrow(x), y=y'; end
    else
        y=zeros(size(x));
        for c=1:size(x,2)
            y(:,c)=movmean(x(:,c),[w-1,0],'omitnan','Endpoints','shrink');
        end
    end
end

function dx = causal_deriv_sg(x,w,deg)
    x=x(:); n=length(x); dx=zeros(n,1); min_pts=max(3,deg+1);
    tau_cache=struct();
    for t=1:n
        seg=x(max(1,t-w+1):t); m=length(seg);
        if m<min_pts, dx(t)=0; continue; end
        key=sprintf('m%d',m);
        if ~isfield(tau_cache,key), tau_cache.(key)=linspace(0,1,m)'; end
        tau_loc=tau_cache.(key);
        p=polyfit(tau_loc,seg,min(deg,m-1));
        dx(t)=polyval(polyder(p),1.0)*(m-1);
    end
    dx=filloutliers(dx,'linear','movmedian',max(5,ceil(w/2)));
end

function res = seir_residual(p,S,E,I,R,u,delta,alpha,dS,dE,dI,dR,Rt_tgt,lam)
    b=p(1); r=p(2); ep=p(3); foi=(1-u)*b*S*I; di_s=delta*I;
    res_S=dS-(alpha*(1-S)-foi+di_s*S);
    res_E=dE-(foi-(ep+alpha)*E+di_s*E);
    res_I=dI-(ep*E-(r+delta+alpha)*I+di_s*I);
    res_R=dR-(r*I-alpha*R+di_s*R);
    res=[res_S;res_E;res_I;res_R];
    if lam>0
        Rt_m=max(b*(1-u)*S/max(r+delta+alpha,1e-8),0);
        res=[res; sqrt(lam)*(Rt_m-Rt_tgt)];
    end
end

function [mae,rmse,r2,nrmse] = compute_metrics(y,yhat)
    y=y(:); yhat=yhat(:); n=min(numel(y),numel(yhat));
    y=y(1:n); yhat=yhat(1:n);
    ok=isfinite(y)&isfinite(yhat); y=y(ok); yhat=yhat(ok);
    if isempty(y), mae=NaN; rmse=NaN; r2=NaN; nrmse=NaN; return; end
    err=yhat-y; mae=mean(abs(err)); rmse=sqrt(mean(err.^2));
    r2=1-sum(err.^2)/(sum((y-mean(y)).^2)+eps);
    nrmse=rmse/(mean(abs(y))+eps);
end

function varargout = replaceBadValues(ws,varargin)
    varargout=cell(1,numel(varargin));
    for k=1:numel(varargin)
        x=varargin{k}(:); xm=movmedian(x,ws,'omitnan');
        xa=movmad(x,ws,1,'omitnan'); xa(xa==0)=eps;
        bad=abs(x-xm)>3*xa; x(bad)=xm(bad); varargout{k}=x;
        if mean(bad)>0.05
            fprintf('[replaceBadValues] series %d: %.1f%% repaired\n',k,mean(bad)*100);
        end
    end
end

function ci = block_bootstrap_ci(residuals,n_forecast,n_boot,block_len,~)
    residuals=residuals(isfinite(residuals)); n_res=numel(residuals);
    boot_mat=zeros(n_boot,n_forecast);
    for b=1:n_boot
        seq=zeros(n_forecast,1); idx=0;
        while idx<n_forecast
            sb=randi(max(1,n_res-block_len+1));
            blk=residuals(sb:min(sb+block_len-1,n_res));
            take=min(numel(blk),n_forecast-idx);
            seq(idx+1:idx+take)=blk(1:take); idx=idx+take;
        end
        boot_mat(b,:)=seq;
    end
    ci=[prctile(boot_mat,2.5,1)',prctile(boot_mat,97.5,1)'];
end

function g_out = norm_clip(g,GT)
    gn=sqrt(sum(extractdata(g).^2,'all'));
    if gn>GT, g_out=g*(GT/gn); else, g_out=g; end
end

function layers = build_layers(HP,numFtr)
    fc_wide=HP.fcSize+32;
    layers=[
        sequenceInputLayer(numFtr,'Name','input','Normalization','none')
        lstmLayer(HP.hdnsz1,'OutputMode','sequence','Name','lstm1')
        dropoutLayer(HP.dropR,'Name','drop1')
        layerNormalizationLayer('Name','ln1')
        lstmLayer(HP.hdnsz2,'OutputMode','last','Name','lstm2')
        layerNormalizationLayer('Name','ln2')
        dropoutLayer(HP.dropR2,'Name','drop2')
        fullyConnectedLayer(fc_wide,'Name','fc1')
        tanhLayer('Name','tanh1')
        fullyConnectedLayer(HP.fcSize,'Name','fc2')
        reluLayer('Name','relu2')
        fullyConnectedLayer(3,'Name','fc_out')
    ];
end

function bw = pack_batch(bidx,XN_full,S_sn,E_sn,I_sn,R_sn,u_ts,delta_t, ...
                          alpha_s,sqln,Rt_ref,reliable_tr,epoch_flag_tr)
    n=numel(bidx); bw=cell(n,1);
    for k=1:n
        i=bidx(k);
        w.X=squeeze(XN_full(i,:,:))';
        w.S=S_sn(i:i+sqln-1);  w.E=E_sn(i:i+sqln-1);
        w.Iv=I_sn(i:i+sqln-1); w.R=R_sn(i:i+sqln-1);
        w.u=u_ts(i:i+sqln-1);  w.d=delta_t(i:i+sqln-1);
        w.a=alpha_s(i:i+sqln-1);
        w.Rt_ref=Rt_ref(i); w.reliable=reliable_tr(i); w.ef=epoch_flag_tr(i);
        bw{k}=w;
    end
end

function bw = pack_batch_from_full(bidx,X_trn_local,S_sn,E_sn,I_sn,R_sn, ...
        u_ts,delta_t,alpha_s,sqln,Rt_ref_loc,reliable_loc,ef_loc)
    n=numel(bidx); bw=cell(n,1);
    for k=1:n
        i=bidx(k);
        w.X =squeeze(X_trn_local(i,:,:))';
        w.S =S_sn(i:i+sqln-1);   w.E =E_sn(i:i+sqln-1);
        w.Iv=I_sn(i:i+sqln-1);   w.R =R_sn(i:i+sqln-1);
        w.u =u_ts(i:i+sqln-1);   w.d =delta_t(i:i+sqln-1);
        w.a =alpha_s(i:i+sqln-1);
        w.Rt_ref=Rt_ref_loc(i); w.reliable=reliable_loc(i); w.ef=ef_loc(i);
        bw{k}=w;
    end
end

function [loss,grads] = pinn_loss_fn(net,bw, ...
        lam_S,lam_E,lam_I,lam_R,lam_mass,lam_rho_Rt,lam_eps_reg_base, ...
        YN_batch,lw_sqrt,pm_d,ps_d,last_p_batch,bounds)
    b_min=bounds.b_min; b_max=bounds.b_max;
    r_min=bounds.r_min; r_max=bounds.r_max;  
    e_min=bounds.e_min; e_max=bounds.e_max;  
    R_hi =bounds.R_hi;
    n_batch=numel(bw); tot_loss=dlarray(0.0);
    for i=1:n_batch
        w=bw{i}; X_dl=dlarray(w.X,'CBT'); out=forward(net,X_dl);
        err_d=out-dlarray(YN_batch(i,:)','CB');
        huber_delta=0.5; abs_e3=abs(err_d(3));
        huber_e3=min(0.5*err_d(3)^2, huber_delta*abs_e3-0.5*huber_delta^2);
        data_loss=(0.5*err_d(1)^2+0.5*err_d(2)^2+huber_e3)/3;
        yd=(out./dlarray(lw_sqrt','CB')).*dlarray(ps_d','CB')+dlarray(pm_d','CB');
        params=dlarray(last_p_batch(i,:)','CB')+yd;
        beta_p=max(min(params(1),b_max),b_min);  
        rho_p =max(min(params(2),r_max),r_min);  
        eps_p =max(min(params(3),e_max),e_min); 
        beta_start=double(last_p_batch(i,1));
        rho_start =double(last_p_batch(i,2));
        eps_start =double(last_p_batch(i,3));
        sqL=numel(w.Iv);
        S_seq=double(w.S); E_seq=double(w.E); I_seq=double(w.Iv); R_seq=double(w.R);
        u_seq=double(w.u); d_seq=double(w.d); a_seq=double(w.a);
        Sc=S_seq(1); Ec=E_seq(1); Ic=I_seq(1); Rc=R_seq(1);
        S_pred=zeros(sqL,1,'like',extractdata(beta_p));
        E_pred=zeros(sqL,1,'like',extractdata(beta_p));
        I_pred_v=zeros(sqL,1,'like',extractdata(beta_p));
        R_pred=zeros(sqL,1,'like',extractdata(beta_p));
        S_pred(1)=Sc; E_pred(1)=Ec; I_pred_v(1)=Ic; R_pred(1)=Rc;
        for t=2:sqL
            t_frac=(t-1)/max(sqL-1,1);
            beta_t=beta_start*(1-t_frac)+beta_p*t_frac;
            rho_t =rho_start*(1-t_frac) +rho_p*t_frac;
            eps_t =eps_start*(1-t_frac) +eps_p*t_frac;
            foi_t=(1-u_seq(t-1))*beta_t*Sc*Ic;
            Sc=max(Sc+a_seq(t-1)*(1-Sc)-foi_t+d_seq(t-1)*Ic*Sc,0);
            Ec=max(Ec+foi_t-(eps_t+a_seq(t-1))*Ec+d_seq(t-1)*Ic*Ec,0);
            Ic=max(Ic+eps_t*Ec-(rho_t+d_seq(t-1)+a_seq(t-1))*Ic+d_seq(t-1)*Ic*Ic,0);
            Rc=max(Rc+rho_t*Ic-a_seq(t-1)*Rc+d_seq(t-1)*Ic*Rc,0);
            S_pred(t)=Sc; E_pred(t)=Ec; I_pred_v(t)=Ic; R_pred(t)=Rc;
        end
        S_dl =dlarray(single(S_seq),'CB');   E_dl =dlarray(single(E_seq),'CB');
        I_dl =dlarray(single(I_seq),'CB');   R_dl =dlarray(single(R_seq),'CB');
        Sp_dl=dlarray(single(S_pred),'CB');  Ep_dl=dlarray(single(E_pred),'CB');
        Ip_dl=dlarray(single(I_pred_v),'CB'); Rp_dl=dlarray(single(R_pred),'CB');
        phys_loss=(lam_S*mean((Sp_dl-S_dl).^2)+lam_E*mean((Ep_dl-E_dl).^2)+ ...
                   lam_I*mean((Ip_dl-I_dl).^2)+lam_R*mean((Rp_dl-R_dl).^2)+ ...
                   lam_mass*mean((Sp_dl+Ep_dl+Ip_dl+Rp_dl-1).^2));
        rho_Rt_loss=dlarray(0.0);
        if lam_rho_Rt>0 && w.reliable && w.Rt_ref>0 && w.Rt_ref<=R_hi
            a_t=a_seq(end); S_t=S_seq(end); u_t_end=u_seq(end);
            rho_impl=beta_p*(1-u_t_end)*eps_p*S_t / ...
                (max(w.Rt_ref,0.1)*max(eps_p+a_t,1e-8)) - d_seq(end) - a_t;
            rho_impl=max(min(rho_impl,r_max),r_min);
            rho_Rt_loss=lam_rho_Rt*(rho_p-dlarray(single(rho_impl),'CB'))^2;
        end
        ef_weight=double(w.ef);
        lam_eps_reg=lam_eps_reg_base*max(1-ef_weight,0);
        eps_reg_loss=dlarray(0.0);
        if lam_eps_reg>1e-8
            eps_reg_loss=lam_eps_reg*(eps_p-dlarray(single(eps_start),'CB'))^2;
        end
        tot_loss=tot_loss+data_loss+phys_loss+rho_Rt_loss+eps_reg_loss;
    end
    loss=sum(tot_loss)/n_batch;
    grads=dlgradient(loss,net.Learnables);
end

function net = build_and_train_dl(HP,numFtr,XTrnC,YTrnN,XValC,YValN, ...
        max_ep,pat, ...
        lam_S,lam_E,lam_I,lam_R,lam_mass,lam_rho_Rt,lam_eps_reg_base, ...
        lw_sqrt,pm_d,ps_d,S_sn,E_sn,I_sn,R_sn, ...
        u_ts,delta_t,alpha_s,sqln,X_trn_local,last_p_trn, ...
        Rt_ref_loc,reliable_loc,ef_loc, ...
        val_sample_inds, pred_time_inds_full, bounds)

    plateau_patience_sub=12;  lr_decay_factor_sub=0.60;  lr_min_sub=1e-6;

    nTrn=numel(XTrnC);
    layers=build_layers(HP,numFtr);  net=dlnetwork(layers);
    avg_g=[]; avg_sq=[]; it=0; best_v=inf; best_net=net; no_imp=0;

    plateau_count_sub=0; best_val_for_plateau_sub=inf;
    cur_lr_sub=HP.ILR;   lr_at_start_sub=HP.ILR;

    nV_sub=numel(XValC);
    lp_trn_rows=size(last_p_trn,1);
    n_val_inds=numel(val_sample_inds);

    for ep=1:max_ep
        idx_sh=randperm(nTrn); n_b=ceil(nTrn/HP.MB); ep_l=0;
        for b=1:n_b
            b0=(b-1)*HP.MB+1; b1=min(b*HP.MB,nTrn); bidx=idx_sh(b0:b1);
            bw=pack_batch_from_full(bidx,X_trn_local,S_sn,E_sn,I_sn,R_sn, ...
                u_ts,delta_t,alpha_s,sqln,Rt_ref_loc,reliable_loc,ef_loc);
            lp_batch=last_p_trn(bidx,:);
            [loss,grads]=dlfeval(@pinn_loss_fn,net,bw, ...
                lam_S,lam_E,lam_I,lam_R,lam_mass,lam_rho_Rt,lam_eps_reg_base, ...
                YTrnN(bidx,:),lw_sqrt,pm_d,ps_d,lp_batch,bounds);
            grads=dlupdate(@(g) norm_clip(g,HP.GT), grads);
            it=it+1;
            [net,avg_g,avg_sq]=adamupdate(net,grads,avg_g,avg_sq,it, ...
                cur_lr_sub,0.9,0.999,HP.L2Reg);
            ep_l=ep_l+extractdata(loss);
        end

        vl=0;
        for vi=1:nV_sub
            if vi <= n_val_inds
                si     = val_sample_inds(vi);
                t0_day = pred_time_inds_full(si);
                win_s  = max(1, t0_day - sqln + 1);
                win_e  = t0_day;
                n_win  = win_e - win_s + 1;
                bw_v = struct();
                bw_v.X        = XValC{vi};
                bw_v.Rt_ref   = Rt_ref_loc(min(nTrn,numel(Rt_ref_loc)));
                bw_v.reliable = reliable_loc(min(nTrn,numel(reliable_loc)));
                bw_v.ef       = ef_loc(min(nTrn,numel(ef_loc)));
                bw_v.S  = S_sn(win_s:win_e);
                bw_v.E  = E_sn(win_s:win_e);
                bw_v.Iv = I_sn(win_s:win_e);
                bw_v.R  = R_sn(win_s:win_e);
                bw_v.u  = u_ts(win_s:win_e);
                bw_v.d  = delta_t(win_s:win_e);
                bw_v.a  = alpha_s(win_s:win_e);
                if n_win < sqln
                    pad = sqln - n_win;
                    bw_v.S  = [repmat(bw_v.S(1), pad,1);  bw_v.S];
                    bw_v.E  = [repmat(bw_v.E(1), pad,1);  bw_v.E];
                    bw_v.Iv = [repmat(bw_v.Iv(1),pad,1); bw_v.Iv];
                    bw_v.R  = [repmat(bw_v.R(1), pad,1);  bw_v.R];
                    bw_v.u  = [repmat(bw_v.u(1), pad,1);  bw_v.u];
                    bw_v.d  = [repmat(bw_v.d(1), pad,1);  bw_v.d];
                    bw_v.a  = [repmat(bw_v.a(1), pad,1);  bw_v.a];
                end
                lp_v = last_p_trn(min(si, lp_trn_rows), :);
            else
                lp_v  = last_p_trn(min(nTrn+vi, lp_trn_rows), :);
                bw_v  = make_fallback_window(vi, nTrn, sqln, XValC, ...
                            S_sn, E_sn, I_sn, R_sn, u_ts, delta_t, alpha_s, ...
                            Rt_ref_loc, reliable_loc, ef_loc);
            end
            loss_v=dlfeval(@pinn_loss_fn,net,{bw_v}, ...
                lam_S,lam_E,lam_I,lam_R,lam_mass,lam_rho_Rt,lam_eps_reg_base, ...
                YValN(vi,:),lw_sqrt,pm_d,ps_d,lp_v,bounds);
            vl=vl+extractdata(loss_v);
        end
        vl=vl/max(nV_sub,1);
        if vl<best_v, best_v=vl; best_net=net; no_imp=0; else, no_imp=no_imp+1; end

        if vl<best_val_for_plateau_sub
            best_val_for_plateau_sub=vl; plateau_count_sub=0; lr_at_start_sub=cur_lr_sub;
        else
            plateau_count_sub=plateau_count_sub+1;
            frac=plateau_count_sub/plateau_patience_sub;
            cosine_f=0.5*(1+cos(pi*frac));
            lr_tgt=max(lr_at_start_sub*lr_decay_factor_sub,lr_min_sub);
            new_lr=max(lr_tgt+(lr_at_start_sub-lr_tgt)*cosine_f,lr_min_sub);
            if new_lr<cur_lr_sub-1e-10, cur_lr_sub=new_lr; end
        end
        if plateau_count_sub>=plateau_patience_sub
            new_lr_f=max(lr_at_start_sub*lr_decay_factor_sub,lr_min_sub);
            if new_lr_f<lr_at_start_sub-1e-10
                cur_lr_sub=new_lr_f; avg_g=[]; avg_sq=[]; lr_at_start_sub=new_lr_f;
            end
            plateau_count_sub=0; best_val_for_plateau_sub=vl;
        end
        if no_imp>=pat, break; end
    end
    net=best_net;
end

function net = finetune_from_net(net_init,HP,XTrnC,YTrnN,XValC,YValN, ...
        max_ep,pat, ...
        lam_S,lam_E,lam_I,lam_R,lam_mass,lam_rho_Rt,lam_eps_reg_base, ...
        lw_sqrt,pm_d,ps_d,S_sn,E_sn,I_sn,R_sn, ...
        u_ts,delta_t,alpha_s,sqln,X_trn_local,last_p_trn, ...
        Rt_ref_loc,reliable_loc,ef_loc, ...
        val_sample_inds, pred_time_inds_full, bounds)

    plateau_patience_ft=10; lr_decay_factor_ft=0.60; lr_min_ft=1e-7;
    cur_lr_ft=HP.ILR/5;     lr_at_start_ft=cur_lr_ft;

    nTrn=numel(XTrnC);
    net=net_init;
    avg_g=[]; avg_sq=[]; it=0; best_v=inf; best_net=net; no_imp=0;
    plateau_count_ft=0; best_val_ft=inf;

    nV_sub=numel(XValC);
    lp_trn_rows=size(last_p_trn,1);
    n_val_inds=numel(val_sample_inds);

    for ep=1:max_ep
        idx_sh=randperm(nTrn); n_b=ceil(nTrn/HP.MB); ep_l=0;
        for b=1:n_b
            b0=(b-1)*HP.MB+1; b1=min(b*HP.MB,nTrn); bidx=idx_sh(b0:b1);
            bw=pack_batch_from_full(bidx,X_trn_local,S_sn,E_sn,I_sn,R_sn, ...
                u_ts,delta_t,alpha_s,sqln,Rt_ref_loc,reliable_loc,ef_loc);
            lp_batch=last_p_trn(bidx,:);
            [loss,grads]=dlfeval(@pinn_loss_fn,net,bw, ...
                lam_S,lam_E,lam_I,lam_R,lam_mass,lam_rho_Rt,lam_eps_reg_base, ...
                YTrnN(bidx,:),lw_sqrt,pm_d,ps_d,lp_batch,bounds);
            grads=dlupdate(@(g) norm_clip(g,HP.GT), grads);
            it=it+1;
            [net,avg_g,avg_sq]=adamupdate(net,grads,avg_g,avg_sq,it, ...
                cur_lr_ft,0.9,0.999,HP.L2Reg);
            ep_l=ep_l+extractdata(loss);
        end

        vl=0;
        for vi=1:nV_sub
            if vi <= n_val_inds
                si     = val_sample_inds(vi);
                t0_day = pred_time_inds_full(si);
                win_s  = max(1, t0_day - sqln + 1);
                win_e  = t0_day;
                n_win  = win_e - win_s + 1;
                bw_v = struct();
                bw_v.X        = XValC{vi};
                bw_v.Rt_ref   = Rt_ref_loc(min(nTrn,numel(Rt_ref_loc)));
                bw_v.reliable = reliable_loc(min(nTrn,numel(reliable_loc)));
                bw_v.ef       = ef_loc(min(nTrn,numel(ef_loc)));
                bw_v.S  = S_sn(win_s:win_e);
                bw_v.E  = E_sn(win_s:win_e);
                bw_v.Iv = I_sn(win_s:win_e);
                bw_v.R  = R_sn(win_s:win_e);
                bw_v.u  = u_ts(win_s:win_e);
                bw_v.d  = delta_t(win_s:win_e);
                bw_v.a  = alpha_s(win_s:win_e);
                if n_win < sqln
                    pad = sqln - n_win;
                    bw_v.S  = [repmat(bw_v.S(1), pad,1);  bw_v.S];
                    bw_v.E  = [repmat(bw_v.E(1), pad,1);  bw_v.E];
                    bw_v.Iv = [repmat(bw_v.Iv(1),pad,1); bw_v.Iv];
                    bw_v.R  = [repmat(bw_v.R(1), pad,1);  bw_v.R];
                    bw_v.u  = [repmat(bw_v.u(1), pad,1);  bw_v.u];
                    bw_v.d  = [repmat(bw_v.d(1), pad,1);  bw_v.d];
                    bw_v.a  = [repmat(bw_v.a(1), pad,1);  bw_v.a];
                end
                lp_v = last_p_trn(min(si, lp_trn_rows), :);
            else
                lp_v  = last_p_trn(min(nTrn+vi, lp_trn_rows), :);
                bw_v  = make_fallback_window(vi, nTrn, sqln, XValC, ...
                            S_sn, E_sn, I_sn, R_sn, u_ts, delta_t, alpha_s, ...
                            Rt_ref_loc, reliable_loc, ef_loc);
            end
            loss_v=dlfeval(@pinn_loss_fn,net,{bw_v}, ...
                lam_S,lam_E,lam_I,lam_R,lam_mass,lam_rho_Rt,lam_eps_reg_base, ...
                YValN(vi,:),lw_sqrt,pm_d,ps_d,lp_v,bounds);
            vl=vl+extractdata(loss_v);
        end
        vl=vl/max(nV_sub,1);
        if vl<best_v, best_v=vl; best_net=net; no_imp=0; else, no_imp=no_imp+1; end

        if vl<best_val_ft
            best_val_ft=vl; plateau_count_ft=0; lr_at_start_ft=cur_lr_ft;
        else
            plateau_count_ft=plateau_count_ft+1;
            frac=plateau_count_ft/plateau_patience_ft;
            cosine_f=0.5*(1+cos(pi*frac));
            lr_tgt=max(lr_at_start_ft*lr_decay_factor_ft,lr_min_ft);
            new_lr=max(lr_tgt+(lr_at_start_ft-lr_tgt)*cosine_f,lr_min_ft);
            if new_lr<cur_lr_ft-1e-10, cur_lr_ft=new_lr; end
        end
        if plateau_count_ft>=plateau_patience_ft
            new_lr_f=max(lr_at_start_ft*lr_decay_factor_ft,lr_min_ft);
            if new_lr_f<lr_at_start_ft-1e-10
                cur_lr_ft=new_lr_f; avg_g=[]; avg_sq=[]; lr_at_start_ft=new_lr_f;
            end
            plateau_count_ft=0; best_val_ft=vl;
        end
        if no_imp>=pat, break; end
    end
    net=best_net;
end

function bw_v = make_fallback_window(vi, nTrn, sqln, XValC, ...
        S_sn, E_sn, I_sn, R_sn, u_ts, delta_t, alpha_s, ...
        Rt_ref_loc, reliable_loc, ef_loc)
    n_seq = min(sqln, numel(S_sn));
    bw_v.X        = XValC{vi};
    bw_v.Rt_ref   = Rt_ref_loc(min(nTrn,numel(Rt_ref_loc)));
    bw_v.reliable = reliable_loc(min(nTrn,numel(reliable_loc)));
    bw_v.ef       = ef_loc(min(nTrn,numel(ef_loc)));
    bw_v.S  = S_sn(end-n_seq+1:end);
    bw_v.E  = E_sn(end-n_seq+1:end);
    bw_v.Iv = I_sn(end-n_seq+1:end);
    bw_v.R  = R_sn(end-n_seq+1:end);
    bw_v.u  = u_ts(end-n_seq+1:end);
    bw_v.d  = delta_t(end-n_seq+1:end);
    bw_v.a  = alpha_s(end-n_seq+1:end);
end

function yd_row = decode_yd(p_raw,lw_sqrt,ps,pm)
    v=double(p_raw(:)'); lw=lw_sqrt(:)'; ps=ps(:)'; pm=pm(:)';
    yd_row=(v./lw).*ps+pm;
end

function [beta_imp,rho_imp,eps_imp] = rolling_mia_batch(DM_pert_struct,varname,net, ...
        fm,fs,pm_d,ps_d,lw_sqrt,sqln,n_perturb, ...
        b_min,b_max,r_min,r_max,e_min,e_max,last_p_local)

    beta_imp=zeros(n_perturb,1); rho_imp=zeros(n_perturb,1); eps_imp=zeros(n_perturb,1);
    n_lp=size(last_p_local,1);  skip=sqln;

    for p_idx=1:n_perturb
        DM_p=DM_pert_struct(p_idx).(varname);
        n_total=size(DM_p,1);  n_steps=n_total-sqln;
        if n_steps<=skip, continue; end
        numFtr_loc=size(DM_p,2);
        all_wins=zeros(numFtr_loc,sqln,n_steps,'single');
        for t=1:n_steps
            win_raw=DM_p(t:t+sqln-1,:);
            win_n=((win_raw-fm)./fs)';
            all_wins(:,:,t)=single(win_n);
        end
        b_traj=zeros(n_steps,1); r_traj=zeros(n_steps,1); e_traj=zeros(n_steps,1);
        for t=1:n_steps
            gt=min(sqln+t,n_lp);
            p_raw=extractdata(predict(net,dlarray(all_wins(:,:,t),'CBT')));
            p_raw=p_raw(:,end);
            yd=decode_yd(p_raw,lw_sqrt,pm_d,ps_d);
            lp_k=last_p_local(gt,:);
            b_traj(t)=min(max(lp_k(1)+yd(1),b_min),b_max);
            r_traj(t)=min(max(lp_k(2)+yd(2),r_min),r_max);
            e_traj(t)=min(max(lp_k(3)+yd(3),e_min),e_max);
        end
        b_traj=movmedian(b_traj,5,'omitnan');
        r_traj=movmedian(r_traj,5,'omitnan');
        e_traj=movmedian(e_traj,5,'omitnan');
        beta_imp(p_idx)=mean(b_traj(skip+1:end));
        rho_imp(p_idx) =mean(r_traj(skip+1:end));
        eps_imp(p_idx) =mean(e_traj(skip+1:end));
    end
    mid=ceil(n_perturb/2);
    beta_imp=beta_imp-beta_imp(mid);
    rho_imp =rho_imp -rho_imp(mid);
    eps_imp =eps_imp -eps_imp(mid);
end

function [ccc,bias] = compute_ccc(y,yhat)
    y=y(:); yhat=yhat(:);
    ok=isfinite(y)&isfinite(yhat); y=y(ok); yhat=yhat(ok);
    if numel(y)<3, ccc=NaN; bias=NaN; return; end
    mx=mean(y); my=mean(yhat);
    sx2=var(y,1); sy2=var(yhat,1);
    r=corr(y,yhat,'Type','Pearson');
    ccc=2*r*sqrt(sx2*sy2)/(sx2+sy2+(mx-my)^2+eps);
    bias=mean(yhat-y);
end

function ci_shade_fill(ax,x,ylo,yhi,face_clr,~,useColor)
    x=x(:)'; ylo=ylo(:)'; yhi=yhi(:)';
    valid=isfinite(x)&isfinite(ylo)&isfinite(yhi);
    if ~any(valid), return; end
    xv=[x(valid),fliplr(x(valid))]; yv=[ylo(valid),fliplr(yhi(valid))];
    if useColor
        fill(ax,xv,yv,face_clr,'FaceAlpha',1.0,'EdgeColor','none','LineWidth',0.5,'HandleVisibility','off');
    else
        fill(ax,xv,yv,[0.88 0.88 0.88],'FaceAlpha',1.0,'EdgeColor',[0.5 0.5 0.5], ...
            'LineStyle','--','LineWidth',0.5,'HandleVisibility','off');
    end
end

function exportEPS(figHandle,filename,useColor)
    set(figHandle,'Renderer','painters'); drawnow; pause(0.5);
    if useColor
        print(figHandle,filename,'-depsc2','-cmyk','-r300');
    else
        print(figHandle,filename,'-deps','-r600');
    end
    pause(0.5); fprintf('    Saved: %s\n',filename);
end
