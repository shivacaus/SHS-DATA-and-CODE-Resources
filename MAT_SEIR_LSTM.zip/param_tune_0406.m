%% param_tune_0406_fixed.m  — Unified Parameter Tuning Pipeline
%  Combines: (1) Lag Tuning  (2) Smoothing Parameter Tuning  (3) LSTM HP Tuning
%  Author: [SHS] | 
%  Updated: 2025-11-12
% REQUIRED: Epidemic and meteorological data_Nepal.xlsx
%  ═══════════════════════════════════════════════════════════════════
clear; clc; close all;
rng(42,'twister');
fprintf('==========================================================\n');
fprintf('  UNIFIED TUNING PIPELINE\n');
fprintf('  Stage 1: Lag  |  Stage 2: Smooth  |  Stage 3: LSTM HP\n');
fprintf('==========================================================\n\n');

try
    gd=gpuDevice(1);
    fprintf('  GPU detected: %s (%.1f GB)\n', gd.Name, gd.TotalMemory/1e9);
catch
    fprintf('  No GPU detected — running on CPU\n');
end

%% ===================================================================
%% BLOCK 0 — SHARED CONSTANTS AND RAW DATA LOAD
%% ===================================================================
fprintf('--- Block 0: Loading data and constants ---\n');

data       = readtable('Epidemic and meteorological data_Nepal.xlsx');
I_raw_g    = data.I;           R_raw_g   = data.R_c;
DD_g       = data.Death_Daily; N_pop_g   = data.N_Living;
T2M_g      = data.T2M;         RH2M_g    = data.RH2M;  WS2M_g = data.WS2M;
u_t_g      = data.u_t;         v_t_g     = data.v_t;
incd_raw_g = data.I_Daily;     dates_g   = data.Date;
n_days_raw = height(data);
fprintf('  Raw rows: %d\n', n_days_raw);

epsilon_fixed=1/5.1; v_e=0.65;
b_min=1e-5; b_max=1.8; r_min=1/28; r_max=1/2;
e_min=1/21; e_max=1/1.25; u_min=0; u_max=0.95;
d_min=0; d_max=1e-4; R_lo=0.005; R_hi=6.0;

dth_lag=3; lambda_E4=0.20; theta_E=0.50;
n_iter_E=25; tol_E=1e-5;
sqln=28; lambda_reg=2e-5; lambda_Rt_seir=0.40;  
numFtr=10;
eta_base=0.01; R_grid_n=2500;
prior_mean=0.95; prior_sd=0.25;
SI_vrnt = {
    datetime(2020,5,8),  datetime(2020,10,31), 'Wild-type', 5.5, 3.5, 28;
    datetime(2020,11,1), datetime(2021,4,30),  'Alpha',     5.0, 3.2, 25;
    datetime(2021,5,1),  datetime(2021,12,15), 'Delta',     4.7, 2.8, 22;
    datetime(2021,12,16),datetime(2022,12,31), 'Omicron',   3.5, 2,   18;
};
n_vrnt=size(SI_vrnt,1);

incub_kern=gampdf(0:21,5.8,0.9); incub_kern=incub_kern/sum(incub_kern);
incub_kern_c=flipud(incub_kern(:));
cdf_incub_g = cumsum(incub_kern(:));
surv_kern_g  = max(1 - cdf_incub_g, 0);
surv_kern_g  = surv_kern_g / max(sum(surv_kern_g), 1e-12);
T_surv_g     = numel(surv_kern_g);

fprintf('  numFtr=%d (S,E,I,R,u,delta,T,RH,WS,EpiRt — no eps_lag/epoch)\n', numFtr);
fprintf('  Constants ready.\n\n');

%% ===================================================================
%% STAGE 1 — LAG TUNING
%% ===================================================================
fprintf('=== STAGE 1: Lag Tuning ===\n');

lag_max=21; df_time=3;
standardise=@(v,idx_)(v-mean(v(idx_)))/(std(v(idx_))+1e-10);
incd_smooth_lag=movmean(incd_raw_g,7,'Endpoints','shrink');
incd_smooth_lag=max(incd_smooth_lag,0);
t_start_lag=lag_max+1;
idx_lag=t_start_lag:n_days_raw;
n_lag=length(idx_lag);
Y_lag=incd_smooth_lag(idx_lag);

x_T_s =standardise(T2M_g, idx_lag);
x_RH_s=standardise(RH2M_g,idx_lag);
x_WS_s=standardise(WS2M_g,idx_lag);
x_u_s =standardise(u_t_g, idx_lag);

t_sc=((1:n_lag)'-n_lag/2)/(n_lag/2);
B_time=ns_basis(t_sc,df_time);

Y_lag1_raw=nan(n_lag,1);
Y_lag1_raw(2:end)=log(incd_smooth_lag(idx_lag(1:end-1))+1);
valid_ar=~isnan(Y_lag1_raw);
Y_lag1=(Y_lag1_raw-mean(Y_lag1_raw(valid_ar)))/(std(Y_lag1_raw(valid_ar))+1e-10);

pred_full_s={x_T_s,x_RH_s,x_WS_s,x_u_s};
pred_names_lag={'T2M','RH2M','WS2M','u_t'};
n_pred=4; lags_v=0:lag_max;
w_base_lag=[0.50,0.15,0.35];

% ---- Method 1: AIC Grid ----
lag_AIC=zeros(1,n_pred); AIC_curves=zeros(n_pred,lag_max+1);
for p=1:n_pred
    aic_vec=nan(1,lag_max+1);
    for li=1:length(lags_v)
        xl=extract_lag(pred_full_s{p},lags_v(li),idx_lag);
        vld=~isnan(xl)&~isnan(Y_lag1);
        Xv=[ones(sum(vld),1),xl(vld),B_time(vld,:),Y_lag1(vld)];
        [~,~,~,qaic]=qpois_glm(Xv,Y_lag(vld));
        aic_vec(li)=qaic;
    end
    AIC_curves(p,:)=aic_vec;
    [~,bi]=min(aic_vec); lag_AIC(p)=lags_v(bi);
end

% ---- Method 2: Partial CCF ----
lag_CCF=zeros(1,n_pred); CCF_curves=zeros(n_pred,lag_max+1);
C_conf=[B_time,Y_lag1]; valid_ccf=all(~isnan(C_conf),2);
C_v0=C_conf(valid_ccf,:); Y_v0=Y_lag(valid_ccf);
[Q_c,R_c,~]=qr(C_v0,0);
tol_qr=max(size(C_v0))*eps(norm(R_c));
if sum(abs(diag(R_c))>tol_qr)<size(C_v0,2)
    coef_Y=pinv(C_v0)*Y_v0;
else
    coef_Y=R_c\(Q_c'*Y_v0);
end
resY=nan(n_lag,1); resY(valid_ccf)=Y_v0-C_v0*coef_Y;
for p=1:n_pred
    ccf_vals=nan(1,lag_max+1);
    for li=1:length(lags_v)
        xl=extract_lag(pred_full_s{p},lags_v(li),idx_lag);
        vld=~isnan(xl)&~isnan(resY);
        if sum(vld)<10, continue; end
        Cv=C_conf(vld,:); xv=xl(vld);
        [Qx,Rx,~]=qr(Cv,0);
        tolx=max(size(Cv))*eps(norm(Rx));
        if sum(abs(diag(Rx))>tolx)<size(Cv,2)
            cx=pinv(Cv)*xv;
        else
            cx=Rx\(Qx'*xv);
        end
        resX=xv-Cv*cx;
        ccf_vals(li)=corr(resX,resY(vld),'Type','Spearman');
    end
    CCF_curves(p,:)=ccf_vals;
    [~,bi]=max(abs(ccf_vals)); lag_CCF(p)=lags_v(bi);
end

% ---- Method 3: P-spline ----
lag_PSP=nan(1,n_pred); psp_valid=false(1,n_pred);
D2=diff(eye(lag_max+1),2); Pen=D2'*D2;
lambdas_psp=logspace(-1,3,30);
for p=1:n_pred
    L=zeros(n_lag,lag_max+1);
    for li=1:length(lags_v), L(:,li)=extract_lag(pred_full_s{p},lags_v(li),idx_lag); end
    L_scale=std(L,0,1)+1e-10; L_norm=L./L_scale;
    X_conf_p=[ones(n_lag,1),B_time,Y_lag1];
    X_full_p=[X_conf_p,L_norm];
    vld_r=all(~isnan(X_full_p),2);
    Xv=X_full_p(vld_r,:); Yv=Y_lag(vld_r); nv=sum(vld_r);
    n_par=size(Xv,2); n_conf_p=size(X_conf_p,2);
    lag_cols=n_conf_p+1:n_par;
    P_full=zeros(n_par); gcv_vec=nan(size(lambdas_psp));
    for li2=1:length(lambdas_psp)
        lam=lambdas_psp(li2);
        P_full(lag_cols,lag_cols)=lam*Pen;
        [bt,~,dev_t,~]=qpois_penalised(Xv,Yv,P_full);
        if isnan(dev_t)||isinf(dev_t), continue; end
        mu_t=max(exp(Xv*bt),1e-10); sqW=sqrt(mu_t);
        Xw_t=Xv.*sqW; XtWX=Xw_t'*Xw_t+P_full+1e-4*eye(n_par);
        XtWX_inv=XtWX\eye(n_par);
        trH=sum(sum((Xw_t*XtWX_inv).*Xw_t,2));
        denom=max(1-trH/nv,1e-6)^2;
        gcv_vec(li2)=dev_t/(nv*denom);
    end
    if all(isnan(gcv_vec)), lam_opt=10;
    else, [~,bi]=min(gcv_vec); lam_opt=lambdas_psp(bi);
    end
    P_full(lag_cols,lag_cols)=lam_opt*Pen;
    beta_all=qpois_penalised(Xv,Yv,P_full);
    beta_lag=beta_all(lag_cols)./L_scale';
    bi_int_all=abs(beta_lag(2:end-1));
    if max(bi_int_all)>0.1*max(abs(beta_lag)+1e-10)
        [~,bii]=max(bi_int_all); lag_PSP(p)=lags_v(bii+1); psp_valid(p)=true;
    end
end

% ---- Consensus ----
cand_mat=nan(n_pred,3);
cand_mat(:,1)=lag_AIC(:); cand_mat(:,2)=lag_CCF(:);
for p=1:n_pred, if psp_valid(p), cand_mat(p,3)=lag_PSP(p); end, end
lag_consensus=zeros(1,n_pred);
for p=1:n_pred
    row=cand_mat(p,:); vld=~isnan(row);
    vals=row(vld); w_raw=w_base_lag(vld); w_n=w_raw/sum(w_raw);
    lw=round(sum(w_n.*vals));
    if any(vals==0), lag_consensus(p)=max(0,min(lag_max,lw));
    else,            lag_consensus(p)=max(1,min(lag_max-1,lw));
    end
end

tau.T2M =lag_consensus(1);
tau.RH2M=lag_consensus(2);
tau.WS2M=lag_consensus(3);
tau.u_t =lag_consensus(4);
tau_max =max(lag_consensus);

fprintf('  Lag results (AIC | CCF | Pspline | Consensus):\n');
for p=1:n_pred
    if psp_valid(p), ps=sprintf('%d',lag_PSP(p)); else, ps='--'; end
    fprintf('    %-6s : AIC=%2d  CCF=%2d  PSP=%-3s  => %2d days\n',...
        pred_names_lag{p},lag_AIC(p),lag_CCF(p),ps,lag_consensus(p));
end
fprintf('  tau_max = %d\n\n', tau_max);

%% ===================================================================
%% BLOCK 1.1 — APPLY TUNED LAGS + BURN-IN TRIM
%% ===================================================================
u_comb=min(max(1-(1-u_t_g).*(1-v_t_g.*v_e),u_min),u_max);
u_pad=[nan(tau.u_t,1);u_comb(1:end-tau.u_t)];
u_ts_g=movmean(u_pad,[7 0],'omitnan','Endpoints','shrink');
u_ts_g=min(max(fillmissing(u_ts_g,'nearest'),u_min),u_max);
y_yr_g=year(dates_g); alpha_g=zeros(n_days_raw,1);
alpha_g(y_yr_g==2020)=5.65479e-05;
alpha_g(y_yr_g==2021)=5.60274e-05;
alpha_g(y_yr_g==2022)=5.52329e-05;
T2M_lag =fillmissing(lagmatrix(T2M_g, tau.T2M), 'nearest');
RH2M_lag=fillmissing(lagmatrix(RH2M_g,tau.RH2M),'nearest');
WS2M_lag=fillmissing(lagmatrix(WS2M_g,tau.WS2M),'nearest');
met_lag_g=[T2M_lag,RH2M_lag,WS2M_lag];
keep=(tau_max+1):n_days_raw;
dates_k=dates_g(keep);     I_raw_k=I_raw_g(keep);   R_raw_k=R_raw_g(keep);
DD_k=DD_g(keep);           N_pop_k=N_pop_g(keep);    u_ts_k=u_ts_g(keep);
alpha_k=alpha_g(keep);     met_lag_k=met_lag_g(keep,:);
incd_raw_k=incd_raw_g(keep); n_days=numel(keep);
fprintf('  After burn-in trim (tau_max=%d): %d days\n\n',tau_max,n_days);

%% ===================================================================
%% STAGE 2 — SMOOTHING PARAMETER TUNING
%% ===================================================================
fprintf('=== STAGE 2: Smoothing Parameter Tuning ===\n');

grid_smth_win  = [7  10 14 21 28];
grid_sg_win    = [7   9 11 15 21];
grid_sg_deg    = [2   3];
grid_win_Size  = [7  10 14 21];
grid_smooth_Rt = [7  10 14 21 28];
w_C1=0.30; w_C2=0.20; w_C3=0.20; w_C4=0.20; w_C5=0.10;

n1s=numel(grid_smth_win); n2s=numel(grid_sg_win); n3s=numel(grid_sg_deg);
n4s=numel(grid_win_Size); n5s=numel(grid_smooth_Rt);
N_smooth=n1s*n2s*n3s*n4s*n5s;
[G1s,G2s,G3s,G4s,G5s]=ndgrid(1:n1s,1:n2s,1:n3s,1:n4s,1:n5s);
all_idx_s=[G1s(:),G2s(:),G3s(:),G4s(:),G5s(:)];
rng(0,'twister'); perm_s=randperm(size(all_idx_s,1));
n_pilot=30; pilot_raw=nan(n_pilot,5); pc_done=0; pc_s=1;
while pc_done<n_pilot && pc_s<=numel(perm_s)
    ii=all_idx_s(perm_s(pc_s),:); pc_s=pc_s+1;
    sw_p=grid_smth_win(ii(1)); sgw_p=grid_sg_win(ii(2));
    sgd_p=grid_sg_deg(ii(3));  wsz_p=grid_win_Size(ii(4)); rtsw_p=grid_smooth_Rt(ii(5));
    if sgd_p>=sgw_p, continue; end
    try
        [c1,c2,c3,c4,c5]=eval_smooth_combo(sw_p,sgw_p,sgd_p,wsz_p,rtsw_p,...
            I_raw_k,R_raw_k,DD_k,N_pop_k,u_ts_k,alpha_k,incd_raw_k,...
            epsilon_fixed,b_min,b_max,r_min,r_max,e_min,e_max,...
            d_min,d_max,dth_lag,lambda_E4,theta_E,n_iter_E,tol_E,...
            incub_kern_c,surv_kern_g,T_surv_g,n_days);
        pc_done=pc_done+1; pilot_raw(pc_done,:)=[c1,c2,c3,c4,c5];
    catch ME
        warning('Smooth pilot: %s',ME.message);
    end
end
pilot_raw=pilot_raw(1:pc_done,:);
ref_C1=max(prctile(pilot_raw(:,1),95),1e-10); ref_C2=max(prctile(pilot_raw(:,2),95),1e-10);
ref_C3=max(prctile(pilot_raw(:,3),95),0.10);  ref_C4=max(prctile(pilot_raw(:,4),95),0.01);
ref_C5=max(prctile(pilot_raw(:,5),95),1e-10);
fprintf('  Pilot n=%d | 95th refs: C1=%.2e C2=%.4f C3=%.2f C4=%.4f C5=%.2e\n',...
    pc_done,ref_C1,ref_C2,ref_C3,ref_C4,ref_C5);
rng(42,'twister');

res_s=nan(N_smooth,11); row_s=0;
for i1=1:n1s
for i2=1:n2s
for i3=1:n3s
for i4=1:n4s
for i5=1:n5s
    sw=grid_smth_win(i1); sgw=grid_sg_win(i2); sgd=grid_sg_deg(i3);
    wsz=grid_win_Size(i4); rtsw=grid_smooth_Rt(i5);
    row_s=row_s+1; res_s(row_s,1:5)=[sw,sgw,sgd,wsz,rtsw];
    if sgd>=sgw, continue; end
    try
        [c1,c2,c3,c4,c5]=eval_smooth_combo(sw,sgw,sgd,wsz,rtsw,...
            I_raw_k,R_raw_k,DD_k,N_pop_k,u_ts_k,alpha_k,incd_raw_k,...
            epsilon_fixed,b_min,b_max,r_min,r_max,e_min,e_max,...
            d_min,d_max,dth_lag,lambda_E4,theta_E,n_iter_E,tol_E,...
            incub_kern_c,surv_kern_g,T_surv_g,n_days);
    catch ME
        warning('Smooth grid: %s',ME.message); continue
    end
    C1n=min(c1/ref_C1,3); C2n=min(c2/ref_C2,3); C3n=min(c3/ref_C3,3);
    C4n=min(c4/ref_C4,1); C5n=min(c5/ref_C5,3);
    res_s(row_s,:)=[sw,sgw,sgd,wsz,rtsw, C1n,C2n,C3n,C4n,C5n,...
        w_C1*C1n+w_C2*C2n+w_C3*C3n+w_C4*C4n+w_C5*C5n];
end
end
end
end
end

vld_s=isfinite(res_s(:,11)); Rs=res_s(vld_s,:); [~,si]=sort(Rs(:,11)); Rs=Rs(si,:);
best_s=Rs(1,:);
smth_win    =best_s(1);
sg_win      =best_s(2);
sg_deg      =best_s(3);
win_Size    =best_s(4);
smooth_win_Rt=best_s(5);

fprintf('  Best smooth config: smth_win=%d  sg_win=%d  sg_deg=%d  win_Size=%d  smooth_win_Rt=%d\n',...
    smth_win,sg_win,sg_deg,win_Size,smooth_win_Rt);
fprintf('  Score=%.4f  (C1=%.3f C2=%.3f C3=%.3f C4=%.3f C5=%.3f)\n\n',...
    best_s(11),best_s(6),best_s(7),best_s(8),best_s(9),best_s(10));

%% ===================================================================
%% BLOCK 2.1 — FULL-SERIES CAUSAL COVARIATES FOR STAGE 3
%% ===================================================================
fprintf('  Computing full-series causal covariates...\n');

I_sn_full=min(max(causal_smooth(I_raw_k./N_pop_k,smth_win),0),1);
D_s_full=max(causal_smooth(DD_k,smth_win),0);
I_sftd_f=fillmissing([nan(dth_lag,1);I_sn_full(1:end-dth_lag)],'nearest');
delta_t_full=causal_smooth(min(max(D_s_full./max(I_sftd_f.*N_pop_k,1),d_min),d_max),smth_win);
alpha_full=causal_smooth(alpha_k,smth_win);

R_grid=linspace(R_lo,R_hi,R_grid_n)'; dR_step=R_grid(2)-R_grid(1);
[R1ef,R2ef]=meshgrid(R_grid,R_grid);
T_mat_r=normpdf(R1ef,R2ef,sqrt(eta_base)); T_mat_r(R1ef<R_lo|R1ef>R_hi)=0;
cs=sum(T_mat_r,1)*dR_step; cs(cs==0)=1; T_mat_ef=(T_mat_r./cs)*dR_step;
pr_R=normpdf(R_grid,prior_mean,prior_sd); pr_R=max(pr_R,0); pr_R=pr_R/(sum(pr_R)*dR_step);

t_epoch_s=dates_k(1); t_dn_s=days(dates_k-t_epoch_s);
t_trns_s=zeros(n_vrnt,1);
for vv=1:n_vrnt, t_trns_s(vv)=days(SI_vrnt{vv,1}-t_epoch_s); end
si_pmf_v=cell(n_vrnt,1); si_mx_v=zeros(n_vrnt,1);
for vv=1:n_vrnt
    sm_v=SI_vrnt{vv,4}; sd_v=SI_vrnt{vv,5}; sx_v=SI_vrnt{vv,6};
    pv=gampdf((0:sx_v)',(sm_v/sd_v)^2,sd_v^2/sm_v); pv(1)=0;
    sv=sum(pv); if sv>0,pv=pv/sv; else,pv=zeros(sx_v+1,1);pv(2)=1; end
    si_pmf_v{vv}=pv; si_mx_v(vv)=sx_v;
end
max_si=max(si_mx_v);
si_pmf_daily=build_si_pmf_daily(n_days,t_dn_s,t_trns_s,n_vrnt,si_pmf_v,si_mx_v,max_si,14);

incd_ef_full=max(round(movmean(incd_raw_k,7,'omitnan')),0);
reliable_full=movsum(incd_ef_full,7,'omitnan')>=10;
pRc_f=pr_R*dR_step; EpiR_full=nan(n_days,1);
for t=1:n_days
    pmft=si_pmf_daily{t}; avt=min(t-1,numel(pmft)-1); Lt=0;
    if avt>=1, Lt=pmft(2:avt+1)'*incd_ef_full(t-1:-1:t-avt); end
    Lt=max(Lt,1e-8);
    if t==1, pRp=pRc_f;
    else
        pRp=T_mat_ef*pRc_f; pRp=max(pRp,0);
        sv=sum(pRp); if sv>0,pRp=pRp/sv; else,pRp=ones(R_grid_n,1)/R_grid_n; end
    end
    if reliable_full(t)
        ll=incd_ef_full(t).*log(R_grid*Lt+1e-300)-R_grid*Lt;
        ll=ll-max(ll); lk=exp(ll); pRps=pRp.*lk; sv=sum(pRps);
        if sv>1e-300, pRps=pRps/sv; else, pRps=pRp; end
    else, pRps=pRp;
    end
    pRc_f=pRps;
    if reliable_full(t), EpiR_full(t)=sum(R_grid.*pRps); end
end
el_f=tau_max+1; Ef_f=fillmissing(EpiR_full,'movmedian',[win_Size 0]);
EpiR_full=max(causal_smooth(fillmissing([nan(el_f,1);Ef_f(1:end-el_f)],'nearest'),smth_win),0);
R_sn_full=min(max(causal_smooth(R_raw_k./N_pop_k,smth_win),0),1);
dI_full_g=causal_deriv_sg(I_sn_full,sg_win,sg_deg);
dR_full_g=causal_deriv_sg(R_sn_full,sg_win,sg_deg);
I_sftd_g2=fillmissing([nan(dth_lag,1);I_sn_full(1:end-dth_lag)],'nearest');
delta_t_g2=causal_smooth(min(max(causal_smooth(DD_k,smth_win)./...
    max(I_sftd_g2.*N_pop_k,1),d_min),d_max),smth_win);
rho_full_g=causal_smooth(min(max(fillmissing(real(...
    (dR_full_g+alpha_full.*R_sn_full-delta_t_g2.*I_sn_full.*R_sn_full)./...
    (I_sn_full+1e-6)),'movmedian',[win_Size 0]),r_min),r_max),smth_win);
E_sn_full=causal_smooth(max(...
    (dI_full_g+(rho_full_g+delta_t_g2+alpha_full).*I_sn_full-...
     delta_t_g2.*I_sn_full.^2)./epsilon_fixed,1e-6),smth_win);
E_sn_full=max(E_sn_full,0.8*I_sn_full);
S_sn_full=max(1-E_sn_full-I_sn_full-R_sn_full,0);
TS_full=max(S_sn_full+E_sn_full+I_sn_full+R_sn_full,1e-6);
S_sn_full=S_sn_full./TS_full; E_sn_full=E_sn_full./TS_full;
I_sn_full_n=I_sn_full./TS_full; R_sn_full=R_sn_full./TS_full;

epoch_full=zeros(n_days,1);
for vv_f=1:n_vrnt
    iv_f=find(dates_k>=SI_vrnt{vv_f,1},1,'first');
    if ~isempty(iv_f)
        for tt_f=1:n_days
            epoch_full(tt_f)=epoch_full(tt_f)+1/(1+exp(-(tt_f-iv_f)/7));
        end
    end
end
epoch_full=epoch_full/max(epoch_full+1e-8);

reliable_full2=movsum(max(round(movmean(incd_raw_k,7,'omitnan')),0),7,'omitnan')>=10;

fprintf('  Full-series covariates ready.\n\n');

%% ===================================================================
%% STAGE 3 — LSTM HYPERPARAMETER TUNING (Bayesian Optimisation)
%% ===================================================================
fprintf('=== STAGE 3: LSTM Hyperparameter Tuning (Bayesian BO) ===\n');

bo_cv_trn_init=250; bo_cv_val_len=120; bo_cv_step=180;
bo_cv_starts=(bo_cv_trn_init+1):bo_cv_step:(n_days-sqln-bo_cv_val_len+1);
bo_cv_starts=bo_cv_starts(1:min(end,2)); n_bo_folds=numel(bo_cv_starts);
fprintf('  Walk-forward folds: %d\n',n_bo_folds);
for f=1:n_bo_folds
    fprintf('    Fold %d: train [1..%d]  val [%d..%d]\n',f,...
        bo_cv_starts(f)-1,bo_cv_starts(f),...
        min(bo_cv_starts(f)+bo_cv_val_len-1,n_days-sqln));
end

w_param=0.40; w_traj=0.40; w_Rt=0.20;

sh.I_raw_k=I_raw_k;   sh.R_raw_k=R_raw_k;   sh.DD_k=DD_k;
sh.N_pop_k=N_pop_k;   sh.u_ts_k=u_ts_k;     sh.alpha_k=alpha_k;
sh.met_lag_k=met_lag_k; sh.incd_raw_k=incd_raw_k;
sh.dates_k=dates_k;   sh.n_days=n_days;
sh.delta_t_full=delta_t_full; sh.alpha_full=alpha_full; sh.EpiR_full=EpiR_full;
sh.S_full=S_sn_full; sh.E_full=E_sn_full;
sh.I_full=I_sn_full_n; sh.R_full=R_sn_full;
sh.delta_t_full2=delta_t_g2;  
sh.epoch_full=epoch_full;
sh.reliable_full2=reliable_full2;
sh.epsilon_fixed=epsilon_fixed;
sh.b_min=b_min; sh.b_max=b_max; sh.r_min=r_min; sh.r_max=r_max;
sh.e_min=e_min; sh.e_max=e_max; sh.d_min=d_min; sh.d_max=d_max;
sh.R_lo=R_lo;   sh.R_hi=R_hi;
sh.smth_win=smth_win; sh.win_Size=win_Size; sh.dth_lag=dth_lag;
sh.sg_win=sg_win; sh.sg_deg=sg_deg;
sh.lambda_E4=lambda_E4; sh.theta_E=theta_E; sh.n_iter_E=n_iter_E; sh.tol_E=tol_E;
sh.lambda_reg=lambda_reg; sh.lambda_Rt_seir=lambda_Rt_seir;
sh.sqln=sqln; sh.numFtr=numFtr;
sh.SI_vrnt=SI_vrnt; sh.n_vrnt=n_vrnt;
sh.T_mat_ef=T_mat_ef; sh.R_grid=R_grid; sh.dR_step=dR_step;
sh.pr_R=pr_R; sh.R_grid_n=R_grid_n; sh.si_pmf_daily=si_pmf_daily;
sh.bo_cv_starts=bo_cv_starts; sh.bo_cv_val_len=bo_cv_val_len; sh.n_bo_folds=n_bo_folds;
sh.w_param=w_param; sh.w_traj=w_traj; sh.w_Rt=w_Rt;
sh.bo_max_ep=20; sh.bo_patience=8;
sh.surv_kern=surv_kern_g; sh.T_surv=T_surv_g;
sh.incub_kern_c=incub_kern_c;

vars=[
    optimizableVariable('hdnsz1', [32,128],   'Type','integer')
    optimizableVariable('hdnsz2', [16,64],    'Type','integer')
    optimizableVariable('fcSize', [16,64],    'Type','integer')
    optimizableVariable('dropR',  [0.10,0.60],'Type','real')
    optimizableVariable('dropR2', [0.05,0.50],'Type','real')
    optimizableVariable('L2Reg',  [1e-5,1e-2],'Type','real','Transform','log')
    optimizableVariable('ILR',    [5e-5,5e-3],'Type','real','Transform','log')
    optimizableVariable('LRDF',   [0.20,0.90],'Type','real')
    optimizableVariable('LRDP',   [5,40],     'Type','integer')
    optimizableVariable('GT',     [0.10,5.00],'Type','real')
    optimizableVariable('MB',     [64,128],   'Type','integer')
    optimizableVariable('lam_S_w',[0.10,2.00],'Type','real','Transform','log')
    optimizableVariable('lam_E_w',[0.05,3.0],'Type','real','Transform','log')
    optimizableVariable('lam_I_w',[0.05,4.00],'Type','real','Transform','log')
    optimizableVariable('lam_R_w',[0.10,2.00],'Type','real','Transform','log')
    optimizableVariable('lam_mass',[0.01,1.00],'Type','real','Transform','log')
    optimizableVariable('lam_rho',[0.01,1.00],'Type','real','Transform','log')
];

fprintf('  BO variables: %d | folds: %d | epochs/fold: %d | patience: %d\n',...
    numel(vars),n_bo_folds,sh.bo_max_ep,sh.bo_patience);
fprintf('  numFtr=%d (v20: no eps_lag/epoch cols)\n\n',numFtr);

bo_results=bayesopt(@(hp)bo_objective(hp,sh),vars,...
    'AcquisitionFunctionName','expected-improvement-plus',...
    'MaxObjectiveEvaluations',30,...
    'NumSeedPoints',10,...
    'IsObjectiveDeterministic',false,...
    'UseParallel',false,...
    'Verbose',1,...
    'PlotFcn',[]);

%% ===================================================================
%% FINAL RESULTS 
%% ===================================================================
best_hp=bo_results.XAtMinEstimatedObjective;
best_loss=bo_results.MinEstimatedObjective;
hdnsz1_r=best_hp.hdnsz1;
hdnsz2_r=min(best_hp.hdnsz2,best_hp.hdnsz1);

fprintf('\n');
fprintf('##################################################################\n');
fprintf('##  PASTE BLOCK — copy everything below into SEIR-LSTM ##\n');
fprintf('##################################################################\n\n');

fprintf('%% ── Stage 1: Tuned Lags ──\n');
fprintf('tau.T2M  = %d;\n',tau.T2M);
fprintf('tau.RH2M = %d;\n',tau.RH2M);
fprintf('tau.WS2M = %d;\n',tau.WS2M);
fprintf('tau.u_t  = %d;\n',tau.u_t);
fprintf('tau_max  = %d;\n\n',tau_max);

fprintf('%% ── Stage 2: Tuned Smoothing Parameters ──\n');
fprintf('smth_win      = %d;\n',smth_win);
fprintf('sg_win        = %d;\n',sg_win);
fprintf('sg_deg        = %d;\n',sg_deg);
fprintf('win_Size      = %d;\n',win_Size);
fprintf('smooth_win_Rt = %d;\n\n',smooth_win_Rt);

fprintf('%% ── Stage 3: Tuned LSTM Hyperparameters (numFtr=10) ──\n');
fprintf('%% Composite CV loss = %.6f\n',best_loss);
fprintf('HP.hdnsz1 = %d;\n',hdnsz1_r);
fprintf('HP.hdnsz2 = %d;\n',hdnsz2_r);
fprintf('HP.fcSize = %d;\n',best_hp.fcSize);
fprintf('HP.dropR  = %.4f;\n',best_hp.dropR);
fprintf('HP.dropR2 = %.4f;\n',best_hp.dropR2);
fprintf('HP.ILR    = %.4e;\n',best_hp.ILR);
fprintf('HP.LRDF   = %.4f;\n',best_hp.LRDF);
fprintf('HP.LRDP   = %d;\n',best_hp.LRDP);
fprintf('HP.L2Reg  = %.4e;\n',best_hp.L2Reg);
fprintf('HP.GT     = %.4f;\n',best_hp.GT);
fprintf('HP.MB     = %d;\n',best_hp.MB);
fprintf('lam_phys_S = %.4f;\n',best_hp.lam_S_w);
fprintf('lam_phys_E = %.4f;\n',best_hp.lam_E_w);
fprintf('lam_phys_I = %.4f;\n',best_hp.lam_I_w);
fprintf('lam_phys_R = %.4f;\n',best_hp.lam_R_w);
fprintf('lam_mass   = %.4f;\n',best_hp.lam_mass);
fprintf('lam_rho_Rt = %.4f;\n',best_hp.lam_rho);
fprintf('##################################################################\n\n');

T_lags=table({'T2M';'RH2M';'WS2M';'u_t'},lag_consensus(:),...
    'VariableNames',{'Variable','Consensus_Lag'});
T_smooth=table({'smth_win';'sg_win';'sg_deg';'win_Size';'smooth_win_Rt'},...
    [smth_win;sg_win;sg_deg;win_Size;smooth_win_Rt],...
    'VariableNames',{'Parameter','Value'});
hp_names={'hdnsz1','hdnsz2_eff','fcSize','dropR','dropR2','L2Reg',...
    'ILR','LRDF','LRDP','GT','MB','lam_phys_S','lam_phys_E','lam_phys_I',...
    'lam_phys_R','lam_mass','lam_rho_Rt'};
hp_vals=[hdnsz1_r,hdnsz2_r,best_hp.fcSize,best_hp.dropR,best_hp.dropR2,...
    best_hp.L2Reg,best_hp.ILR,best_hp.LRDF,best_hp.LRDP,best_hp.GT,...
    best_hp.MB,best_hp.lam_S_w,best_hp.lam_E_w,best_hp.lam_I_w,...
    best_hp.lam_R_w,best_hp.lam_mass,best_hp.lam_rho];
T_hp=table(hp_names',hp_vals','VariableNames',{'Hyperparameter','Value'});
writetable(T_lags,'tuned_lags.csv');
writetable(T_smooth,'tuned_smooth.csv');
writetable(T_hp,'tuned_lstm_hp.csv');
save('tuned_all_params.mat','tau','tau_max','smth_win','sg_win','sg_deg',...
    'win_Size','smooth_win_Rt','best_hp','hdnsz1_r','hdnsz2_r','best_loss');
fprintf('Saved: tuned_lags.csv | tuned_smooth.csv | tuned_lstm_hp.csv | tuned_all_params.mat\n');
fprintf('=== UNIFIED TUNING COMPLETE ===\n');

%% ===================================================================
%%            LOCAL FUNCTIONS
%% ===================================================================

%% ── STAGE 3 HELPERS ────────────────────────────────────────────────

function loss=bo_objective(hp,sh)
    try
        HP.hdnsz1=hp.hdnsz1; HP.hdnsz2=min(hp.hdnsz2,hp.hdnsz1);
        HP.fcSize=hp.fcSize; HP.dropR=hp.dropR; HP.dropR2=hp.dropR2;
        HP.L2Reg=hp.L2Reg; HP.ILR=hp.ILR; HP.LRDF=hp.LRDF;
        HP.LRDP=hp.LRDP; HP.GT=hp.GT; HP.MB=hp.MB;
        sg_win_loc=sh.sg_win; sg_deg_loc=sh.sg_deg;
        if sg_win_loc<2*sg_deg_loc+1, loss=1e6; return; end
        fold_losses=nan(sh.n_bo_folds,1);
        for fold=1:sh.n_bo_folds
            trn_end=sh.bo_cv_starts(fold)-1;
            val_start_idx=sh.bo_cv_starts(fold);
            val_end_idx=min(sh.bo_cv_starts(fold)+sh.bo_cv_val_len-1,sh.n_days-sh.sqln);

            if trn_end<80 || val_start_idx<=trn_end || val_end_idx<=val_start_idx || ...
               val_end_idx > sh.n_days-sh.sqln
                fold_losses(fold)=1e6; continue;
            end

            [S_fl,E_fl,I_fl,R_fl,~,~,~,u_fl,delta_fl,alpha_fl,...
             ~,EpiR_fl,epoch_fl,~,~,reliable_fl,~,~,pm_cv,ps_cv,...
             X_trn,Y_trn,lp_trn,X_val,Y_val,lp_val,nT,nV]=...
                fold_local_pipeline(fold,trn_end,val_end_idx,sh,sg_win_loc,sg_deg_loc);
            if isempty(X_trn) || isempty(X_val), fold_losses(fold)=1e6; continue; end

            lw=sqrt([1 1 1.5]);
            XTrC=cell(nT,1); for ii=1:nT, XTrC{ii}=squeeze(X_trn(ii,:,:))'; end
            XVaC=cell(nV,1); for ii=1:nV, XVaC{ii}=squeeze(X_val(ii,:,:))'; end
            YTrN=((Y_trn-lp_trn-pm_cv)./ps_cv).*lw;
            YVaN=((Y_val-lp_val-pm_cv)./ps_cv).*lw;

            rt_idx = min(sh.sqln+(1:nT), length(EpiR_fl));
            Rt_fl_tr=EpiR_fl(rt_idx);
            rel_idx = min(sh.sqln+(1:nT), length(reliable_fl));
            rel_fl_tr=reliable_fl(rel_idx);
            ef_idx = min(sh.sqln+(1:nT), length(epoch_fl));
            ef_fl_tr=epoch_fl(ef_idx);

            val_sample_inds_bo = nT+(1:nV);
            pred_time_inds_bo  = sh.sqln+(1:nT+nV);

            lam_sum_bo = hp.lam_S_w+hp.lam_E_w+hp.lam_I_w+hp.lam_R_w+ ...
                         hp.lam_mass+hp.lam_rho;
            fprintf('  BO fold %d/%d: %-3s %-12s %-12s %-10s %-13s %-13s %-13s\n', ...
                fold,sh.n_bo_folds,'Ep','Train-Loss','Val-Loss','LR', ...
                'ValPlateau%','TV_Gap','PhysRes%');

            net_cv=build_and_train_dl_bo(HP,sh.numFtr,XTrC,YTrN,XVaC,YVaN,...
                sh.bo_max_ep,sh.bo_patience, ...
                hp.lam_S_w,hp.lam_E_w,hp.lam_I_w,hp.lam_R_w,hp.lam_mass,hp.lam_rho,...
                lw,pm_cv,ps_cv, ...
                S_fl,E_fl,I_fl,R_fl,u_fl,delta_fl,alpha_fl,...
                sh.sqln,X_trn,lp_trn, ...
                Rt_fl_tr,rel_fl_tr,ef_fl_tr, ...
                val_sample_inds_bo,pred_time_inds_bo, ...
                sh.epsilon_fixed,lam_sum_bo, ...
                sh.S_full,sh.E_full,sh.I_full,sh.R_full,...
                sh.delta_t_full,sh.alpha_full,sh.EpiR_full,...
                sh.epoch_full,sh.reliable_full2,sh.u_ts_k);

            Yh=zeros(nV,3);
            for ii=1:nV
                pr=extractdata(predict(net_cv,dlarray(XVaC{ii},'CBT')));
                yd=decode_yd(pr(:,end),lw,ps_cv,pm_cv);
                Yh(ii,:)=lp_val(ii,:)+yd;
            end
            Yh(:,1)=min(max(Yh(:,1),sh.b_min),sh.b_max);
            Yh(:,2)=min(max(Yh(:,2),sh.r_min),sh.r_max);
            Yh(:,3)=min(max(Yh(:,3),sh.e_min),sh.e_max);

            L_param=(nrmse_safe(Y_val(:,1),Yh(:,1))+nrmse_safe(Y_val(:,2),Yh(:,2))+...
                     nrmse_safe(Y_val(:,3),Yh(:,3)))/3;
            val_start_day=trn_end+sh.sqln+1;
            if val_start_day+nV-1<=sh.n_days
                I_obs_v=min(max(sh.I_raw_k./sh.N_pop_k,0),1);
                I_obs_v=I_obs_v(val_start_day:val_start_day+nV-1);
                [I_traj,S_traj]=rk4_SI_traj(Yh(:,1),Yh(:,2),...
                    S_fl(trn_end),E_fl(trn_end),I_fl(trn_end),R_fl(trn_end),...
                    sh.u_ts_k,sh.delta_t_full,sh.alpha_full,sh.epsilon_fixed,...
                    val_start_day,nV);
                L_traj=nrmse_safe(I_obs_v,I_traj);
                Rt_hat=compute_Rt_NGM(Yh(:,1),Yh(:,2),Yh(:,3),S_traj,...
                    sh.u_ts_k(val_start_day:val_start_day+nV-1),...
                    sh.delta_t_full(val_start_day:val_start_day+nV-1),...
                    sh.alpha_full(val_start_day:val_start_day+nV-1));
                rt_ep_idx = min(val_start_day:val_start_day+nV-1, length(sh.EpiR_full));
                Rt_ep_v=sh.EpiR_full(rt_ep_idx);
                ok_rt=isfinite(Rt_hat)&isfinite(Rt_ep_v)&Rt_ep_v>0;
                if sum(ok_rt)>5, L_Rt=mean(abs(Rt_hat(ok_rt)-Rt_ep_v(ok_rt)));
                else, L_Rt=L_param; end
            else
                L_traj=L_param; L_Rt=L_param;
            end
            fold_losses(fold)=sh.w_param*L_param+sh.w_traj*L_traj+sh.w_Rt*L_Rt;
        end
        fv=fold_losses(isfinite(fold_losses));
        loss=mean(fv); if isnan(loss)||~isfinite(loss), loss=1e6; end
    catch ME
        warning('BO eval error: %s',ME.message); loss=1e6;
    end
end

function [S_fl,E_fl,I_fl,R_fl,beta_fl,rho_fl,eps_fl,u_fl,delta_fl,alpha_fl,...
          met_sm_fl,EpiR_fl,epoch_fl,incd_sm_fl,incd_ef_fl,...
          reliable_fl,fm_cv,fs_cv,pm_cv,ps_cv,...
          X_trn,Y_trn,lp_trn,X_val,Y_val,lp_val,nT,nV]=...
    fold_local_pipeline(fold,trn_end,val_end,sh,sg_win,sg_deg)

    sqln=sh.sqln; numFtr=sh.numFtr; smw=sh.smth_win; epf=sh.epsilon_fixed;
    surv_k=sh.surv_kern; T_sv=sh.T_surv; ikc=sh.incub_kern_c;
    idx=1:trn_end; n_fl=trn_end;

    S_fl=[]; E_fl=[]; I_fl=[]; R_fl=[]; beta_fl=[]; rho_fl=[]; eps_fl=[];
    u_fl=[]; delta_fl=[]; alpha_fl=[]; met_sm_fl=[]; EpiR_fl=[]; epoch_fl=[];
    incd_sm_fl=[]; incd_ef_fl=[]; reliable_fl=[]; fm_cv=[]; fs_cv=[];
    pm_cv=[]; ps_cv=[]; X_trn=[]; Y_trn=[]; lp_trn=[]; X_val=[]; Y_val=[];
    lp_val=[]; nT=0; nV=0;

    if trn_end < sqln + 10, return; end

    I_raw_loc=sh.I_raw_k(idx); R_raw_loc=sh.R_raw_k(idx);
    DD_loc=sh.DD_k(idx); N_pop_loc=sh.N_pop_k(idx);
    u_fl=sh.u_ts_k(idx); alpha_loc=sh.alpha_k(idx);
    met_lag_loc=sh.met_lag_k(idx,:); incd_raw_loc=sh.incd_raw_k(idx);
    dates_loc=sh.dates_k(idx);

    I_sn=min(max(causal_smooth(I_raw_loc./N_pop_loc,smw),0),1);
    R_sn=min(max(causal_smooth(R_raw_loc./N_pop_loc,smw),0),1);
    incd_sm_fl=max(causal_smooth(incd_raw_loc,smw),0);
    incd_ef_fl=max(round(movmean(incd_raw_loc,7,'omitnan')),0);
    reliable_fl=movsum(incd_ef_fl,7,'omitnan')>=10;
    alpha_fl=causal_smooth(alpha_loc,smw);
    met_sm_fl=causal_smooth(met_lag_loc,smw);
    D_s_fl=max(causal_smooth(DD_loc,smw),0);
    I_sftd=fillmissing([nan(sh.dth_lag,1);I_sn(1:end-sh.dth_lag)],'nearest');
    delta_fl=causal_smooth(min(max(D_s_fl./max(I_sftd.*N_pop_loc,1),sh.d_min),sh.d_max),smw);
    incd_norm=incd_sm_fl./max(N_pop_loc,1);

    E_incub_raw=zeros(n_fl,1);
    for tt=1:n_fl
        avail=min(tt,T_sv);
        E_incub_raw(tt)=surv_k(1:avail)'*incd_norm(tt:-1:tt-avail+1);
    end
    E_incub_raw=max(E_incub_raw,0);

    dIp=causal_deriv_sg(I_sn,sg_win,sg_deg); dRp=causal_deriv_sg(R_sn,sg_win,sg_deg);
    rho_p=causal_smooth(min(max(fillmissing(real((dRp+alpha_fl.*R_sn-...
        delta_fl.*I_sn.*R_sn)./(I_sn+1e-6)),'movmedian',[sh.win_Size 0]),sh.r_min),sh.r_max),smw);
    E_p=causal_smooth(max((dIp+(rho_p+delta_fl+alpha_fl).*I_sn-delta_fl.*I_sn.^2)./epf,1e-6),smw);
    E_incub_sm=causal_smooth(max(E_incub_raw,0),smw);
    E_incub_sm=max(E_incub_sm,0.8*I_sn);
    E_p=max(E_p,E_incub_sm);
    Sp=max(1-E_p-I_sn-R_sn,0); TS=max(Sp+E_p+I_sn+R_sn,1e-6);
    S_fl=Sp./TS; E_fl=E_p./TS; I_fl=I_sn./TS; R_fl=R_sn./TS;

    dE_fl=causal_deriv_sg(E_fl,sg_win,sg_deg);
    dI_fl=causal_deriv_sg(I_fl,sg_win,sg_deg);
    dR_fl=causal_deriv_sg(R_fl,sg_win,sg_deg);
    Isf=I_fl+1e-6; Ssf=S_fl+1e-6;
    rho_it=rho_p; eps_it=epf*ones(n_fl,1);
    grth=causal_smooth(dI_fl./Isf,smw);

    E_m1_raw=zeros(n_fl,1);
    for tt=1:n_fl
        avail=min(tt,T_sv);
        E_m1_raw(tt)=surv_k(1:avail)'*incd_norm(tt:-1:tt-avail+1);
    end
    E_m1=causal_smooth(max(E_m1_raw,1e-6),smw);

    E_m2=max(I_fl.*min(max(1.05+grth/epf,1.05),6.0),1e-6);
    dIsm=causal_smooth(dI_fl,smw); dIsd=std(dIsm)+1e-10;
    fg=dIsm>0.5*dIsd; sg2=dIsm>0&~fg; dc=dIsm<=0;
    w1c=0.20*fg+0.15*sg2+0.55*dc; w2c=0.05*fg+0.10*sg2+0.15*dc; w3c=0.75*fg+0.75*sg2+0.30*dc;
    kl2=numel(ikc); Rt_prx=nan(n_fl,1); rl2=movsum(incd_sm_fl,[smw-1 0],'omitnan')>=10;
    for tt=2:n_fl
        av2=min(tt-1,kl2-1); if av2<1,continue; end
        lmt=ikc(2:av2+1)'*incd_sm_fl(tt-1:-1:tt-av2);
        if lmt>1e-8&&rl2(tt), Rt_prx(tt)=incd_sm_fl(tt)/lmt; end
    end
    Rt_prx=causal_smooth(max(min(fillmissing(Rt_prx,'movmedian',[sh.win_Size 0]),sh.R_hi),0),smw);
    Rtrel=Rt_prx>0&isfinite(Rt_prx);
    bprx=causal_smooth(min(max(fillmissing(real((dE_fl+(eps_it+alpha_fl).*E_fl-...
        delta_fl.*I_fl.*E_fl)./max((1-u_fl).*Ssf.*Isf,1e-8)),...
        'movmedian',[sh.win_Size 0]),sh.b_min),sh.b_max),smw);
    M3_0=max(dI_fl+(rho_it+delta_fl+alpha_fl).*I_fl-delta_fl.*I_fl.^2,0);
    E_curr=causal_smooth(max(w1c.*E_m1+w2c.*E_m2+w3c.*causal_smooth(max(M3_0./max(epf,1e-6),1e-6),smw),1e-6),smw);
    E_curr=max(E_curr,max(I_fl.*((rho_it+delta_fl+alpha_fl)./max(epf,1e-6)),0.8*I_fl));
    for it2=1:sh.n_iter_E
        Ep2=E_curr;
        rk=causal_smooth(min(max(fillmissing(real((dR_fl+alpha_fl.*R_fl-delta_fl.*I_fl.*R_fl)./Isf),...
            'movmedian',[sh.win_Size 0]),sh.r_min),sh.r_max),smw);
        M3k=dI_fl+(rk+delta_fl+alpha_fl).*I_fl-delta_fl.*I_fl.^2;
        ek=causal_smooth(min(max(fillmissing(real(M3k./max(Ep2,1e-6)),...
            'movmedian',[sh.win_Size 0]),sh.e_min),sh.e_max),smw);
        Ep1k=max(I_fl.*((rk+delta_fl+alpha_fl-delta_fl.*I_fl)./max(ek,1e-6)),0.8*I_fl);
        Em3k=causal_smooth(max(max(M3k,0)./max(ek,1e-6),1e-6),smw);
        Em4=min(max(Rt_prx.*(rk+delta_fl+alpha_fl).*I_fl./max(bprx.*(1-u_fl).*Ssf,1e-8),0.8*I_fl),10*I_fl);
        Em4(~Rtrel)=Em3k(~Rtrel);
        En=causal_smooth(max((1-sh.lambda_E4).*(w1c.*E_m1+w2c.*E_m2+w3c.*Em3k)+sh.lambda_E4.*Em4,1e-6),smw);
        E_curr=max(sh.theta_E*En+(1-sh.theta_E)*Ep2,Ep1k);
        rho_it=rk; eps_it=ek;
        if norm(E_curr-Ep2)/(norm(Ep2)+1e-8)<sh.tol_E, break; end
    end
    Eph=max(I_fl.*((rho_it+delta_fl+alpha_fl-delta_fl.*I_fl)./max(eps_it,1e-6)),0.8*I_fl);
    E_fl=max(E_curr,Eph);
    Stmp=max(1-E_fl-I_fl-R_fl,0); TS=max(Stmp+E_fl+I_fl+R_fl,1e-6);
    S_fl=Stmp./TS; E_fl=E_fl./TS; I_fl=I_fl./TS; R_fl=R_fl./TS;

    pRc=sh.pr_R*sh.dR_step; EpiR_fl=nan(n_fl,1);
    for t=1:n_fl
        pmft=sh.si_pmf_daily{t}; avt=min(t-1,numel(pmft)-1); Lt=0;
        if avt>=1, Lt=pmft(2:avt+1)'*incd_ef_fl(t-1:-1:t-avt); end
        Lt=max(Lt,1e-8);
        if t==1, pRp=pRc;
        else
            pRp=sh.T_mat_ef*pRc; pRp=max(pRp,0);
            sv=sum(pRp); if sv>0,pRp=pRp/sv; else,pRp=ones(sh.R_grid_n,1)/sh.R_grid_n; end
        end
        if reliable_fl(t)
            ll=incd_ef_fl(t).*log(sh.R_grid*Lt+1e-300)-sh.R_grid*Lt;
            ll=ll-max(ll); lk=exp(ll); pRps=pRp.*lk; sv=sum(pRps);
            if sv>1e-300, pRps=pRps/sv; else, pRps=pRp; end
        else, pRps=pRp;
        end
        pRc=pRps;
        if reliable_fl(t), EpiR_fl(t)=sum(sh.R_grid.*pRps); end
    end
    el=14+1; Ef2=fillmissing(EpiR_fl,'movmedian',[sh.win_Size 0]);
    EpiR_fl=max(causal_smooth(fillmissing([nan(el,1);Ef2(1:end-el)],'nearest'),smw),0);

    dS2=causal_deriv_sg(S_fl,sg_win,sg_deg); dE2=causal_deriv_sg(E_fl,sg_win,sg_deg);
    dI2=causal_deriv_sg(I_fl,sg_win,sg_deg); dR2=causal_deriv_sg(R_fl,sg_win,sg_deg);
    SIsf=(1-u_fl).*(S_fl+1e-6).*(I_fl+1e-6)+1e-6;
    bws=causal_smooth(min(max(fillmissing(real((dE2+(eps_it+alpha_fl).*E_fl-...
        delta_fl.*I_fl.*E_fl)./SIsf),'movmedian',[sh.win_Size 0]),sh.b_min),sh.b_max),smw);
    lop=optimoptions('lsqnonlin','Display','off','MaxIterations',300,...
        'FunctionTolerance',1e-7,'StepTolerance',1e-7);
    lb2=[sh.b_min,sh.r_min,sh.e_min]; ub2=[sh.b_max,sh.r_max,sh.e_max];
    beta_fl=zeros(n_fl,1); rho_fl=zeros(n_fl,1); eps_fl=zeros(n_fl,1);
    x02=[bws(1),rho_it(1),eps_it(1)]; pp2=x02;
    eb2=false(n_fl,1);
    for vv=1:sh.n_vrnt
        iv=find(dates_loc>=sh.SI_vrnt{vv,1},1,'first');
        if ~isempty(iv)&&iv<=n_fl, eb2(iv)=true; end
    end
    Ef3=fillmissing(EpiR_fl,'movmedian',[sh.win_Size 0]);
    for t=1:n_fl
        if eb2(t), x02=[bws(t),rho_it(t),eps_it(t)]; pp2=x02; end
        Rt3=Ef3(t); lRt=sh.lambda_Rt_seir;
        if isnan(Rt3)||Rt3<=0||Rt3>sh.R_hi, lRt=0; end
        fn3=@(p)[seir_residual_v20(p,S_fl(t),E_fl(t),I_fl(t),R_fl(t),u_fl(t),...
            delta_fl(t),alpha_fl(t),dS2(t),dE2(t),dI2(t),dR2(t),Rt3,lRt);...
            sqrt(sh.lambda_reg)*(p-pp2)'];
        [po,~,~,ef3]=lsqnonlin(fn3,[bws(t),rho_it(t),eps_it(t)],lb2,ub2,lop);
        if ef3<0, po=x02; end
        beta_fl(t)=po(1); rho_fl(t)=po(2); eps_fl(t)=po(3);
        pp2=po; x02=po;
    end
    beta_fl=min(max(causal_smooth(beta_fl,7),sh.b_min),sh.b_max);
    rho_fl =min(max(causal_smooth(rho_fl, 7),sh.r_min),sh.r_max);
    eps_fl =min(max(causal_smooth(eps_fl, 7),sh.e_min),sh.e_max);
    [beta_fl,rho_fl,eps_fl]=replaceBadValues(sh.win_Size,beta_fl,rho_fl,eps_fl);

    epoch_fl=zeros(n_fl,1);
    for vv=1:sh.n_vrnt
        iv=find(dates_loc>=sh.SI_vrnt{vv,1},1,'first');
        if ~isempty(iv)
            for tt=1:n_fl, epoch_fl(tt)=epoch_fl(tt)+1/(1+exp(-(tt-iv)/7)); end
        end
    end
    epoch_fl=epoch_fl/max(epoch_fl+1e-8);
    idx_ext=1:val_end;
    u_ext=sh.u_ts_k(idx_ext);
    dlt_ext=[delta_fl;repmat(delta_fl(end),val_end-trn_end,1)];
    met_ext=[met_sm_fl;repmat(met_sm_fl(end,:),val_end-trn_end,1)];
    EpiR_ext=[EpiR_fl;repmat(EpiR_fl(end),val_end-trn_end,1)];
    S_ext=[S_fl;repmat(S_fl(end),val_end-trn_end,1)];
    E_ext=[E_fl;repmat(E_fl(end),val_end-trn_end,1)];
    I_ext=[I_fl;repmat(I_fl(end),val_end-trn_end,1)];
    R_ext=[R_fl;repmat(R_fl(end),val_end-trn_end,1)];
    beta_ext=[beta_fl;repmat(beta_fl(end),val_end-trn_end,1)];
    rho_ext=[rho_fl;repmat(rho_fl(end),val_end-trn_end,1)];
    eps_ext=[eps_fl;repmat(eps_fl(end),val_end-trn_end,1)];

    DM_ext=[S_ext, E_ext, I_ext, R_ext, u_ext, dlt_ext, met_ext, EpiR_ext];

    ns=val_end-sqln;
    if ns <= 0, return; end

    X_all=zeros(ns,sqln,numFtr); Y_all=zeros(ns,3);
    for i=1:ns
        X_all(i,:,:)=DM_ext(i:i+sqln-1,:);
        Y_all(i,:)=[beta_ext(i+sqln),rho_ext(i+sqln),eps_ext(i+sqln)];
    end
    lp_all=[beta_ext(sqln:end-1),rho_ext(sqln:end-1),eps_ext(sqln:end-1)];

    nT = trn_end - sqln;
    vs = sh.bo_cv_starts(fold) - sqln;
    ve = val_end - sqln;
    nV = ve - vs + 1;

    if nT < 5 || nV < 5 || vs < 1 || ve > ns || vs > nT + 1
        return;
    end

    Xf=reshape(X_all(1:nT,:,:),[],numFtr);
    fm_cv=mean(Xf,1); fs_cv=std(Xf,0,1); fs_cv(fs_cv==0)=1;
    X_trn=(X_all(1:nT,:,:)-reshape(fm_cv,[1,1,numFtr]))./reshape(fs_cv,[1,1,numFtr]);
    X_val=(X_all(vs:ve,:,:)-reshape(fm_cv,[1,1,numFtr]))./reshape(fs_cv,[1,1,numFtr]);
    Y_trn=Y_all(1:nT,:); lp_trn=lp_all(1:nT,:);
    Y_val=Y_all(vs:ve,:); lp_val=lp_all(vs:ve,:);
    Yd=Y_trn-lp_trn;
    pm_cv=mean(Yd,1,'omitnan'); ps_cv=std(Yd,0,1,'omitnan'); ps_cv(ps_cv==0)=1;
end

function res=seir_residual_v20(p,S,E,I,R,u,delta,alpha,dS,dE,dI,dR,Rt_tgt,lam)
    b=p(1); r=p(2); ep=p(3); foi=(1-u)*b*S*I; dis=delta*I;
    res=[dS-(alpha*(1-S)-foi+dis*S);
         dE-(foi-(ep+alpha)*E+dis*E);
         dI-(ep*E-(r+delta+alpha)*I+dis*I);
         dR-(r*I-alpha*R+dis*R)];
    if lam>0
        Rt_m = max(b*(1-u)*S / max(r+delta+alpha, 1e-8), 0);
        res=[res; sqrt(lam)*(Rt_m-Rt_tgt)];
    end
end

function net=build_and_train_dl_bo(HP,numFtr,XTrC,YTrN,XVaC,YVaN,mep,pat, ...
        lS,lE,lI,lR,lm,lrho,lw,pm,ps, ...
        S_sn,E_sn,I_sn,R_sn,u_ts,delta_t,alpha_s,sqln,X_trn_local,lp_trn, ...
        Rt_ref_loc,reliable_loc,ef_loc, ...
        val_sample_inds,pred_time_inds_full, ...
        epf,lam_sum, ...
        S_full,E_full,I_full,R_full,delta_t_full,alpha_full,EpiR_full, ...
        epoch_full,reliable_full2,u_ts_full)
    plateau_patience_bo=8; lr_decay_factor_bo=0.60; lr_min_bo=1e-6;
    nTl=numel(XTrC);
    layers=build_layers(HP,numFtr); net=dlnetwork(layers);
    ag=[]; asq=[]; it=0; bv=inf; bn=net; ni=0;
    cur_lr=HP.ILR; lr_at_start=HP.ILR; plateau_count=0; best_val_plat=inf;
    nV_sub=numel(XVaC); lp_rows=size(lp_trn,1); n_val_inds=numel(val_sample_inds);

    prev_val_mon=nan; init_phys_res=nan; prev_gap_mon=nan;

    for ep=1:mep
        is=randperm(nTl); nb2=ceil(nTl/HP.MB); el=0;
        lr=cur_lr;
        for b=1:nb2
            b0=(b-1)*HP.MB+1; b1=min(b*HP.MB,nTl); bi=is(b0:b1);
            bw=pack_batch(bi,X_trn_local,S_sn,E_sn,I_sn,R_sn,u_ts, ...
                delta_t,alpha_s,sqln,Rt_ref_loc,reliable_loc,ef_loc);
            [ls2,gr]=dlfeval(@pinn_loss_fn_v20,net,bw,epf,lS,lE,lI,lR,lm,lrho,...
                YTrN(bi,:),lw,pm,ps,lp_trn(bi,:));
            gr=dlupdate(@(g)norm_clip(g,HP.GT),gr);
            it=it+1; [net,ag,asq]=adamupdate(net,gr,ag,asq,it,lr,0.9,0.999,HP.L2Reg);
            el=el+extractdata(ls2);
        end
        ep_loss_val=el/nb2;

        vl=0;
        for vi=1:nV_sub
            if vi<=n_val_inds
                si=val_sample_inds(vi);
                t0_day=pred_time_inds_full(si);
                win_s=max(1,t0_day-sqln+1);
                win_e=t0_day;
                bw_v=struct(); bw_v.X=XVaC{vi};
                nG=length(S_full);
                ws_g=max(1,win_s); we_g=min(win_e,nG);
                bw_v.S =S_full(ws_g:we_g);    bw_v.E =E_full(ws_g:we_g);
                bw_v.Iv=I_full(ws_g:we_g);    bw_v.R =R_full(ws_g:we_g);
                bw_v.u =u_ts_full(min(ws_g:we_g,length(u_ts_full)));
                bw_v.d =delta_t_full(min(ws_g:we_g,length(delta_t_full)));
                bw_v.a =alpha_full(min(ws_g:we_g,length(alpha_full)));
                t_mid=min(t0_day,nG);
                bw_v.Rt_ref  =EpiR_full(t_mid);
                bw_v.reliable=reliable_full2(t_mid);
                bw_v.ef      =epoch_full(t_mid);
                if isnan(bw_v.Rt_ref)||bw_v.Rt_ref<=0
                    bw_v.Rt_ref=0; bw_v.reliable=false;
                end
                
                n_got=numel(bw_v.S);
                if n_got < sqln
                    pad=sqln-n_got;
                    bw_v.S =[repmat(bw_v.S(1), pad,1); bw_v.S(:)];
                    bw_v.E =[repmat(bw_v.E(1), pad,1); bw_v.E(:)];
                    bw_v.Iv=[repmat(bw_v.Iv(1),pad,1); bw_v.Iv(:)];
                    bw_v.R =[repmat(bw_v.R(1), pad,1); bw_v.R(:)];
                    bw_v.u =[repmat(bw_v.u(1), pad,1); bw_v.u(:)];
                    bw_v.d =[repmat(bw_v.d(1), pad,1); bw_v.d(:)];
                    bw_v.a =[repmat(bw_v.a(1), pad,1); bw_v.a(:)];
                end
                lp_v=lp_trn(min(si,lp_rows),:);
            else
                bw_v=make_fallback_window(vi,nTl,sqln,XVaC,S_full,E_full,I_full,R_full, ...
                         u_ts_full,delta_t_full,alpha_full,EpiR_full,reliable_full2,epoch_full);
                lp_v=lp_trn(min(nTl+vi,lp_rows),:);
            end
            loss_v=dlfeval(@pinn_loss_fn_v20,net,{bw_v},epf,lS,lE,lI,lR,lm,lrho,...
                YVaN(vi,:),lw,pm,ps,lp_v);
            vl=vl+extractdata(loss_v);
        end
        vl=vl/max(nV_sub,1);

        if vl<bv, bv=vl; bn=net; ni=0; else, ni=ni+1; end

        if vl<best_val_plat
            best_val_plat=vl; plateau_count=0; lr_at_start=cur_lr;
        else
            plateau_count=plateau_count+1;
            frac=plateau_count/plateau_patience_bo;
            cosine_f=0.5*(1+cos(pi*frac));
            lr_tgt=max(lr_at_start*lr_decay_factor_bo,lr_min_bo);
            new_lr=max(lr_tgt+(lr_at_start-lr_tgt)*cosine_f,lr_min_bo);
            if new_lr<cur_lr-1e-10, cur_lr=new_lr; end
        end
        if plateau_count>=plateau_patience_bo
            new_lr_f=max(lr_at_start*lr_decay_factor_bo,lr_min_bo);
            if new_lr_f<lr_at_start-1e-10
                cur_lr=new_lr_f; ag=[]; asq=[]; lr_at_start=new_lr_f;
            end
            plateau_count=0; best_val_plat=vl;
        end

        if mod(ep,2)==0 || ep==1
            if isnan(prev_val_mon)||prev_val_mon==0
                vp_str='    --     ';
            else
                vp_pct=100*(vl-prev_val_mon)/abs(prev_val_mon);
                if     vp_pct<-5,  vtag='vv';
                elseif vp_pct<-1,  vtag='v ';
                elseif vp_pct< 1,  vtag='-- ';
                else,              vtag='^ ';
                end
                vp_str=sprintf('%+6.1f%% %s',vp_pct,vtag);
            end
            prev_val_mon=vl;
            gap=ep_loss_val-vl;
            if isnan(prev_gap_mon)
                gap_str='    --     ';
            else
                dgap=gap-prev_gap_mon;
                if gap<0
                    gap_str=sprintf('%+7.4f inv',gap);
                elseif dgap>0.5*abs(gap)
                    gap_str=sprintf('%+7.4f OVF',gap);
                else
                    gap_str=sprintf('%+7.4f ok ',gap);
                end
            end
            prev_gap_mon=gap;
            phys_proxy=ep_loss_val*lam_sum/(1+lam_sum);
            if isnan(init_phys_res), init_phys_res=phys_proxy+eps; end
            phys_pct=100*phys_proxy/init_phys_res;
            if     phys_pct<50,  ptag='stab';
            elseif phys_pct<90,  ptag='conv';
            else,                ptag='high';
            end
            fprintf('    %-3d  %-12.6f %-12.6f %-10.2e %-13s %-13s %5.1f%% %s\n',...
                ep,ep_loss_val,vl,cur_lr,vp_str,gap_str,phys_pct,ptag);
        end

        if ni>=pat, break; end
    end
    net=bn;
end

function [loss,grads]=pinn_loss_fn_v20(net,bw,~,lS,lE,lI,lR,lm,lrho,...
        YN,lw,pm,ps,lp)
    nb=numel(bw); tot=dlarray(0.0);
    for i=1:nb
        w=bw{i}; Xd=dlarray(w.X,'CBT'); out=forward(net,Xd);
        err_d=out-dlarray(YN(i,:)','CB');

        huber_delta=0.5; abs_e3=abs(err_d(3));
        huber_e3=min(0.5*err_d(3)^2,huber_delta*abs_e3-0.5*huber_delta^2);
        data_loss=(0.5*err_d(1)^2+0.5*err_d(2)^2+huber_e3)/3;

        yd2=(out./dlarray(lw','CB')).*dlarray(ps','CB')+dlarray(pm','CB');
        pa=dlarray(lp(i,:)','CB')+yd2;
        bp=max(min(pa(1),1.8),1e-5); rp=max(min(pa(2),0.5),1/35);
        ep_p=max(min(pa(3),1/1.25),1/21);

        beta_start=double(lp(i,1)); rho_start=double(lp(i,2)); eps_start=double(lp(i,3));
        qL=numel(w.Iv);
        Ss=double(w.S); Es=double(w.E); Is=double(w.Iv); Rs=double(w.R);
        us=double(w.u); ds=double(w.d); as=double(w.a);
        Sc=Ss(1); Ec=Es(1); Ic=Is(1); Rc=Rs(1);
        SP=zeros(qL,1,'like',extractdata(bp)); EP=zeros(qL,1,'like',extractdata(bp));
        IP=zeros(qL,1,'like',extractdata(bp)); RP=zeros(qL,1,'like',extractdata(bp));
        SP(1)=Sc; EP(1)=Ec; IP(1)=Ic; RP(1)=Rc;
        for t=2:qL
            t_frac=(t-1)/max(qL-1,1);
            beta_t=beta_start*(1-t_frac)+bp*t_frac;
            rho_t =rho_start*(1-t_frac) +rp*t_frac;
            eps_t =eps_start*(1-t_frac) +ep_p*t_frac;
            fo=(1-us(t-1))*beta_t*Sc*Ic;
            Sc=max(Sc+as(t-1)*(1-Sc)-fo+ds(t-1)*Ic*Sc,0);
            Ec=max(Ec+fo-(eps_t+as(t-1))*Ec+ds(t-1)*Ic*Ec,0);
            Ic=max(Ic+eps_t*Ec-(rho_t+ds(t-1)+as(t-1))*Ic+ds(t-1)*Ic*Ic,0);
            Rc=max(Rc+rho_t*Ic-as(t-1)*Rc+ds(t-1)*Ic*Rc,0);
            SP(t)=Sc; EP(t)=Ec; IP(t)=Ic; RP(t)=Rc;
        end
        Sd=dlarray(single(Ss),'CB'); Ed=dlarray(single(Es),'CB');
        Id=dlarray(single(Is),'CB'); Rd=dlarray(single(Rs),'CB');
        ph=(lS*mean((dlarray(single(SP),'CB')-Sd).^2)+ ...
            lE*mean((dlarray(single(EP),'CB')-Ed).^2)+ ...
            lI*mean((dlarray(single(IP),'CB')-Id).^2)+ ...
            lR*mean((dlarray(single(RP),'CB')-Rd).^2)+ ...
            lm*mean((dlarray(single(SP),'CB')+dlarray(single(EP),'CB')+ ...
                     dlarray(single(IP),'CB')+dlarray(single(RP),'CB')-1).^2));

        rl=dlarray(0.0);
        if lrho>0 && w.reliable && w.Rt_ref>0 && w.Rt_ref<=6
            at=as(end); dt2=ds(end); St=Ss(end);
            rho_impl=bp*ep_p*St / ...
                (max(w.Rt_ref,0.1)*max(ep_p+at,1e-8)) ...
                - dt2 - at;
            rho_impl=max(min(rho_impl,0.5),1/35);
            rl=lrho*(rp-dlarray(single(rho_impl),'CB'))^2;
        end

        efw=1.0+double(w.ef)*1.5;
        dl=(data_loss*efw+data_loss*(2-efw))/3;
        tot=tot+dl+ph+rl;
    end
    loss=sum(tot)/nb; grads=dlgradient(loss,net.Learnables);
end

function [I_traj,S_traj]=rk4_SI_traj(bv,rv,S0,E0,I0,R0,u_all,d_all,a_all,epf,vst,nV)
    Sc=S0; Ec=E0; Ic=I0; Rc=R0; I_traj=zeros(nV,1); S_traj=zeros(nV,1);
    for k=1:nV
        t=vst+k-1; u=u_all(t); d=d_all(t); a=a_all(t);
        b=bv(min(k,end)); r=rv(min(k,end));
        x0=[Sc;Ec;Ic;Rc];
        k1=seir_rhs(x0,b,r,epf,u,d,a); k2=seir_rhs(x0+0.5*k1,b,r,epf,u,d,a);
        k3=seir_rhs(x0+0.5*k2,b,r,epf,u,d,a); k4=seir_rhs(x0+k3,b,r,epf,u,d,a);
        x1=max(x0+(k1+2*k2+2*k3+k4)/6,0);
        tot=sum(x1); if tot>1e-8, x1=x1/tot; else, x1=[1;0;0;0]; end
        Sc=x1(1); Ec=x1(2); Ic=x1(3); Rc=x1(4);
        I_traj(k)=Ic; S_traj(k)=Sc;
    end
end

function dx=seir_rhs(x,b,r,epf,u,d,a)
    S=x(1);E=x(2);I=x(3);R=x(4); foi=(1-u)*b*S*I;
    dx=[a*(1-S)-foi+d*I*S; foi-(epf+a)*E+d*I*E;
        epf*E-(r+d+a)*I+d*I*I; r*I-a*R+d*I*R];
end

function Rt=compute_Rt_NGM(bv,rv,ev,Sv,uv,dv,av)
    n=numel(bv); Rt=zeros(n,1);
    for k=1:n
        b=bv(k);r=rv(k);ep=ev(k);
        S=Sv(min(k,end));u=uv(min(k,end));d=dv(min(k,end));a=av(min(k,end));
        Rt(k)=max((b*(1-u)*ep*S)/max((ep+a)*(r+d+a),1e-8),0);
    end
    Rt=causal_smooth(Rt,7);
end

function v=nrmse_safe(y,yh)
    ok=isfinite(y)&isfinite(yh);
    if sum(ok)<3, v=1.0; return; end
    v=sqrt(mean((y(ok)-yh(ok)).^2))/(mean(abs(y(ok)))+1e-10);
end

function bw_v=make_fallback_window(vi,~,sqln,XVaC,S_g,E_g,I_g,R_g, ...
        u_g,delta_g,alpha_g,EpiR_g,reliable_g,epoch_g)
    nG=length(S_g);
    n_seq=min(sqln,nG);
    bw_v.X       =XVaC{vi};
    bw_v.Rt_ref  =EpiR_g(end);
    bw_v.reliable=reliable_g(end);
    bw_v.ef      =epoch_g(end);
    if isnan(bw_v.Rt_ref)||bw_v.Rt_ref<=0
        bw_v.Rt_ref=0; bw_v.reliable=false;
    end
    bw_v.S =S_g(end-n_seq+1:end);    bw_v.E =E_g(end-n_seq+1:end);
    bw_v.Iv=I_g(end-n_seq+1:end);    bw_v.R =R_g(end-n_seq+1:end);
    bw_v.u =u_g(end-n_seq+1:end);    bw_v.d =delta_g(end-n_seq+1:end);
    bw_v.a =alpha_g(end-n_seq+1:end);
end

function bw=pack_batch(bidx,X_trn_local,S_sn,E_sn,I_sn,R_sn,u_ts, ...
        delta_t,alpha_s,sqln,Rt_ref_loc,reliable_loc,ef_loc)
    n=numel(bidx); bw=cell(n,1);
    nS=length(S_sn);
    for k=1:n
        i=bidx(k); w.X=squeeze(X_trn_local(i,:,:))';
        
        i2=min(i+sqln-1, nS);
        w.S =S_sn(i:i2);    w.E =E_sn(i:min(i2,length(E_sn)));
        w.Iv=I_sn(i:min(i2,length(I_sn))); w.R =R_sn(i:min(i2,length(R_sn)));
        w.u =u_ts(i:min(i2,length(u_ts))); w.d =delta_t(i:min(i2,length(delta_t)));
        w.a =alpha_s(i:min(i2,length(alpha_s)));
        
        if numel(w.S) < sqln
            pad = sqln - numel(w.S);
            w.S  = [repmat(w.S(1),  pad,1); w.S(:)];
            w.E  = [repmat(w.E(1),  pad,1); w.E(:)];
            w.Iv = [repmat(w.Iv(1), pad,1); w.Iv(:)];
            w.R  = [repmat(w.R(1),  pad,1); w.R(:)];
            w.u  = [repmat(w.u(1),  pad,1); w.u(:)];
            w.d  = [repmat(w.d(1),  pad,1); w.d(:)];
            w.a  = [repmat(w.a(1),  pad,1); w.a(:)];
        end
        w.Rt_ref=Rt_ref_loc(min(i,numel(Rt_ref_loc)));
        w.reliable=reliable_loc(min(i,numel(reliable_loc)));
        w.ef=ef_loc(min(i,numel(ef_loc)));
        bw{k}=w;
    end
end

function yd=decode_yd(p,lw,ps,pm)
    v=double(p(:)'); lw=lw(:)'; ps=ps(:)'; pm=pm(:)';
    yd=(v./lw).*ps+pm;
end

function g_out=norm_clip(g,threshold)
    gd=extractdata(g); gnrm=norm(gd(:),2)+1e-12;
    if gnrm>threshold, g_out=g*(threshold/gnrm); else, g_out=g; end
end

function layers=build_layers(HP,numFtr)
    fc_wide=HP.fcSize+32;
    layers=[sequenceInputLayer(numFtr,'Name','input','Normalization','none')
        lstmLayer(HP.hdnsz1,'OutputMode','sequence','Name','lstm1')
        dropoutLayer(HP.dropR,'Name','drop1')
        layerNormalizationLayer('Name','ln1')
        lstmLayer(HP.hdnsz2,'OutputMode','last','Name','lstm2')
        layerNormalizationLayer('Name','ln2')
        dropoutLayer(HP.dropR2,'Name','drop2')
        fullyConnectedLayer(fc_wide,'Name','fc1')
        tanhLayer('Name','tanh1')
        fullyConnectedLayer(HP.fcSize,'Name','fc2')
        reluLayer('Name','relu2')
        fullyConnectedLayer(3,'Name','fc_out')];
end

function varargout=replaceBadValues(ws,varargin)
    nout = max(nargout, 1);
    varargout = cell(1, nout);
    for k = 1:min(nout, numel(varargin))
        x = varargin{k}(:);
        xm = movmedian(x, ws, 'omitnan');
        xa = movmad(x, ws, 1, 'omitnan');
        xa(xa == 0) = eps;
        bad = abs(x - xm) > 3 * xa;
        x(bad) = xm(bad);
        varargout{k} = x;
    end
end

%% ── STAGE 2 HELPERS ────────────────────────────────────────────────

function [c1,c2,c3,c4,c5]=eval_smooth_combo(sw,sgw,sgd,wsz,rtsw,...
        I_raw,R_raw,DD,N_pop,u_ts,alpha,incd_raw,...
        epsilon_fixed,b_min,b_max,r_min,r_max,e_min,e_max,...
        d_min,d_max,dth_lag,lambda_E4,theta_E,n_iter_E,tol_E,...
        ikc,surv_k,T_sv,n_days)

    alpha_s=max(causal_smooth(alpha,sw),0);
    I_s=max(causal_smooth(I_raw,sw),0); R_s=max(causal_smooth(R_raw,sw),0);
    D_s=max(causal_smooth(DD,sw),0);
    incd_sm=max(causal_smooth(incd_raw,sw),0);
    I_sftd=fillmissing([nan(dth_lag,1);I_s(1:end-dth_lag)],'nearest');
    delta_t=causal_smooth(min(max(D_s./max(I_sftd,1),d_min),d_max),sw);
    I_sn=min(max(I_s./N_pop,0),1); R_sn=min(max(R_s./N_pop,0),1);
    incd_norm=incd_sm./max(N_pop,1);

    dIp=causal_deriv_sg(I_sn,sgw,sgd); dRp=causal_deriv_sg(R_sn,sgw,sgd);
    rho_p=causal_smooth(min(max(fillmissing(real((dRp+alpha_s.*R_sn-delta_t.*I_sn.*R_sn)./(I_sn+1e-6)),...
        'movmedian',[wsz 0]),r_min),r_max),sw);
    E_p=causal_smooth(max((dIp+(rho_p+delta_t+alpha_s).*I_sn-delta_t.*I_sn.^2)./epsilon_fixed,1e-6),sw);

    E_incub_raw=zeros(n_days,1);
    for tt=1:n_days
        avail=min(tt,T_sv);
        E_incub_raw(tt)=surv_k(1:avail)'*incd_norm(tt:-1:tt-avail+1);
    end
    E_inc=causal_smooth(max(E_incub_raw,0),sw);
    E_inc=max(E_inc,0.8*I_sn);
    E_p=max(E_p,E_inc);

    Sp=max(1-E_p-I_sn-R_sn,0); TS=max(Sp+E_p+I_sn+R_sn,1e-6);
    S_sn=Sp./TS; E_sn=E_p./TS; I_sn=I_sn./TS; R_sn=R_sn./TS;
    dE_s=causal_deriv_sg(E_sn,sgw,sgd); dI_s=causal_deriv_sg(I_sn,sgw,sgd);
    dR_s=causal_deriv_sg(R_sn,sgw,sgd);
    I_sf=I_sn+1e-6; S_sf=S_sn+1e-6;
    rho_init=causal_smooth(min(max(fillmissing(real((dR_s+alpha_s.*R_sn-delta_t.*I_sn.*R_sn)./I_sf),...
        'movmedian',[wsz 0]),r_min),r_max),sw);

    E_m1_raw=zeros(n_days,1);
    for tt=1:n_days
        avail=min(tt,T_sv);
        E_m1_raw(tt)=surv_k(1:avail)'*incd_norm(tt:-1:tt-avail+1);
    end
    E_m1=causal_smooth(max(E_m1_raw,1e-6),sw);

    grth=causal_smooth(dI_s./I_sf,sw);
    E_m2=max(I_sn.*min(max(1.05+grth/epsilon_fixed,1.05),6.0),1e-6);
    dIsm=causal_smooth(dI_s,sw); dIsd=std(dIsm)+1e-10;
    fg=dIsm>0.5*dIsd; sg2_m=dIsm>0&~fg; dc=dIsm<=0;
    w1v=0.20*fg+0.15*sg2_m+0.55*dc; w2v=0.05*fg+0.10*sg2_m+0.15*dc; w3v=0.75*fg+0.75*sg2_m+0.30*dc;
    rho_it=rho_init; eps_it=epsilon_fixed*ones(n_days,1);
    M3_0=max(dI_s+(rho_init+delta_t+alpha_s).*I_sn-delta_t.*I_sn.^2,0);
    E_c=causal_smooth(max(w1v.*E_m1+w2v.*E_m2+w3v.*causal_smooth(max(M3_0./epsilon_fixed,1e-6),sw),1e-6),sw);
    E_c=max(E_c,max(I_sn.*((rho_init+delta_t+alpha_s)./max(epsilon_fixed,1e-6)),0.8*I_sn));
    for it=1:n_iter_E
        E_pv=E_c;
        rk=causal_smooth(min(max(fillmissing(real((dR_s+alpha_s.*R_sn-delta_t.*I_sn.*R_sn)./I_sf),...
            'movmedian',[wsz 0]),r_min),r_max),sw);
        M3k=dI_s+(rk+delta_t+alpha_s).*I_sn-delta_t.*I_sn.^2;
        ek=causal_smooth(min(max(fillmissing(real(M3k./max(E_pv,1e-6)),'movmedian',[wsz 0]),e_min),e_max),sw);
        E_ph=max(I_sn.*((rk+delta_t+alpha_s-delta_t.*I_sn)./max(ek,1e-6)),0.8*I_sn);
        E_m3=causal_smooth(max(max(M3k,0)./max(ek,1e-6),1e-6),sw);
        roll7=movsum(incd_sm,sw,'omitnan'); rel_t=roll7>=10;
        Rt_px=nan(n_days,1); kl=numel(ikc);
        for tt=2:n_days
            av=min(tt-1,kl-1); if av<1,continue; end
            lm=ikc(2:av+1)'*incd_sm(tt-1:-1:tt-av);
            if lm>1e-8&&rel_t(tt), Rt_px(tt)=incd_sm(tt)/lm; end
        end
        Rt_px=causal_smooth(max(min(fillmissing(Rt_px,'movmedian',[wsz 0]),6),0),sw);
        beta_px=causal_smooth(min(max((dE_s+(ek+alpha_s).*E_pv-delta_t.*I_sn.*E_pv)./...
            max((1-u_ts).*S_sf.*I_sf,1e-8),b_min),b_max),sw);
        E_m4=min(max(Rt_px.*(rk+delta_t+alpha_s).*I_sn./max(beta_px.*(1-u_ts).*S_sf,1e-8),...
            0.8*I_sn),10*I_sn);
        E_m4(~(Rt_px>0&isfinite(Rt_px)))=E_m3(~(Rt_px>0&isfinite(Rt_px)));
        En=causal_smooth(max((1-lambda_E4).*(w1v.*E_m1+w2v.*E_m2+w3v.*E_m3)+lambda_E4.*E_m4,1e-6),sw);
        E_c=max(theta_E*En+(1-theta_E)*E_pv,E_ph); rho_it=rk; eps_it=ek;
        if norm(E_c-E_pv)/(norm(E_pv)+1e-8)<tol_E, break; end
    end
    E_ph2=max(I_sn.*((rho_it+delta_t+alpha_s-delta_t.*I_sn)./max(eps_it,1e-6)),0.8*I_sn);
    E_sn=max(E_c,E_ph2);
    Stmp=max(1-E_sn-I_sn-R_sn,0); TS=max(Stmp+E_sn+I_sn+R_sn,1e-6);
    S_sn=Stmp./TS; E_sn=E_sn./TS; I_sn=I_sn./TS; R_sn=R_sn./TS;

    dS2=causal_deriv_sg(S_sn,sgw,sgd); dE2=causal_deriv_sg(E_sn,sgw,sgd);
    dI2=causal_deriv_sg(I_sn,sgw,sgd); dR2=causal_deriv_sg(R_sn,sgw,sgd);
    I_sf2=I_sn+1e-6; SI_sf=(1-u_ts).*(S_sn+1e-6).*I_sf2+1e-6;
    br=fillmissing(real((dE2+(eps_it+alpha_s).*E_sn-delta_t.*I_sn.*E_sn)./SI_sf),'movmedian',[wsz 0]);
    rr=fillmissing(real((dR2+alpha_s.*R_sn-delta_t.*I_sn.*R_sn)./I_sf2),'movmedian',[wsz 0]);
    er=fillmissing(real((dI2+(rho_it+delta_t+alpha_s).*I_sn-delta_t.*I_sn.^2)./max(E_sn,1e-6)),'movmedian',[wsz 0]);
    beta_out=causal_smooth(min(max(br,b_min),b_max),sw);
    rho_out =causal_smooth(min(max(rr,r_min),r_max),sw);
    eps_out =causal_smooth(min(max(er,e_min),e_max),sw);
    [beta_out,rho_out,eps_out]=replaceBadValues(wsz,beta_out,rho_out,eps_out);

    beff=causal_smooth((1-u_ts).*beta_out,7);
    Rt_r=max((beff.*eps_out.*S_sn)./max((eps_out+alpha_s).*(rho_out+delta_t+alpha_s),1e-8),0);
    Rt_out=max(causal_smooth(Rt_r,rtsw),0);

    foi=(1-u_ts).*beta_out.*S_sn.*I_sn;
    dS_p=alpha_s.*(1-S_sn)-foi+delta_t.*I_sn.*S_sn;
    dE_p=foi-(eps_out+alpha_s).*E_sn+delta_t.*I_sn.*E_sn;
    dI_p=eps_out.*E_sn-(rho_out+delta_t+alpha_s).*I_sn+delta_t.*I_sn.^2;
    dR_p=rho_out.*I_sn-alpha_s.*R_sn+delta_t.*I_sn.*R_sn;
    denom1=abs(dS2)+abs(dE2)+abs(dI2)+abs(dR2)+1e-8;
    c1=mean(((dS2-dS_p).^2+(dE2-dE_p).^2+(dI2-dI_p).^2+(dR2-dR_p).^2)./denom1,'omitnan');
    c2=mean([roughness_fn(beta_out),roughness_fn(rho_out),roughness_fn(eps_out)]);
    prm=0.05*max(double(incd_raw)); psm=0.05*max(double(I_sn.*N_pop));
    [~,tr]=findpeaks(double(incd_raw),'MinPeakProminence',max(prm,1));
    [~,ts]=findpeaks(double(I_sn.*N_pop),'MinPeakProminence',max(psm,1e-6));
    if ~isempty(tr)&&~isempty(ts)
        dm=abs(tr(:)-ts(:)'); c3=mean(min(dm,[],2),'omitnan');
    else, c3=n_days/4;
    end
    dI_ph=causal_smooth(dI2,sw); eps_ph=0.05;
    ok4=isfinite(Rt_out)&isfinite(dI_ph)&abs(Rt_out-1)>eps_ph;
    if sum(ok4)>10
        rph=corr(Rt_out(ok4)-1,dI_ph(ok4),'Type','Spearman'); c4=1-max(rph,-1);
    else, c4=1.0;
    end
    c5=mean(abs(S_sn+E_sn+I_sn+R_sn-1),'omitnan');
end

function r=roughness_fn(x)
    x=x(isfinite(x)); if numel(x)<3,r=0;return; end
    r=mean(abs(diff(diff(x))))/(range(x)+1e-10);
end

%% ── STAGE 1 HELPERS ────────────────────────────────────────────────

function [beta,beta_se,dev,qaic]=qpois_glm(X,Y)
    [beta,beta_se,dev,qaic]=qpois_penalised(X,Y,zeros(size(X,2)));
end

function [beta,beta_se,dev,qaic]=qpois_penalised(X,Y,P)
    Y=max(Y(:),0); n=length(Y); p_=size(X,2); mu=max(Y,0.5); beta=zeros(p_,1);
    ridge=1e-4; tol_p=1e-6;
    for iter=1:200
        eta=log(mu); z=eta+(Y-mu)./mu; sqW=sqrt(mu); Xw=X.*sqW; zw=z.*sqW;
        A=Xw'*Xw+P+ridge*eye(p_); [Q_,R_]=qr(A);
        if rcond(R_)<1e-14, A=A+1e-2*eye(p_); [Q_,R_]=qr(A); end
        beta_new=R_\(Q_'*(Xw'*zw));
        mu_new=max(exp(min(X*beta_new,500)),1e-10);
        dev_old=2*sum(Y.*log(max(Y,1e-10)./mu)-(Y-mu));
        dev_new=2*sum(Y.*log(max(Y,1e-10)./mu_new)-(Y-mu_new));
        step=1;
        while dev_new>dev_old+1e-6&&step>1e-4
            step=step/2; bt=beta+step*(beta_new-beta);
            mu_new=max(exp(min(X*bt,500)),1e-10);
            dev_new=2*sum(Y.*log(max(Y,1e-10)./mu_new)-(Y-mu_new));
        end
        beta=beta+step*(beta_new-beta); mu=max(exp(min(X*beta,500)),1e-10);
        if norm(beta_new-beta)/(norm(beta)+1e-10)<tol_p, break; end
    end
    dev=2*sum(Y.*log(max(Y,1e-10)./mu)-(Y-mu));
    phi=max(dev/max(n-p_,1),1); sqW=sqrt(mu); Xw=X.*sqW;
    A=Xw'*Xw+P+ridge*eye(p_); Ainv=A\eye(p_);
    V=phi*Ainv*(Xw'*Xw)*Ainv; beta_se=sqrt(max(diag(V),0)); qaic=dev+2*p_;
end

function xl=extract_lag(x_full,l,idx)
    n=length(idx); xl=nan(n,1);
    for ti=1:n
        tb=idx(ti)-l; if tb>=1, xl(ti)=x_full(tb); end
    end
end

function B=ns_basis(x,df)
    x=x(:); n=length(x); bnd=[min(x),max(x)]; rng_v=max(bnd(2)-bnd(1),1e-10);
    knots=quantile(x,linspace(0,1,df+1)); knots=knots(2:end-1);
    all_k=[bnd(1);knots(:);bnd(2)]; B=zeros(n,df);
    B(:,1)=1; B(:,2)=(x-bnd(1))/rng_v;
    for k=1:df-2
        kk=all_k(k+1);
        t1=max(x-kk,0).^3/rng_v^3; t2=max(x-bnd(2),0).^3/rng_v^3;
        t3=max(x-bnd(1),0).^3/rng_v^3;
        B(:,k+2)=t1-t2*(bnd(2)-kk)/rng_v+t3*(bnd(1)-kk)/rng_v;
    end
    for j=2:df
        s=std(B(:,j)); if s>1e-12, B(:,j)=B(:,j)/s; end
    end
end

%% ── SHARED HELPERS ────────────────────────────────────────────────

function y=causal_smooth(x,w)
    if isvector(x)
        y=movmean(x(:),[w-1,0],'omitnan','Endpoints','shrink');
        if isrow(x),y=y'; end
    else
        y=zeros(size(x));
        for c=1:size(x,2)
            y(:,c)=movmean(x(:,c),[w-1,0],'omitnan','Endpoints','shrink');
        end
    end
end

function dx=causal_deriv_sg(x,w,deg)
    x=x(:); n=length(x); dx=zeros(n,1); mpt=max(3,deg+1); tc=struct();
    for t=1:n
        seg=x(max(1,t-w+1):t); m=length(seg);
        if m<mpt, dx(t)=0; continue; end
        key=sprintf('m%d',m);
        if ~isfield(tc,key), tc.(key)=linspace(0,1,m)'; end
        p=polyfit(tc.(key),seg,min(deg,m-1));
        dx(t)=polyval(polyder(p),1.0)*(m-1);
    end
    dx=filloutliers(dx,'linear','movmedian',max(5,ceil(w/2)));
end

function sp=build_si_pmf_daily(nd,tdn,ttr,nv,spv,~,msg,tl)
    sp=cell(nd,1);
    for t=1:nd
        tn=tdn(t); wv=ones(nv,1);
        for vv=1:nv
            wv(vv)=wv(vv)*(1/(1+exp(-(tn-ttr(vv))/tl)));
            if vv<nv, wv(vv)=wv(vv)*(1-1/(1+exp(-(tn-ttr(vv+1))/tl))); end
        end
        ws=sum(wv); if ws>1e-12,wv=wv/ws; else,wv=zeros(nv,1);wv(1)=1; end
        pm=zeros(msg+1,1);
        for vv=1:nv
            if wv(vv)<1e-9,continue; end
            pv=spv{vv}; pm(1:numel(pv))=pm(1:numel(pv))+wv(vv)*pv;
        end
        pm(1)=0; sm=sum(pm); if sm>0,pm=pm/sm; else,pm(2)=1; end
        sp{t}=pm;
    end
end
