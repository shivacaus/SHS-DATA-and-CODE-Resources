%% Figures and Table generation script 
%  UPDATED: 2026-04-05  SHS
%  Run after main script SEIR_LSTM_SHS_F30, (time consuming)
%  OR load F30_full_n30.mat first. (If available this Large file)
%  OR  load F30_fig_table_data.mat first (RECOMMENDED)
clear; clc; close all;

%% ==================== LOAD DATA ====================
load('F30_fig_table_data.mat');   % Zenodo and Github compatible
fprintf('Loaded F30_fig_table_data.mat  (n_days=%d)\n', n_days);

 % load('F30_full_n30.mat');        % Zenodo compatible
 % fprintf('Loaded F30_full_n30.mat  (n_days=%d)\n', n_days);

fprintf('\n=== PART 11: Generating Figures (Fig2-Fig5) ===\n');
outdir = 'figures_PINN_LSTM';
if ~exist(outdir,'dir'), mkdir(outdir); end

%% ====================  GLOBAL SETTINGS ====================
%   Double-column text area : 174 mm  (max width, used for all figures)
%   Max height              : 234 mm
%   Font size range         : 8-12 pt

chosenFont = 'Arial';

% Figure width 
W_cm  = 17.4;   % cm

% Font sizes 
bfs   = 9;      % axis tick labels
lfs   = 8;      % legend text
labfs = 10;     % axis labels

% Line / marker
LW      = 1.3;
lw_fcst = LW + 0.5;   % 1.8
mkSz    = 4;

% Global MATLAB defaults
set(groot, ...
    'DefaultAxesFontName',            chosenFont, ...
    'DefaultTextFontName',            chosenFont, ...
    'DefaultLegendFontName',          chosenFont, ...
    'DefaultAxesFontSize',            bfs, ...
    'DefaultAxesFontWeight',          'normal', ...
    'DefaultTextFontWeight',          'normal', ...
    'DefaultTextInterpreter',         'tex', ...
    'DefaultAxesTickLabelInterpreter','tex', ...
    'DefaultLegendInterpreter',       'tex');

% Axis style helper
sAx = @(ax) set(ax, ...
    'FontSize',   bfs, ...
    'FontWeight', 'normal', ...
    'LineWidth',   0.8, ...
    'Box',        'on', ...
    'TickDir',    'out', ...
    'TickLabelInterpreter','tex');

%% ==================== SHARED COLOURS & STYLES ====================
col_data = [0.00 0.18 0.45];   % dark blue
col_lstm = [0.72 0.08 0.00];   % dark red
col_fcst = [0.00 0.00 0.00];   % black

ls_data = '-';    mk_data = 'o';
ls_lstm = '--';   mk_lstm = 's';
ls_fcst = '-.';

blendW   = @(c,a) a.*c + (1-a).*ones(size(c));
ci_blend = blendW([0.40 0.15 0.60], 0.50);
ci_edge  = [0.20 0.05 0.35];

var_colors = [0.85 0.93 0.97; 0.85 0.97 0.85;
              0.97 0.97 0.75; 0.97 0.88 0.75];
var_colors = blendW(var_colors, 0.45);
var_start_idx = zeros(n_vrnt,1);
var_end_idx   = zeros(n_vrnt,1);
for vv = 1:n_vrnt
    si2 = find(dates >= SI_vrnt{vv,1}, 1, 'first');
    ei2 = find(dates <= SI_vrnt{vv,2}, 1, 'last');
    if isempty(si2), si2 = 1;      end
    if isempty(ei2), ei2 = n_days; end
    var_start_idx(vv) = si2;
    var_end_idx(vv)   = ei2;
end

t_axis = 1:n_days;
mkSp   = @(n) max(1, floor(n/18));
sp1    = mkSp(n_days);


%% ==================== FIG 2: Parameters (beta, rho, epsilon) ====================
% 3 stacked panels 
H2_cm = 10;

fig2 = figure('Color','w', ...
    'Units','centimeters', 'Position',[2 2 W_cm H2_cm], ...
    'PaperUnits','centimeters', 'PaperSize',[W_cm H2_cm], ...
    'PaperPosition',[0 0 W_cm H2_cm], ...
    'PaperPositionMode','manual');

pLbl = {'\beta(t)', '\rho(t)', '\epsilon(t)'};
pObs = {beta_SEIR,      rho_SEIR,      epsilon_SEIR};
pPrd = {beta_pred_full, rho_pred_full, epsilon_pred_full};
axF2 = gobjects(1,3);

for k = 1:3
    axF2(k) = subplot(3,1,k); hold on;

    yl_obs = [min(pObs{k})*0.88, max(pObs{k})*1.12];
    if diff(yl_obs) < 1e-6, yl_obs = yl_obs + [-1e-4 1e-4]; end

    idx = 1:sp1:n_days;
    plot(t_axis, pObs{k}, ls_data, ...
        'Color',col_data,'LineWidth',LW, ...
        'Marker',mk_data,'MarkerIndices',idx, ...
        'MarkerFaceColor',col_data,'MarkerEdgeColor',col_data, ...
        'MarkerSize',mkSz,'DisplayName','SEIR (estimated)');

    vld_p = find(~isnan(pPrd{k}));
    if ~isempty(vld_p)
        idxL = vld_p(1):sp1:vld_p(end);
        plot(t_axis, pPrd{k}, ls_lstm, ...
            'Color',col_lstm,'LineWidth',LW+0.3, ...
            'Marker',mk_lstm,'MarkerIndices',idxL, ...
            'MarkerFaceColor',col_lstm,'MarkerEdgeColor',col_lstm, ...
            'MarkerSize',mkSz,'DisplayName','SEIR-LSTM');
    end

    ylabel(pLbl{k},'FontSize',labfs,'FontWeight','normal','Interpreter','tex');
    if k == 3
        xlabel('Day','FontSize',labfs,'FontWeight','normal');
    end
    ylim(yl_obs); grid off; sAx(gca);

    if k == 1
        drawnow;
        lg = legend('show','Box','off','FontSize',lfs);
        set(lg,'AutoUpdate','off','FontName',chosenFont, ...
            'Interpreter','tex','Color','none','EdgeColor','none', ...
            'TextColor',[0 0 0],'FontWeight','normal');
        lg.Units = 'normalized';
        ax_pos = axF2(1).Position;
        lg_w = ax_pos(3)*0.28;  lg_h = ax_pos(4)*0.45;
        lg_x = ax_pos(1) + ax_pos(3) - lg_w - 0.01;
        lg_y = ax_pos(2) + ax_pos(4)*0.60;
        lg.Position = [lg_x lg_y lg_w lg_h];
    end
end

linkaxes(axF2,'x'); xlim(axF2(1),[1 n_days]);
set(findall(fig2,'-property','FontName'),   'FontName',   chosenFont);
set(findall(fig2,'-property','FontWeight'), 'FontWeight', 'normal');
exportEPS(fig2, fullfile(outdir,'Fig2_Parameters.eps'));
fprintf('  Saved: Fig2_Parameters.eps\n');


%% ==================== FIG 3: SEIR States + 100-day Forecast ====================
% 4 stacked panels 
H3_cm = 13;

t_fcst_ax = n_days + (1:forecast_days);
sObs = {S_sn,       E_sn,       I_sn,       R_sn};
sFst = {S_fc,       E_fc,       I_fc,       R_fc};
sOde = {S_ode_full, E_ode_full, I_ode_full, R_ode_full};
sLbl = {'s','e','i','r'};

fig3 = figure('Color','w', ...
    'Units','centimeters', 'Position',[2 2 W_cm H3_cm], ...
    'PaperUnits','centimeters', 'PaperSize',[W_cm H3_cm], ...
    'PaperPosition',[0 0 W_cm H3_cm], ...
    'PaperPositionMode','manual');
axH  = gobjects(1,4);
spH  = mkSp(n_days);

for k = 1:4
    axH(k) = subplot(4,1,k); hold on;

    all_v = [sObs{k}; sFst{k}; sOde{k}(isfinite(sOde{k}))];
    all_v = all_v(isfinite(all_v) & all_v >= 0);
    dr    = max(all_v) - min(all_v);
    pad   = max(0.05*dr, 1e-5);
    yl_hi = max(all_v) + pad;
    if k==2||k==3; yl_lo = -0.04*dr; else; yl_lo = max(0, min(all_v)-pad); end
    if yl_hi <= yl_lo + 1e-8; yl_hi = yl_lo + 1e-3; end

    if k == 3
        ci_shade_fill(gca, t_fcst_ax, I_ci_lo', I_ci_hi', ci_blend, ci_edge);
    end

    idxH = 1:spH:n_days;

    plot(t_axis, sObs{k}, ls_data, ...
        'Color',col_data,'LineWidth',LW, ...
        'Marker',mk_data,'MarkerIndices',idxH, ...
        'MarkerFaceColor',col_data,'MarkerEdgeColor',col_data, ...
        'MarkerSize',mkSz,'DisplayName','Observed');

    vld_ode = find(~isnan(sOde{k}));
    if ~isempty(vld_ode)
        sp_ode    = max(1, floor(numel(vld_ode)/18));
        pos_marks = 1:sp_ode:numel(vld_ode);
        plot(vld_ode, sOde{k}(vld_ode), ls_lstm, ...
            'Color',col_lstm,'LineWidth',LW+0.3, ...
            'Marker',mk_lstm,'MarkerIndices',pos_marks, ...
            'MarkerFaceColor',col_lstm,'MarkerEdgeColor',col_lstm, ...
            'MarkerSize',mkSz,'DisplayName','ODE (SEIR-LSTM)');
    end

    plot([t_axis(end), t_fcst_ax], [sObs{k}(end), sFst{k}(:)'], ls_fcst, ...
        'Color',col_fcst,'LineWidth',lw_fcst, ...
        'Marker','none','DisplayName','Forecast');

    if k == 3
        patch([NaN NaN],[NaN NaN],ci_blend,'FaceAlpha',1.0, ...
            'EdgeColor',ci_edge,'DisplayName','95% BCI');

        Rt_at_end = Rt_NGM_full(find(~isnan(Rt_NGM_full),1,'last'));
        if isnan(Rt_at_end); Rt_at_end = 1.0; end
        I_at_end = I_sn(n_days); yr = yl_hi - yl_lo;
        x_txt  = n_days - 0.06*(n_days-1);  y_txt  = I_at_end + 0.13*yr;
        x_head = n_days;                     y_head = I_at_end + 0.04*yr;
        plot(n_days,I_at_end,'ko','MarkerSize',4, ...
            'MarkerFaceColor','w','LineWidth',1.0,'HandleVisibility','off');
        quiver(x_txt,y_txt,x_head-x_txt,y_head-y_txt,'k','LineWidth',0.8, ...
            'MaxHeadSize',0.5,'AutoScale','off','HandleVisibility','off');
        text(x_txt,y_txt+0.03*yr,sprintf('R_t = %.3f',Rt_at_end), ...
            'FontSize',bfs,'FontName',chosenFont,'FontWeight','normal', ...
            'HorizontalAlignment','center','VerticalAlignment','bottom', ...
            'Interpreter','tex');
    end

    xline(n_days,'--k','LineWidth',0.8,'HandleVisibility','off');
    ylabel(sLbl{k},'FontSize',labfs,'FontWeight','normal','Interpreter','tex');
    if k == 4
        xlabel('Day','FontSize',labfs,'FontWeight','normal');
    end
    ylim([yl_lo, yl_hi]); grid off; sAx(gca);
end

linkaxes(axH,'x');
xlim(axH(1),[1, n_days + forecast_days + 5]);
drawnow;

lg3 = legend(axH(3),'show','Box','off','FontSize',lfs);
set(lg3,'AutoUpdate','off','FontName',chosenFont,'Interpreter','tex', ...
    'Color','none','EdgeColor','none','TextColor',[0 0 0],'FontWeight','normal');

lg3.Units = 'normalized';
ax3_pos = axH(3).Position; xl3 = get(axH(3),'XLim');
nd_frac = (n_days - xl3(1)) / (xl3(2) - xl3(1));
lg3_w   = ax3_pos(3)*0.26;  lg3_h = ax3_pos(4)*0.32;
lg3_x   = ax3_pos(1) + ax3_pos(3)*(nd_frac - 0.018) - lg3_w;
lg3_y   = ax3_pos(2) + ax3_pos(4)*0.45;
lg3_x   = max(ax3_pos(1)+0.004, min(lg3_x, ax3_pos(1)+ax3_pos(3)-lg3_w-0.004));
lg3_y   = max(ax3_pos(2)+0.004, min(lg3_y, ax3_pos(2)+ax3_pos(4)-lg3_h-0.004));
lg3.Position = [lg3_x, lg3_y, lg3_w, lg3_h];

set(findall(fig3,'-property','FontName'),   'FontName',   chosenFont);
set(findall(fig3,'-property','FontWeight'), 'FontWeight', 'normal');
set(lg3,'FontName',chosenFont);
exportEPS(fig3, fullfile(outdir,'Fig3_States_Forecast.eps'));
fprintf('  Saved: Fig3_States_Forecast.eps\n');


%% ==================== FIG 4: Rt panel + daily cases ====================
% 2 stacked panels 
H4_cm = 8;

c_epi_fwd = [0.00 0.18 0.45];
c_epi_sm  = [0.04 0.38 0.04];
c_ngm     = [0.72 0.08 0.00];

ls_fwd = '-';   mk_fwd = 'o';  mkSz_fwd = mkSz + 1;
ls_sm  = '--';  mk_sm  = '^';  mkSz_sm  = mkSz + 1;
ls_ngm = '-.';

sp_fwd = max(1, floor(n_days/12));
sp_sm  = max(1, floor(n_days/12));
off_sm = max(1, floor(sp_sm/2));

fig4 = figure('Color','w', ...
    'Units','centimeters', 'Position',[2 2 W_cm H4_cm], ...
    'PaperUnits','centimeters', 'PaperSize',[W_cm H4_cm], ...
    'PaperPosition',[0 0 W_cm H4_cm], ...
    'PaperPositionMode','manual');

ax_top = subplot(2,1,1); hold(ax_top,'on');
yl5 = [0 6]; ylim(ax_top,yl5);

idx_fwd = 1:sp_fwd:n_days;
plot(ax_top,t_axis,EpiR_fwd_aligned,ls_fwd, ...
    'Color',c_epi_fwd,'LineWidth',LW, ...
    'Marker',mk_fwd,'MarkerIndices',idx_fwd, ...
    'MarkerFaceColor',c_epi_fwd,'MarkerEdgeColor','k', ...
    'MarkerSize',mkSz_fwd,'DisplayName','EpiFilter (forward)');

idx_sm = min(off_sm,n_days):sp_sm:n_days;
plot(ax_top,t_axis,EpiR_sm_aligned,ls_sm, ...
    'Color',c_epi_sm,'LineWidth',LW, ...
    'Marker',mk_sm,'MarkerIndices',idx_sm, ...
    'MarkerFaceColor',c_epi_sm,'MarkerEdgeColor',c_epi_sm*0.6, ...
    'MarkerSize',mkSz_sm,'DisplayName','EpiFilter (smoother)');

vld_rt = find(~isnan(Rt_NGM_full));
if ~isempty(vld_rt)
    plot(ax_top,vld_rt,Rt_NGM_full(vld_rt),ls_ngm, ...
        'Color',c_ngm,'LineWidth',LW+0.4, ...
        'Marker','none','DisplayName','LSTM-NGM');
end

yline(ax_top,1,'--k','LineWidth',0.8,'HandleVisibility','off');
ylabel(ax_top,'R_t','FontSize',labfs,'FontWeight','normal','Interpreter','tex');
ylim(ax_top,yl5); grid(ax_top,'off'); sAx(ax_top);

lg4a = legend(ax_top,'show','Location','northeast','Box','off','FontSize',lfs);
set(lg4a,'AutoUpdate','off','Interpreter','tex','FontName',chosenFont, ...
    'TextColor',[0 0 0],'FontWeight','normal');

ax_bot = subplot(2,1,2); hold(ax_bot,'on');
I_daily_plot = max(incd_raw,0);
avg7         = movmean(I_daily_plot,[6 0],'omitnan');

patch(ax_bot,[t_axis,fliplr(t_axis)],[I_daily_plot',zeros(1,n_days)], ...
    [0.55 0.55 0.55],'EdgeColor','none','DisplayName','Daily cases');
plot(ax_bot,t_axis,avg7,'-', ...
    'Color',[0.72 0.08 0.00],'LineWidth',LW+0.4,'DisplayName','7-day avg');

ylim(ax_bot,[0, max(I_daily_plot)*1.15]);
ylabel(ax_bot,'Daily cases','FontSize',labfs,'FontWeight','normal');
xlabel(ax_bot,'Day',        'FontSize',labfs,'FontWeight','normal');
grid(ax_bot,'off'); sAx(ax_bot);

lg4b = legend(ax_bot,'show','Location','northeast','Box','off','FontSize',lfs);
set(lg4b,'AutoUpdate','off','Interpreter','tex','FontName',chosenFont, ...
    'TextColor',[0 0 0],'FontWeight','normal');

linkaxes([ax_top,ax_bot],'x'); xlim(ax_top,[1,n_days]);
set(findall(fig4,'-property','FontName'),   'FontName',   chosenFont);
set(findall(fig4,'-property','FontWeight'), 'FontWeight', 'normal');
exportEPS(fig4, fullfile(outdir,'Fig4_Rt.eps'));
fprintf('  Saved: Fig4_Rt.eps\n');


%% ==================== FIG 5: MIA curves ====================
% 1 row x 3 panels 
H5_cm = 8;

% --- Linearity analysis ---
sigma_vec = perturb_lvl(:);
R2_thresh = 0.99;
n_pm = 3; n_mv = 3;
R2_mat     = nan(n_pm,n_mv); b_ols_mat  = nan(n_pm,n_mv);
AI_mat     = nan(n_pm,n_mv); mono_mat   = false(n_pm,n_mv);
linear_mat = false(n_pm,n_mv);
[sigma_sorted, sort_idx] = sort(sigma_vec);

for pm_i = 1:n_pm
    for v = 1:n_mv
        y_raw = squeeze(ens_mean(:,pm_i,v)); y = y_raw(sort_idx);
        b_ols = (sigma_sorted'*sigma_sorted) \ (sigma_sorted'*y);
        y_hat = b_ols*sigma_sorted;
        SS_res = sum((y-y_hat).^2); SS_tot = sum(y.^2);
        if SS_tot < eps; R2 = NaN; else; R2 = 1 - SS_res/SS_tot; end
        b_ols_mat(pm_i,v) = b_ols; R2_mat(pm_i,v) = R2;
        dy = diff(y);
        mono_mat(pm_i,v)   = all(dy>=0) || all(dy<=0);
        linear_mat(pm_i,v) = ~isnan(R2) && (R2 >= R2_thresh);
        y_neg2 = y(1); y_pos2 = y(end);
        if abs(y_neg2) < eps; AI_mat(pm_i,v) = NaN;
        else; AI_mat(pm_i,v) = (abs(y_pos2)-abs(y_neg2))/abs(y_neg2)*100; end
    end
end

fprintf('\n=== MIA Linearity Analysis (R2 threshold = %.2f) ===\n',R2_thresh);
fprintf('%-5s %-5s  %+11s  %8s  %-10s  %-10s  %12s\n', ...
    'Par','Met','b_ols (slope)','R2','Linear?','Monotone?','Asymmetry(%)');
fprintf('%s\n',repmat('-',1,70));
param_lbl_pr = {'\beta','\rho','\varepsilon'};
met_lbl_pr   = {'T_m','RH','WS'};
for pm_i = 1:n_pm
    for v = 1:n_mv
        if linear_mat(pm_i,v); ls2='yes'; else; ls2='NO'; end
        if mono_mat(pm_i,v);   ms2='yes'; else; ms2='NO'; end
        if isnan(R2_mat(pm_i,v))
            fprintf('%-5s %-5s  %+11.3e  %8s  %-10s  %-10s  %+12.1f\n', ...
                param_lbl_pr{pm_i},met_lbl_pr{v},b_ols_mat(pm_i,v),'NaN',ls2,ms2,AI_mat(pm_i,v));
        else
            fprintf('%-5s %-5s  %+11.3e  %8.4f  %-10s  %-10s  %+12.1f\n', ...
                param_lbl_pr{pm_i},met_lbl_pr{v},b_ols_mat(pm_i,v),R2_mat(pm_i,v),ls2,ms2,AI_mat(pm_i,v));
        end
    end
end
save(fullfile(outdir,'mia_linearity.mat'), ...
    'R2_mat','b_ols_mat','AI_mat','mono_mat','linear_mat','R2_thresh');
fprintf('  Linearity results saved: mia_linearity.mat\n');

fprintf('Generating MIA figure (n=%d)...\n', size(ens_mia,1));

% MIA colours
c_T  = [0.00 0.25 0.55];
c_RH = [0.72 0.08 0.00];
c_WS = [0.04 0.38 0.04];

mia_sty = {
    c_T,  '-',  'o', c_T;
    c_RH, '--', 's', c_RH;
    c_WS, ':',  '^', c_WS
};

ci_fill_clr = { blendW(c_T,0.254); blendW(c_RH,0.502); blendW(c_WS,0.450) };
ci_bnd_ls   = {'-','--',':'};
ci_bnd_lw   = [0.7, 0.7, 1.0];

mYlb      = {'\Delta\beta', '\Delta\rho', '\Delta\epsilon'};
dsp_names = {'T_m','RH','WS'};

mImp = {
    {ens_mean(:,1,1), ens_mean(:,1,2), ens_mean(:,1,3)};
    {ens_mean(:,2,1), ens_mean(:,2,2), ens_mean(:,2,3)};
    {ens_mean(:,3,1), ens_mean(:,3,2), ens_mean(:,3,3)}
};

fig5 = figure('Color','w', ...
    'Units','centimeters', 'Position',[2 2 W_cm H5_cm], ...
    'PaperUnits','centimeters', 'PaperSize',[W_cm H5_cm], ...
    'PaperPosition',[0 0 W_cm H5_cm], ...
    'PaperPositionMode','manual');

for sp = 1:3
    ax = subplot(1,3,sp); hold on;

    % Layer 1: CI fills (back to front: WS, RH, Tm)
    for wv = [3,2,1]
        fill([perturb_lvl, fliplr(perturb_lvl)], ...
             [ens_bslo(:,sp,wv)', fliplr(ens_bshi(:,sp,wv)')], ...
             ci_fill_clr{wv},'FaceAlpha',1.0,'EdgeColor','none', ...
             'HandleVisibility','off');
    end

    % Layer 2: CI boundary lines
    for wv = 1:3
        plot(perturb_lvl,ens_bshi(:,sp,wv), ...
            ci_bnd_ls{wv},'Color',mia_sty{wv,1}, ...
            'LineWidth',ci_bnd_lw(wv),'HandleVisibility','off');
        plot(perturb_lvl,ens_bslo(:,sp,wv), ...
            ci_bnd_ls{wv},'Color',mia_sty{wv,1}, ...
            'LineWidth',ci_bnd_lw(wv),'HandleVisibility','off');
    end

    % Layer 3: Mean curves
    for wv = 1:3
        sc = mia_sty(wv,:);
        plot(perturb_lvl, mImp{sp}{wv}, ...
            'LineStyle',sc{2},'Color',sc{1},'LineWidth',LW+0.2, ...
            'Marker',sc{3},'MarkerFaceColor',sc{4}, ...
            'MarkerEdgeColor',sc{1},'MarkerSize',mkSz+1, ...
            'DisplayName',dsp_names{wv});
    end

    yline(0,'--','Color',[0.45 0.45 0.45],'LineWidth',0.8,'HandleVisibility','off');

    xlabel('\sigma','FontSize',labfs,'FontWeight','normal','Interpreter','tex');
    ylabel(mYlb{sp},'FontSize',labfs,'FontWeight','normal','Interpreter','tex');

    % Mean-curve legend: first panel only
    if sp == 1
        lg5a = legend('Box','off','FontSize',lfs);
        set(lg5a,'AutoUpdate','off','FontName',chosenFont, ...
            'Interpreter','tex','FontWeight','normal');
        drawnow;
        lg5a.Units    = 'normalized';
        lg5a.Position = [0.16, 0.76, 0.10, 0.14];
    end

    xlim([-2.3 2.3]); grid off;
    set(gca,'FontSize',bfs,'FontName',chosenFont,'FontWeight','normal', ...
        'Box','on','LineWidth',0.8,'TickDir','out', ...
        'TickLabelInterpreter','tex');
end

% CI proxy legend (bottom-left of first panel)
ax1     = subplot(1,3,1);
ax1_pos = ax1.Position(:)';
ax_leg  = axes('Position',ax1_pos,'Color','none','XColor','none', ...
               'YColor','none','HitTest','off');
hold(ax_leg,'on');
h_prx = gobjects(3,1);
for wv = 1:3
    h_prx(wv) = fill(ax_leg,NaN,NaN,ci_fill_clr{wv}, ...
        'EdgeColor',mia_sty{wv,1},'LineStyle',ci_bnd_ls{wv},'LineWidth',1.2);
end
lg5b = legend(ax_leg,h_prx, ...
    {'95% BCI (T_m)','95% BCI (RH)','95% BCI (WS)'}, ...
    'Box','off','FontSize',lfs,'Interpreter','tex');
set(lg5b,'AutoUpdate','off','FontName',chosenFont,'FontWeight','normal');
lg5b.ItemTokenSize = [15, 4];
drawnow;
lg5b.Units    = 'normalized';
lg5b.Position = [ax1_pos(1)+0.04, ax1_pos(2)+0.01, ...
                 ax1_pos(3)*0.68,  ax1_pos(4)*0.22];

set(findall(fig5,'-property','FontName'),   'FontName',   chosenFont);
set(findall(fig5,'-property','FontWeight'), 'FontWeight', 'normal');
exportEPS(fig5, fullfile(outdir,'Fig5_MIA_n30.eps'));
fprintf('  Saved: Fig5_MIA_n30.eps\n');


%% ==================== GRAYSCALE VERIFICATION ====================
%  --- To re-enable: remove the   %{   and   %}   below.      ---
%{
fprintf('\n=== Grayscale B/W verification ===\n');
fig_handles = {fig2, fig3, fig4, fig5};
fig_names_v = {'Fig2_Parameters','Fig3_States_Forecast','Fig4_Rt','Fig5_MIA_n30'};

for k = 1:4
    try
        figure(fig_handles{k});
        drawnow; pause(0.25); drawnow;
        frame    = getframe(fig_handles{k});
        img_rgb  = frame.cdata;
        img_gray = rgb2gray(img_rgb);

        hv = figure('Name',sprintf('B/W check: %s',fig_names_v{k}), ...
            'Position',[50 50 1400 500],'Color','w','Visible','off');
        subplot(1,2,1); imshow(img_rgb);
        title('COLOR (online)', 'FontSize',9,'FontWeight','normal');
        subplot(1,2,2); imshow(img_gray);
        title('GRAYSCALE (print)','FontSize',9,'FontWeight','normal','Color',[0.8 0 0]);

        bw_path = fullfile(outdir,sprintf('%s_BW_check.png',fig_names_v{k}));
        exportgraphics(hv,bw_path,'Resolution',150);
        close(hv);

        gv = double(img_gray(:)); gsd = std(gv);
        fprintf('  %-30s  gray_std=%.1f',fig_names_v{k},gsd);
        if gsd < 25; fprintf('  <<< WARNING: low contrast\n');
        else;        fprintf('  [OK]\n'); end
    catch
        fprintf('  %-30s  [verification skipped]\n',fig_names_v{k});
    end
end

fprintf('\n  B/W previews: *_BW_check.png in ./%s/\n',outdir);
%}


fprintf('\n  All EPS figures saved to ./%s/\n',outdir);
fprintf('=== FIGURES + TABLES COMPLETE ===\n');
fprintf('  To generate B/W figures, uncomment the "GRAYSCALE VERIFICATION" part and re-run (time consuming)\n');


%% ==================== TABLE 1: Walk-Forward CV ====================
n_f    = size(cv_r2,1);
day_lo = cv_shade(:,1); day_hi = cv_shade(:,2);
fprintf('\n');
fprintf('================================================================\n');
fprintf('  TABLE 1 - Walk-Forward Cross-Validation Results\n');
fprintf('================================================================\n');
fprintf('  %-6s  %-12s  %-9s  %-9s  %-9s  %-9s  %-9s  %-9s\n', ...
    'Fold','Day Range','R2_beta','R2_rho','R2_eps','MAE_beta','MAE_rho','MAE_eps');
fprintf('  %s\n',repmat('-',1,80));
for i = 1:n_f
    fprintf('  %-6d  [%3d-%3d]     %-9.4f  %-9.4f  %-9.4f  %-9.4f  %-9.4f  %-9.4f\n', ...
        i,day_lo(i),day_hi(i), ...
        cv_r2(i,1),cv_r2(i,2),cv_r2(i,3), ...
        cv_mae(i,1),cv_mae(i,2),cv_mae(i,3));
end
fprintf('  %s\n',repmat('-',1,80));
fprintf('  %-6s  %-12s  %-9.4f  %-9.4f  %-9.4f  %-9.4f  %-9.4f  %-9.4f\n', ...
    'Mean','', ...
    mean(cv_r2(:,1)),mean(cv_r2(:,2)),mean(cv_r2(:,3)), ...
    mean(cv_mae(:,1)),mean(cv_mae(:,2)),mean(cv_mae(:,3)));
fprintf('================================================================\n');


%% ==================== TABLE 2: Full-Data Metrics ====================
var_lbl   = {'beta','rho','epsilon','S','E','I','R','Rt_NGM'};
MAE_v     = [mae_b;  mae_r;  mae_e;  mae_S;  mae_E;  mae_I;  mae_R;  mae_Rt];
RMSE_v    = [rmse_b; rmse_r; rmse_e; rmse_S; rmse_E; rmse_I; rmse_R; rmse_Rt];
R2_v      = [r2_b;   r2_r;   r2_e;   r2_S;   r2_E;   r2_I;   r2_R;   r2_Rt];
nRMSE_v   = [nrmse_b;nrmse_r;nrmse_e;nrmse_S;nrmse_E;nrmse_I;nrmse_R;nrmse_Rt];
Pearson_v = [NaN;NaN;NaN;NaN;pearson_E;pearson_I;NaN;NaN];
CCC_v     = [NaN;NaN;NaN;NaN;ccc_E;    ccc_I;    NaN;NaN];
fprintf('\n');
fprintf('================================================================\n');
fprintf('  TABLE 2 - Full-Data Prediction Metrics\n');
fprintf('================================================================\n');
fprintf('  %-10s  %10s  %10s  %8s  %8s  %8s  %8s\n', ...
    'Variable','MAE','RMSE','R2','nRMSE','Pearson','CCC');
fprintf('  %s\n',repmat('-',1,72));
for i = 1:numel(var_lbl)
    if isnan(Pearson_v(i))
        fprintf('  %-10s  %10.4e  %10.4e  %8.4f  %8.4f\n', ...
            var_lbl{i},MAE_v(i),RMSE_v(i),R2_v(i),nRMSE_v(i));
    else
        fprintf('  %-10s  %10.4e  %10.4e  %8.4f  %8.4f  %8.4f  %8.4f\n', ...
            var_lbl{i},MAE_v(i),RMSE_v(i),R2_v(i),nRMSE_v(i),Pearson_v(i),CCC_v(i));
    end
end
fprintf('================================================================\n');


%% ==================== TABLE 3: MIA Summary (Extended) ====================
param_lbl = {'beta','rho','epsilon'};
met_lbl   = {'T_m','RH','WS'};

% --- Compute max |Delta theta| at sigma = +-2 and mean BCI width ---
max_delta = zeros(3,3);
bci_width = zeros(3,3);
for pm_i = 1:3
    for v = 1:3
        y = squeeze(ens_mean(:,pm_i,v));
        max_delta(pm_i,v) = max(abs(y(1)), abs(y(end)));
        bci_width(pm_i,v) = mean(ens_bshi(:,pm_i,v) - ens_bslo(:,pm_i,v));
    end
end

% --- Fixed domain-informed thresholds 
%   weak     : < 1.5e-5
%   moderate : 1.5e-5 -- 3.0e-5
%   strong   : > 3.0e-5
thr_d_low  = 1.5e-5;
thr_d_high = 3.0e-5;

% BCI width thresholds (based on mean BCI width):
%   narrow   : < 2.0e-5
%   moderate : 2.0e-5 -- 3.0e-5
%   wide     : > 3.0e-5
thr_b_low  = 2.0e-5;
thr_b_high = 3.0e-5;

fprintf('\n');
fprintf('================================================================================\n');
fprintf('  TABLE 3 - MIA Summary (Extended)\n');
fprintf('================================================================================\n');
fprintf('  %-10s %-5s %+12s %7s %12s %12s %-10s %-10s\n', ...
    'Param','Met','OLS_Slope','R2', ...
    'MaxDelta','BCIwidth','Strength','BCI_tier');
fprintf('  %s\n',repmat('-',1,88));
for pm_i = 1:3
    for v = 1:3
        sl = strength3(max_delta(pm_i,v), thr_d_low, thr_d_high);
        bl = bci3(bci_width(pm_i,v),     thr_b_low, thr_b_high);
        fprintf('  %-10s %-5s %+12.4e %7.4f %12.4e %12.4e %-10s %-10s\n', ...
            param_lbl{pm_i}, met_lbl{v}, ...
            b_ols_mat(pm_i,v), R2_mat(pm_i,v), ...
            max_delta(pm_i,v), bci_width(pm_i,v), sl, bl);
    end
end
fprintf('  %s\n',repmat('-',1,88));
fprintf('  Strength thresholds (x10^-5): weak < 1.5, moderate 1.5--3.0, strong > 3.0\n');
fprintf('  BCI thresholds     (x10^-5): narrow < 2.0, moderate 2.0--3.0, wide > 3.0\n');

fprintf('========================================================\n');
fprintf('=== ANALYSIS COMPLETE (v30 BMB Fig2-Fig5 + Tables) ===\n');


%%-----LOCAL HELPER FUNCTIONS---------------------------------------------

function exportEPS(fig, filepath)
%EXPORTEPS  Export figure to vector EPS.
    set(fig,'PaperPositionMode','manual');
    print(fig, filepath, '-depsc2', '-vector', '-r300');
end

function ci_shade_fill(ax, x_vec, y_lo, y_hi, fill_col, edge_col)
%CI_SHADE_FILL  Filled confidence-interval band.
    xp = [x_vec(:)', fliplr(x_vec(:)')];
    yp = [y_lo(:)',  fliplr(y_hi(:)')];
    fill(ax, xp, yp, fill_col, ...
        'FaceAlpha',1.0,'EdgeColor',edge_col, ...
        'LineWidth',0.8,'HandleVisibility','off');
end

function lbl = strength3(val, thr_low, thr_high)
% Classify effect size: weak / moderate / strong.
    if val < thr_low
        lbl = 'Weak';
    elseif val <= thr_high
        lbl = 'Moderate';
    else
        lbl = 'Strong';
    end
end

function lbl = bci3(val, thr_low, thr_high)
%  Classify BCI width: narrow / moderate / wide.
    if val < thr_low
        lbl = 'Narrow';
    elseif val <= thr_high
        lbl = 'Moderate';
    else
        lbl = 'Wide';
    end
end
